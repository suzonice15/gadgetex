@extends('fontend.layout.master')
@section('content')


<section class="emi mt-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-2">
            
            </div>
            <div class="col-sm-12 col-lg-10">
                <h2><span style="color:#647C1E">My</span>  Delivery</h2>
                <p> </p>
            </div>
            
        </div>
    </div>
</section>


@endsection