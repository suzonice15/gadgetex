@extends('fontend.layout.master')
@section('content')
<div style="margin-bottom:20px;" class="banarsection">
    <div style="margin-top:30px;background: #DCDDFF;box-shadow: 0px 9px 19px rgb(0 0 0 / 36%);border-radius: 29px;" class="container">
        <div class="row">
            <div style="padding:0px;" class="col-12 ">
                <div style="background:#DCDDFF;" class="offerbanar text-center p-5">
                        <div class="myoffer-title">
                            <img style="width:63px;z-index: 999;margin-left:-48px;margin-top: -20px;" src="{{asset('/images/ICON/shopicon.png')}}" alt="">
                            <span style="background:#fff;padding: 16px 38px;" class="mytitletext mytext">Contact Us</span>
                        </div>
                </div>
            </div>
            <div class="row pt-4">
                <div class="col-12 col-lg-6">
                    <h3 style="color:#7C7C7C;">Visit our Online Shop :</h3>
                    <p> gadgetex.com.bd<br> facebook.com/gadgetex.com.bd</p>
                </div>
                <div class="col-12 col-lg-6">
                    <h3 style="color:#7C7C7C;">Visit our Shop :</h3>
                    <p>Shop No # 78, Level # 3, Lift # 2, Shah Ali Plaza, Mirpur # 10, Dhaka - 1216. </p>
                </div>
            </div>
            <div class="row pt-4">
                <div class="col-12 col-lg-6">
                    <h3 style="color:#7C7C7C;">Call Us :</h3>
                    <p> 01726-003324</p>
                </div>
                <div class="col-12 col-lg-6">
                    <h3 style="color:#7C7C7C;">eMail Us :</h3>
                    <p>gadgetex.com.bd@gmail.com </p>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection