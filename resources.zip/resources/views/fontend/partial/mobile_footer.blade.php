
<div class="container-fluid footer-mobile pt-1 " style="background-color: #eef0f1;">

    <div class="row">

    <div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
      GadgetEx
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse " aria-labelledby="headingOne" data-bs-parent="#accordionExample">
      <div class="accordion-body">

      <ul style="list-style: none" >
                        <li><a href="{{url('/')}}/about">About Us</a></li>
                        <li><a href="{{url('/')}}/our_misson">Our Mission</a></li>
                        <li><a href="{{url('/')}}/Why_GadgetEx">Why GadgetEx</a></li>
                        <li><a  href="{{url('/')}}/Product_Quality">Product Quality  </a></li>
                        <li><a  href="{{url('/')}}/Shop_Address">Shop Address  </a></li>
                        <li><a href="{{url('/')}}/contact">Contact Us</a></li>
                    </ul>

    </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
      Care
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
      <div class="accordion-body">

                     <ul style="list-style: none">
                        <li><a href="{{url('/')}}/takeguide">Take Guide  </a></li>
                        <li><a href="{{url('/')}}/order-tracking">Order Tracking  </a></li>
                        <li><a href="{{url('/')}}/My_Complain">My Complain    </a></li>

                    </ul>

    </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
      Informations
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
      <div class="accordion-body">

                     <ul style="list-style: none">
                        <li><a href="{{url('/')}}/Privacy_Policy ">Privacy  Policy  </a></li>
                        <li><a href="{{url('/')}}/Terms_and_Conditions ">Terms and Conditions</a></li>
                        <li><a href="{{url('/')}}/Return_and_Replacement">Return and Replacement </a></li>
                        <li><a href="{{url('/')}}/Warrantly_Policy">Warranty  Policy</a></li>

                    </ul>


    </div>
    </div>
  </div>
</div> 



</div>


</div>

<div class="container-fluid footer-mobile" >

<div class="row">
    <div class="col-12 text-center">
        <img style="height: 61px;" src="{{asset('/images/ICON/logo.svg')}}" class="img-fluid">
        <p>GadgetEx continues to provide customers with a reliable and trustworthy online shop along with their two shops, helping to ensure a better and premium business experience.</p>
        <hr>
        <!-- <ul class="socialli">
        <div class="d-flex flex-row justify-content-center ">
                       <a class="solik" href="http://"> <i class="fab fa-facebook-square  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color: #833AB4;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-instagram  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color:#25D366;" href="http://" target="_blank" rel="noopener noreferrer"><i class="fab fa-whatsapp  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color:#2867B2;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-linkedin  social-padding-of-single-product "></i></a>
                       <a class="solik" style="color:#1DA1F2;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-twitter  social-padding-of-single-product"></i></a>
         </div>
        </ul> -->

    </div>
</div>
<div class="row mt-5" style="margin-top: 1.5rem !important">
    <div class="col-12 mt-5" style="margin-top: 1rem !important">
        <h4 class="fbytitle">Follow Facebook Page</h4>
        <div class="fbycover">
            <!-- <img class="img-fluid" src="{{asset('/images/ICON/fbcover.png')}}"> -->

        </div>
    </div>
    <div class="col-12 mt-5">
        <h4 class="fbytitle">Connect with Whatsapp</h4>
        <div class="fbycover">
            <!-- <img class="img-fluid" src="{{asset('/images/ICON/fbcover.png')}}"> -->

        </div>
    </div>
    <div class="col-12b mt-5">
    <h4 class="fbytitle">Subscribe YouTube Channel</h4>
    <div class="fbycover">
    <div class="embed-responsive embed-responsive-16by9">
    <iframe width="100%" height="146" src="https://www.youtube.com/embed/BVMsRltq2yU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
        </div>
    </div>
</div>
</div>
<div class="container">
    
    <div class="row">
        <div class="col-12" style="display: flex;flex-direction: row;justify-content:center;">
        <h5  style="margin-top: 25px;
font-size: 15px;" >Registered Member of </h4><img src="{{asset('/images/ICON/MemberofeCab.png')}}" style="height: 32px;margin-top: 14px;margin-left: 9px;" class="img-fluid"> 
        </div>
        <div class="col-12">
        <img style="margin-top: 6px;margin-bottom: 7px;" src="{{asset('/images/ICON/ssl.png')}}"   class="img-fluid">
        </div>

       
        <div class="col-12">
        <h4 style="font-size: 15px;margin-bottom: 57px;margin-top: 6px;" class="text-center">©  {{date("Y")}} .All  Rights Reserved by GadgetEx. </h4>
        </div>
    </div>
    </div>
</div>
</div>
</div>


<div class="container-fluid fmbfooter mt-3">
    <div class="row">
        <div class="col-2" style="max-width: 100%; height: auto;">
            <img src="{{asset('/images/ICON/Capture-4.png')}}" class="img-fluid "  >

        </div>
        <div class="col-8 text-center" style="background-color: #5f5f5f">
           <p class="fbotom" >Start Purchase</p>
        </div>
        <div class="col-2" style="background:#ddd;border-top-right-radius: 30px;">
            <img src="{{asset('/images/ICON/msg.png')}}" class="img-fluid "  style="margin-top: 13px;" >

        </div>
    </div>




</div>