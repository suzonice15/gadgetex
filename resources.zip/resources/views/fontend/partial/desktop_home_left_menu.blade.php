<ul>

    <li class="" style="margin-bottom: -33px;">
        <p class="new-arrival-icon">New</p>

        <a href="https://sohojbuy.com/category/electric-electronics"> <span class="ms-2">New Arrival</span>    </a>
    </li>
    <li class="" style="margin-to: -3px;">
        <p  class="new-arrival-icon" style="background-color: #E20000">Hot</p>

        <a href="https://sohojbuy.com/category/electric-electronics"><span class="ms-2">Hot Sale </span>   </a>
    </li>
    <li class="">
        <img src="{{url('/')}}/images/ICON/My Offers-01 1.png" width="40" class="img-fluid desktop-left-menu-picture">

        <a href="https://sohojbuy.com/category/electric-electronics">My Offers </a>
    </li>


    @for($i=0;$i<10;$i++)

        <li class=" ">
            <img src="{{url('/')}}/images/ICON/music_sound.svg" width="40" class="img-fluid desktop-left-menu-picture">

            <a href="https://sohojbuy.com/category/electric-electronics">Smartphone Collections</a>
            <span class="right-main-menu-icon"><i class="fal fa-chevron-right"></i></span>
            <ul class="sub-menu-ul">
                <li class="">
                    <a href="https://sohojbuy.com/category/gadget">Gadget </a>
                </li>
                <li class="">
                    <a href="https://sohojbuy.com/category/powerpoints-switches--savers">Powerpoints Switches  </a>
                </li>
            </ul>
        </li>


        @endfor
    <li style="padding-top:10px"><a>Take Guide</a></li>
    <li><a>Our Shops</a></li>
    <li><a>How to Purchase  </a></li>
    <li><a>Why GadgetEx</a></li>
    <li><a>All Polices </a></li>

</ul>
