<div class="mobile-header-top">

<div class="top_itm text-center">

    <div>

        <img  src="{{asset('images/mobileicon/Logo.png')}}">
    
    </div>

    <div class="hom_icon">

        <i class="fas fa-bars"></i>
         <p>Menu</p>

     </div>




    <div>

       

    <!-- <div class="hom_icon">

    <i class="fas fa-home"></i>

    <br>

    <small>Home</small>

    </div> -->
    
    </div>


     <div class="hom_icon">

       <i class="far fa-user"></i>
         <p>Account</p>

     </div>

   

   <div class="hom_icon top_inc">
       <i class="far fa-heart"></i>
         <p>Wishist</p>
         <div class="incr">10</div>

     </div>

   <div style="margin-right: 23px;" class="hom_icon top_inc">
      <i class="fas fa-cart-arrow-down"></i>
         <p> Cart</p>
         <div class="incrc">10</div>
     </div>

</div>

   

</div>

<div class="container">
    
        <form style="box-shadow: inset -33px 0px 36px rgba(0, 0, 0, 0.3);" action="https://sohojbuy.com/search" method="get" class="search_bar">
                    <div class="input-group mt-3">
                        <input style="height: 40px;" type="text" name="search" required="" class="form-control searchbox desktop-search-field" placeholder="Search For Products">
                        <div class="input-group-append wind">
                          <i class="fas fa-search"></i>
                        </div>
                    </div>
                    <ul class="desktop-search-menu">
                    </ul>
                </form>

</div>
    

