<!-- <div class="row desktop-header-top ps-5">
    <div class="col-lg-3 col-xl-3 d-flex flex-row">
        <img src="{{url('/')}}/images/Icon/logo.svg"   class="img-fluid" style="width: 100%;height: 57px;margin-top: 11px;"/>

    </div>
    <div class="col-lg-4 col-xl-4 d-flex flex-row">
        <img src="{{url('/')}}/images/Icon/Call Center 1.png"   class="img-fluid support-picture-desktop" />
        <p class="mt-3 ms-2">Care | +880 1726 003 324</p>
        <img src="{{url('/')}}/images/Icon/eMail 1.png" width="30" class="img-fluid support-picture-desktop ms-3"/>
        <p class="mt-3 ms-2">eMail | support@gadgetex.com.bd</p>
    </div>
    <div class="col-lg-2 col-xl-2 d-flex flex-row">
        <img src="{{url('/')}}/images/Icon/Support Icon 1.png"   class="img-fluid support-picture-desktop"/>
        <p class="support-para">Online |</p>
        <img src="{{url('/')}}/images/Icon/facebook.png"   class="img-fluid support-picture-desktop"/>
        <img src="{{url('/')}}/images/Icon/youtube.png"   class="img-fluid support-picture-desktop"/>
        <img src="{{url('/')}}/images/Icon/whatsapp.png"   class="img-fluid support-picture-desktop"/>
        <img src="{{url('/')}}/images/Icon/imo.png"  class="img-fluid support-picture-desktop"/>

    </div>
    <div class="col-lg-3 col-xl-3 d-flex flex-row">
        <img src="{{url('/')}}/images/Icon/My Offers-01 1.png"  class="img-fluid support-picture-desktop"/>
        <img src="{{url('/')}}/images/Icon/My Offers.png"  class="img-fluid header-offer-piture"/>
        <img src="{{url('/')}}/images/Icon/Capture 4.png"  class="img-fluid" style="height: 47px;margin-top: 8px;"/>
        <img src="{{url('/')}}/images/Icon/Take Guide.png"  class="img-fluid support-picture-desktopf" style="width: 100%;height: 22px;
margin-top: 19px;"/>

    </div>

</div> -->


<div class="desktop-header-top">

    <div class="main_banner_div">
        
        <div class="nav_box">
                
                <div class="logo_box">
                    
                    <img style="width: 150%" src="{{asset('/images/ICON/logo.svg')}}" class="img-fluid">

                </div>

                <div style="width: 40%;" class="d-flex nav_img_snd">

                     <img style="width: 5%; height: 5%;" src="{{url('/')}}/images/ICON/Call Center 1.png"   class="mt-1 img-fluid" />
        <p style="font-size: 12px;font-weight: 400;" class="ms-2 mt-1">Care | +880 1726 003 324</p>
        
        <img style="width: 5%; height: 5%;" src="{{url('/')}}/images/ICON/eMail 1.png"   class="img-fluid ms-2 mt-1" />
        <p style="font-size: 12px;font-weight: 400;" class="ms-2 me-2 mt-1">eMail | support@gadgetex.com.bd</p> 


                    
                </div>


            <div class="d-flex">



              
            <img src="{{url('/')}}/images/ICON/Support Icon 1.png"   class="img-fluid support-picture-desktop"/>
        <p class="support-para" style="font-size: 15px;font-weight: 500;"><span style="display: flex;">Online</span></p> 
    
       
        <img src="{{url('/')}}/images/ICON/youtube.png"   class="img-fluid support-picture-desktop"/>
        <img src="{{url('/')}}/images/ICON/whatsapp.png"   class="img-fluid support-picture-desktop"/>
        <img src="{{url('/')}}/images/ICON/imo.png"  class="img-fluid support-picture-desktop"/>
                


            </div>


             <div class="d-flex last_nav_div">


            <img style="width: 10%;height: 10%; margin-top: 25px;" src="{{url('/')}}/images/ICON/My Offers-01 1.png"  class=" img-fluid support-picture-desktop"/>
        <img style="width: 20%;height: 20%; margin-top: 30px;" src="{{url('/')}}/images/ICON/My Offers.png"  class="img-fluid header-offer-piture"/>
        <img style="width: 20%;height: 20%; margin-top: 10px;" src="{{url('/')}}/images/ICON/Capture 4.png"  class="img-fluid"/>
        <img style="width: 30%;height: 30%; margin-top: 30px" src="{{url('/')}}/images/ICON/Take Guide.png"  class="img-fluid " />
                


            </div>


               

              

               

        </div>

    </div>
    

</div>