<div class="container">
<div class="desktop-header-top">
    <div class="main_banner_div">
        
        <div class="row">
            <div class="col-lg-3"> 
                <div class="logo_box" style="cursor: pointer" onclick="location.href='{{url('/')}}';" >
                    <img src="{{asset('/images/ICON/logo.svg')}}" class="img-fluid">
                </div>
            </div>
                <div  class="d-flex col-lg-4 nav_img_snd">

                     <img style="width: 25px;height: 23px;" src="{{url('/')}}/images/ICON/Call Center 1.png"   class="mt-1 img-fluid" />
        <p style="font-size: 12px;font-weight: 400;" class="ms-2 mt-1">+880 1726 003 324</p>
        
        <img src="{{url('/')}}/images/ICON/eMail 1.png"   class="img-fluid ms-2 mt-1" />
        <p style="font-size: 12px;font-weight: 400;" class="ms-2 me-2 mt-1">support@gadgetex.com.bd</p> 
   </div>

    <div class="col-lg-2"> 
        <ul class="socialli">
        <div class="d-flex flex-row justify-content-center soci">
                       <a class="solik" href="http://"> <i class="fab fa-facebook-square  social-padding-of-single-product"></i></a>
                        <!-- <a class="solik" style="color: #833AB4;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-instagram  social-padding-of-single-product"></i></a> -->
                        <a class="solik" style="color:#25D366;" href="http://" target="_blank" rel="noopener noreferrer"><i class="fab fa-whatsapp  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color:red;" href="http://" target="_blank" rel="noopener noreferrer"><i class="fab fa-youtube  social-padding-of-single-product"></i></a>
                        <!-- <a class="solik" style="color:#2867B2;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-linkedin  social-padding-of-single-product "></i></a> -->
                       <!-- <a class="solik" style="color:#1DA1F2;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-twitter  social-padding-of-single-product"></i></a> -->
         </div>
        </ul>       
    </div>


    <div class=" last_nav_div col-lg-3">
        <div style="padding-top: 25px;text-align: right;" class="myofferguide">
        <a href="{{url('/')}}/order-tracking" class="btn trackorder"><img style="width: 24px;height: 18px;"  src="{{url('/')}}/images/ICON/tracorder.png"  class=" img-fluid support-picture-desktop"/> Track Order</a>
        <a href="{{url('/myoffer')}}" class="btn myoffer"> <img  src="{{url('/')}}/images/ICON/My Offers-01 1.png"  class=" img-fluid support-picture-desktop"/> My Offer</a>
       
        <!-- <img style="width: 81px;" onclick="location.href='{{url('/takeguide')}}';" src="{{url('/')}}/images/ICON/Take Guide.png"  class="img-fluid " /> -->
        <a class="btn takeguide" onclick="location.href='{{url('/takeguide')}}';"> <img   src="{{url('/')}}/images/ICON/Capture-4.png"  class="img-fluid"/> Take Guide</a>
    </div>
    </div>


    </div>
    

</div>
</div>  