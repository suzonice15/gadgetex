
<div class="desktop-header-top">
    <div class="main_banner_div">
        
        <div class="nav_box">
            <div class="col-lg-3"> 
                <div class="logo_box" style="cursor: pointer" onclick="location.href='{{url('/')}}';" >
                    <img src="{{asset('/images/ICON/logo.svg')}}" class="img-fluid">
                </div>
            </div>
                <div  class="d-flex col-lg-4 nav_img_snd">

                     <img style="width: 5%; height: 5%;" src="{{url('/')}}/images/ICON/Call Center 1.png"   class="mt-1 img-fluid" />
        <p style="font-size: 12px;font-weight: 400;" class="ms-2 mt-1">Care | +880 1726 003 324</p>
        
        <img style="width: 5%; height: 5%;" src="{{url('/')}}/images/ICON/eMail 1.png"   class="img-fluid ms-2 mt-1" />
        <p style="font-size: 12px;font-weight: 400;" class="ms-2 me-2 mt-1">eMail | support@gadgetex.com.bd</p> 
   </div>

    <div class="col-lg-2"> 
        <ul class="socialli">
        <div class="d-flex flex-row justify-content-center ">
                       <a class="solik" href="http://"> <i class="fab fa-facebook-square  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color: #833AB4;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-instagram  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color:#25D366;" href="http://" target="_blank" rel="noopener noreferrer"><i class="fab fa-whatsapp  social-padding-of-single-product"></i></a>
                        <a class="solik" style="color:#2867B2;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-linkedin  social-padding-of-single-product "></i></a>
                       <a class="solik" style="color:#1DA1F2;" href="http://" target="_blank" rel="noopener noreferrer"> <i class="fab fa-twitter  social-padding-of-single-product"></i></a>
         </div>
        </ul>       
    </div>


    <div class=" last_nav_div col-lg-3">
        <img  src="{{url('/')}}/images/ICON/My Offers-01 1.png"  class=" img-fluid support-picture-desktop"/>
        <a href="{{url('/myoffer')}}" class="btn myoffer">My Offer</a>
        <img style="width:21px;"  src="{{url('/')}}/images/ICON/Capture-4.png"  class="img-fluid"/>
        <img style="width: 81px;" src="{{url('/')}}/images/ICON/Take Guide.png"  class="img-fluid " />
    </div>


    </div>
    

</div>