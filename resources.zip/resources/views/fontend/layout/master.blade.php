@include('fontend.partial.header')

@yield('content')

@include('fontend.partial.footer')