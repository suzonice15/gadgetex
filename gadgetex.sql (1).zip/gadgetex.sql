-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2021 at 12:07 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gadgetex`
--

-- --------------------------------------------------------

--
-- Table structure for table `adds`
--

CREATE TABLE `adds` (
  `adds_id` int(11) NOT NULL,
  `adds_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adds_link` varchar(555) COLLATE utf8_unicode_ci DEFAULT '#',
  `media_path` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `adds_type` varchar(7) COLLATE utf8_unicode_ci DEFAULT 'sidebar',
  `created_time` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` bigint(20) NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `user_phone` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `picture` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registered_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `user_phone`, `email`, `password`, `status`, `picture`, `registered_date`) VALUES
(2147483647, 'Rakibul islam', NULL, 'a@gmail.com', 'c4ca4238a0b923820dcc509a6f75849badmin', 'super-admin', '1594709609.jpg', '2020-07-02'),
(2147483651, 'jibonpata', '01911504116', 'jibonpatait.ltd@gmail.com', 'c33367701511b4f6020ec61ded352059admin', 'super-admin', '1638790194.png', '2021-12-06'),
(2147483652, 'soikot vai', '01738/305670', 'soikot@gmail.com', 'c4ca4238a0b923820dcc509a6f75849badmin', 'admin', '1639139064.png', '2021-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE `advertisement` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  `create_date` date NOT NULL,
  `order_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advertisement`
--

INSERT INTO `advertisement` (`id`, `title`, `image`, `link`, `create_date`, `order_by`) VALUES
(7, 'yuytut', '7_banner_.jpg', 'utyuytut', '2021-12-16', 676),
(9, 'ddsfdsf', 'uploads/advertisement/9_banner_.png', 'http://127.0.0.1:8000/realme-8-5g-354-30-30', '2021-12-16', 2),
(10, 'camere', 'uploads/advertisement/10_banner_.png', 'http://127.0.0.1:8000/t17-trimmer-510-78-78', '2021-12-16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_coupon_code`
--

CREATE TABLE `affiliate_coupon_code` (
  `id` bigint(20) NOT NULL,
  `affiliate_id` bigint(20) NOT NULL,
  `product_id` int(11) NOT NULL,
  `coupon_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `coupon_code` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `expire_date` date NOT NULL,
  `discount` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `affiliate_coupon_code`
--

INSERT INTO `affiliate_coupon_code` (`id`, `affiliate_id`, `product_id`, `coupon_name`, `coupon_code`, `expire_date`, `discount`, `created_at`) VALUES
(6, 1, 1149, 'watch', 'sujon', '2021-11-27', 30, '2021-08-29 20:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `bands`
--

CREATE TABLE `bands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_link` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_banner` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_seo_title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_seo_keyword` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_seo_content` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bands`
--

INSERT INTO `bands` (`brand_id`, `brand_name`, `brand_link`, `brand_banner`, `brand_seo_title`, `brand_seo_keyword`, `brand_seo_content`, `created_at`) VALUES
(2, 'Vivo', 'are-you-good-boy', NULL, 'dfdfd', 'fdfds', 'dfdsfds', '2021-12-04'),
(4, 'Apple', 'apple', '41638621030.png', 'dfdfd x', 'fdfds  x', 'dfdfd df  x', '2021-12-04'),
(5, 'Hp', 'hp', NULL, NULL, NULL, NULL, '2021-12-04'),
(6, 'Hp', 'hp', NULL, NULL, NULL, NULL, '2021-12-04'),
(7, 'Samsung', 'samsung', '7_banner_.png', NULL, NULL, NULL, '2021-12-04'),
(8, 'Robi', 'robi', '8_banner_.png', NULL, NULL, NULL, '2021-12-04'),
(9, 'Walton', 'walton', '9_banner_.png', NULL, NULL, NULL, '2021-12-04');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `share_image` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `medium_banner` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_icon` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_title` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `category_name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `rank_order` int(11) DEFAULT 0,
  `seo_title` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_meta_title` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_keywords` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_meta_content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `registered_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `share_image`, `medium_banner`, `category_icon`, `category_title`, `category_name`, `parent_id`, `status`, `rank_order`, `seo_title`, `seo_meta_title`, `seo_keywords`, `seo_content`, `seo_meta_content`, `registered_date`) VALUES
(3, NULL, '31639379768.jpg', '31639379768.png', 'Sound & Music Gadgets', 'sound--music-gadgets', 0, 1, 5, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(4, NULL, '41639379630.jpg', '41639379630.png', 'Smartwatch Gadgets', 'smartwatch-gadgets', 0, 1, 6, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(5, NULL, '51639379577.jpg', '51639379577.png', 'Powerbank Gadgets', 'powerbank-gadgets', 0, 1, 7, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(6, NULL, '61639379552.jpg', '61639379552.png', 'Charger & Adapter Gadgets', 'charger--adapter-gadgets', 0, 1, 8, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(7, NULL, '71639379508.jpg', '71639379508.png', 'Camera Gadgets', 'camera-gadgets', 0, 1, 9, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(8, NULL, '81639379480.jpg', '81639379480.png', 'Computer Gadgets', 'computer-gadgets', 0, 1, 10, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(9, NULL, '91639379439.jpg', '91639379439.png', 'Essential Gadgets', 'essential-gadgets', 0, 1, 11, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(10, NULL, '101639379277.jpg', '101639379277.png', 'Exchange Smartphones', 'exchange-smartphones', 0, 1, 12, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(11, NULL, '111639379887.jpg', '111639379887.png', 'Smartphone Collections', 'smartphone-collections', 0, 1, 1, NULL, NULL, NULL, NULL, NULL, '2021-12-13 00:00:00'),
(12, 'public/uploads/category/121639380020.jpg', '121639379938.jpg', '121639379938.png', 'Tablet Collections', 'tablet-collections', 0, 1, 4, NULL, NULL, NULL, NULL, NULL, '2021-12-14 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courier`
--

CREATE TABLE `courier` (
  `courier_id` int(11) NOT NULL,
  `courier_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `courier_status` tinyint(4) NOT NULL COMMENT '1 for inside 2 outside',
  `created_time` datetime NOT NULL,
  `active` tinyint(4) DEFAULT 0 COMMENT '1 active 0 inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `courier`
--

INSERT INTO `courier` (`courier_id`, `courier_name`, `courier_status`, `created_time`, `active`) VALUES
(2, 'sundarban courier', 2, '2020-07-15 07:29:35', 0),
(3, 'sundarban courier', 1, '2020-07-15 07:29:44', 0),
(4, 's a paribahan courier', 1, '2020-07-15 07:30:28', 0),
(5, 's a paribahan courier', 2, '2020-07-15 07:30:45', 0),
(13, 'করতোয়া কুরিয়ার সার্ভিস', 2, '2020-11-10 12:51:58', 0),
(16, 'Virtual products |GGFGF', 1, '2021-08-17 01:47:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(10) UNSIGNED NOT NULL,
  `division_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bn_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `division_id`, `name`, `bn_name`, `lat`, `lon`, `website`) VALUES
(1, 3, 'Dhaka', 'ঢাকা', 23.7115253, 90.4111451, 'www.dhaka.gov.bd'),
(2, 3, 'Faridpur', 'ফরিদপুর', 23.6070822, 89.8429406, 'www.faridpur.gov.bd'),
(3, 3, 'Gazipur', 'গাজীপুর', 24.0022858, 90.4264283, 'www.gazipur.gov.bd'),
(4, 3, 'Gopalganj', 'গোপালগঞ্জ', 23.0050857, 89.8266059, 'www.gopalganj.gov.bd'),
(5, 8, 'Jamalpur', 'জামালপুর', 24.937533, 89.937775, 'www.jamalpur.gov.bd'),
(6, 3, 'Kishoreganj', 'কিশোরগঞ্জ', 24.444937, 90.776575, 'www.kishoreganj.gov.bd'),
(7, 3, 'Madaripur', 'মাদারীপুর', 23.164102, 90.1896805, 'www.madaripur.gov.bd'),
(8, 3, 'Manikganj', 'মানিকগঞ্জ', 0, 0, 'www.manikganj.gov.bd'),
(9, 3, 'Munshiganj', 'মুন্সিগঞ্জ', 0, 0, 'www.munshiganj.gov.bd'),
(10, 8, 'Mymensingh', 'ময়মনসিংহ', 0, 0, 'www.mymensingh.gov.bd'),
(11, 3, 'Narayanganj', 'নারায়াণগঞ্জ', 23.63366, 90.496482, 'www.narayanganj.gov.bd'),
(12, 3, 'Narsingdi', 'নরসিংদী', 23.932233, 90.71541, 'www.narsingdi.gov.bd'),
(13, 8, 'Netrokona', 'নেত্রকোণা', 24.870955, 90.727887, 'www.netrokona.gov.bd'),
(14, 3, 'Rajbari', 'রাজবাড়ি', 23.7574305, 89.6444665, 'www.rajbari.gov.bd'),
(15, 3, 'Shariatpur', 'শরীয়তপুর', 0, 0, 'www.shariatpur.gov.bd'),
(16, 8, 'Sherpur', 'শেরপুর', 25.0204933, 90.0152966, 'www.sherpur.gov.bd'),
(17, 3, 'Tangail', 'টাঙ্গাইল', 0, 0, 'www.tangail.gov.bd'),
(18, 5, 'Bogura', 'বগুড়া', 24.8465228, 89.377755, 'www.bogra.gov.bd'),
(19, 5, 'Joypurhat', 'জয়পুরহাট', 0, 0, 'www.joypurhat.gov.bd'),
(20, 5, 'Naogaon', 'নওগাঁ', 0, 0, 'www.naogaon.gov.bd'),
(21, 5, 'Natore', 'নাটোর', 24.420556, 89.000282, 'www.natore.gov.bd'),
(22, 5, 'Chapainawabganj', 'চাঁপাইনবাবগঞ্জ', 24.5965034, 88.2775122, 'www.chapainawabganj.gov.bd'),
(23, 5, 'Pabna', 'পাবনা', 23.998524, 89.233645, 'www.pabna.gov.bd'),
(24, 5, 'Rajshahi', 'রাজশাহী', 0, 0, 'www.rajshahi.gov.bd'),
(25, 5, 'Sirajgonj', 'সিরাজগঞ্জ', 24.4533978, 89.7006815, 'www.sirajganj.gov.bd'),
(26, 6, 'Dinajpur', 'দিনাজপুর', 25.6217061, 88.6354504, 'www.dinajpur.gov.bd'),
(27, 6, 'Gaibandha', 'গাইবান্ধা', 25.328751, 89.528088, 'www.gaibandha.gov.bd'),
(28, 6, 'Kurigram', 'কুড়িগ্রাম', 25.805445, 89.636174, 'www.kurigram.gov.bd'),
(29, 6, 'Lalmonirhat', 'লালমনিরহাট', 0, 0, 'www.lalmonirhat.gov.bd'),
(30, 6, 'Nilphamari', 'নীলফামারী', 25.931794, 88.856006, 'www.nilphamari.gov.bd'),
(31, 6, 'Panchagarh', 'পঞ্চগড়', 26.3411, 88.5541606, 'www.panchagarh.gov.bd'),
(32, 6, 'Rangpur', 'রংপুর', 25.7558096, 89.244462, 'www.rangpur.gov.bd'),
(33, 6, 'Thakurgaon', 'ঠাকুরগাঁও', 26.0336945, 88.4616834, 'www.thakurgaon.gov.bd'),
(34, 1, 'Barguna', 'বরগুনা', 0, 0, 'www.barguna.gov.bd'),
(35, 1, 'Barishal', 'বরিশাল', 0, 0, 'www.barisal.gov.bd'),
(36, 1, 'Bhola', 'ভোলা', 22.685923, 90.648179, 'www.bhola.gov.bd'),
(37, 1, 'Jhalokati', 'ঝালকাঠি', 0, 0, 'www.jhalakathi.gov.bd'),
(38, 1, 'Patuakhali', 'পটুয়াখালী', 22.3596316, 90.3298712, 'www.patuakhali.gov.bd'),
(39, 1, 'Pirojpur', 'পিরোজপুর', 0, 0, 'www.pirojpur.gov.bd'),
(40, 2, 'Bandarban', 'বান্দরবান', 22.1953275, 92.2183773, 'www.bandarban.gov.bd'),
(41, 2, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 23.9570904, 91.1119286, 'www.brahmanbaria.gov.bd'),
(42, 2, 'Chandpur', 'চাঁদপুর', 23.2332585, 90.6712912, 'www.chandpur.gov.bd'),
(43, 2, 'Chattogram', 'চট্টগ্রাম', 22.335109, 91.834073, 'www.chittagong.gov.bd'),
(44, 2, 'Cumilla', 'কুমিল্লা', 23.4682747, 91.1788135, 'www.comilla.gov.bd'),
(45, 2, 'Cox\'s Bazar', 'কক্স বাজার', 0, 0, 'www.coxsbazar.gov.bd'),
(46, 2, 'Feni', 'ফেনী', 23.023231, 91.3840844, 'www.feni.gov.bd'),
(47, 2, 'Khagrachhari', 'খাগড়াছড়ি', 23.119285, 91.984663, 'www.khagrachhari.gov.bd'),
(48, 2, 'Lakshmipur', 'লক্ষ্মীপুর', 22.942477, 90.841184, 'www.lakshmipur.gov.bd'),
(49, 2, 'Noakhali', 'নোয়াখালী', 22.869563, 91.099398, 'www.noakhali.gov.bd'),
(50, 2, 'Rangamati', 'রাঙ্গামাটি', 0, 0, 'www.rangamati.gov.bd'),
(51, 7, 'Habiganj', 'হবিগঞ্জ', 24.374945, 91.41553, 'www.habiganj.gov.bd'),
(52, 7, 'Moulvibazar', 'মৌলভীবাজার', 24.482934, 91.777417, 'www.moulvibazar.gov.bd'),
(53, 7, 'Sunamganj', 'সুনামগঞ্জ', 25.0658042, 91.3950115, 'www.sunamganj.gov.bd'),
(54, 7, 'Sylhet', 'সিলেট', 24.8897956, 91.8697894, 'www.sylhet.gov.bd'),
(55, 4, 'Bagerhat', 'বাগেরহাট', 22.651568, 89.785938, 'www.bagerhat.gov.bd'),
(56, 4, 'Chuadanga', 'চুয়াডাঙ্গা', 23.6401961, 88.841841, 'www.chuadanga.gov.bd'),
(57, 4, 'Jashore', 'যশোর', 23.16643, 89.2081126, 'www.jessore.gov.bd'),
(58, 4, 'Jhenaidah', 'ঝিনাইদহ', 23.5448176, 89.1539213, 'www.jhenaidah.gov.bd'),
(59, 4, 'Khulna', 'খুলনা', 22.815774, 89.568679, 'www.khulna.gov.bd'),
(60, 4, 'Kushtia', 'কুষ্টিয়া', 23.901258, 89.120482, 'www.kushtia.gov.bd'),
(61, 4, 'Magura', 'মাগুরা', 23.487337, 89.419956, 'www.magura.gov.bd'),
(62, 4, 'Meherpur', 'মেহেরপুর', 23.762213, 88.631821, 'www.meherpur.gov.bd'),
(63, 4, 'Narail', 'নড়াইল', 23.172534, 89.512672, 'www.narail.gov.bd'),
(64, 4, 'Satkhira', 'সাতক্ষীরা', 0, 0, 'www.satkhira.gov.bd');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bn_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `name`, `bn_name`) VALUES
(1, 'Barishal', 'বরিশাল'),
(2, 'Chattogram', 'চট্টগ্রাম'),
(3, 'Dhaka', 'ঢাকা'),
(4, 'Khulna', 'খুলনা'),
(5, 'Rajshahi', 'রাজশাহী'),
(6, 'Rangpur', 'রংপুর'),
(7, 'Sylhet', 'সিলেট'),
(8, 'Mymensingh', 'ময়মনসিংহ');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `expense_id` int(11) NOT NULL,
  `expense_type` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `expense_title` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `expense_total` float DEFAULT NULL,
  `expense_data` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `expense_summary` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `expense_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_category`
--

CREATE TABLE `expense_category` (
  `expense_cat_id` int(11) NOT NULL,
  `expense_cat_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hitcounter`
--

CREATE TABLE `hitcounter` (
  `hitcounter_id` int(11) NOT NULL,
  `client_ip` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `platform` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `agent` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `homeslider`
--

CREATE TABLE `homeslider` (
  `homeslider_id` int(11) NOT NULL,
  `homeslider_title` varchar(555) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#',
  `homeslider_text` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `target_url` varchar(555) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#',
  `homeslider_picture` varchar(555) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `inquiry_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(555) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `media_id` int(11) NOT NULL,
  `media_title` varchar(555) COLLATE utf8_unicode_ci DEFAULT '#',
  `product_code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `media_path` varchar(555) COLLATE utf8_unicode_ci NOT NULL,
  `media_type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(1, 'test', 'SB0001', 'uploads/2/2.buy-facebook-groups-1000-members.png', 'featured_image', 2, '2021-12-08 20:52:02', '2021-12-08 20:52:02'),
(2, 'ddd', 'SB0002', 'uploads/3/3.Screenshot_1.png', 'featured_image', 3, '2021-12-08 20:57:15', '2021-12-08 20:57:15'),
(3, 'tretert', 'SB0001', 'uploads/4/4.buy-facebook-groups-1000-members.png', 'featured_image', 4, '2021-12-08 21:00:02', '2021-12-08 21:00:02'),
(4, 'Samsung A32 (4GB | 64GB)', 'SB0001', 'uploads/5/5.A32-10.jpg', 'featured_image', 5, '2021-12-09 18:08:56', '2021-12-09 18:08:56'),
(5, 'Samsung Note 20 Ultra', 'SB0004', 'uploads/5/23.ssfsF.jpg', 'galary_image1', 5, '2021-12-09 12:51:26', '2021-12-09 12:51:26'),
(6, 'Samsung Note 20 Ultra', 'SB0004', 'uploads/5/42.fsdfdsf.jpg', 'galary_image2', 5, '2021-12-09 12:51:26', '2021-12-09 12:51:26'),
(7, 'Samsung Note 20 Ultra', 'SB0004', 'uploads/5/81.111.jpg', 'galary_image3', 5, '2021-12-09 12:51:26', '2021-12-09 12:51:26'),
(8, 'Samsung Note 20 Ultra', 'SB0004', 'uploads/5/72.222.jpg', 'galary_image4', 5, '2021-12-09 12:51:26', '2021-12-09 12:51:26'),
(9, 'Samsung Note 20 Ultra', 'SB0004', 'uploads/5/21.222.jpg', 'galary_image5', 5, '2021-12-09 12:51:26', '2021-12-09 12:51:26'),
(10, 'Samsung Note 20 Ultra', 'SB0004', 'uploads/5/37.333.jpg', 'galary_image6', 5, '2021-12-09 12:51:26', '2021-12-09 12:51:26'),
(11, 'dfdfd', 'SB0005', 'uploads/6/6.60007584_303 (1).jpg', 'featured_image', 6, '2021-12-09 13:19:00', '2021-12-09 13:19:00'),
(12, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/7.dzdgz.jpg', 'featured_image', 7, '2021-12-09 13:22:00', '2021-12-09 13:22:00'),
(13, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/63.ssfsF.jpg', 'galary_image1', 7, '2021-12-09 13:22:00', '2021-12-09 13:22:00'),
(14, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/60.fsdfdsf.jpg', 'galary_image2', 7, '2021-12-09 13:22:01', '2021-12-09 13:22:01'),
(15, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/33.111.jpg', 'galary_image3', 7, '2021-12-09 13:22:01', '2021-12-09 13:22:01'),
(16, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/22.222.jpg', 'galary_image4', 7, '2021-12-09 13:22:01', '2021-12-09 13:22:01'),
(17, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/75.222.jpg', 'galary_image5', 7, '2021-12-09 13:22:01', '2021-12-09 13:22:01'),
(18, 'Samsung Galaxy Note 20 Ultra', 'SB0004', 'uploads/7/98.333.jpg', 'galary_image6', 7, '2021-12-09 13:22:01', '2021-12-09 13:22:01'),
(19, 'A1 Powerbank', 'SB0007', 'uploads/8/8.Powerbank (4).png', 'featured_image', 8, '2021-12-10 14:20:05', '2021-12-10 14:20:05'),
(20, 'Samsung Z Flip 3', 'SB0007', 'uploads/8/19.Z Flip3-01.jpg', 'galary_image1', 8, '2021-12-09 17:34:35', '2021-12-09 17:34:35'),
(21, 'Samsung Z Flip 3', 'SB0007', 'uploads/8/87.Z Flip3-02.jpg', 'galary_image2', 8, '2021-12-09 17:34:35', '2021-12-09 17:34:35'),
(22, 'Samsung Z Flip 3', 'SB0007', 'uploads/8/28.Z Flip3-03.jpg', 'galary_image3', 8, '2021-12-09 17:34:35', '2021-12-09 17:34:35'),
(23, 'Samsung Z Flip 3', 'SB0007', 'uploads/8/62.Z Flip3-04.jpg', 'galary_image4', 8, '2021-12-09 17:34:35', '2021-12-09 17:34:35'),
(24, 'Samsung Z Flip 3', 'SB0007', 'uploads/8/10.Z Flip3-05.jpg', 'galary_image5', 8, '2021-12-09 17:34:35', '2021-12-09 17:34:35'),
(25, 'Samsung Z Flip 3', 'SB0007', 'uploads/8/57.Z Flip3-08.jpg', 'galary_image6', 8, '2021-12-09 17:34:35', '2021-12-09 17:34:35'),
(26, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/9.A22-10.jpg', 'featured_image', 9, '2021-12-09 17:57:08', '2021-12-09 17:57:08'),
(27, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/60.A22-09.jpg', 'galary_image1', 9, '2021-12-09 17:57:09', '2021-12-09 17:57:09'),
(28, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/79.A22-02.jpg', 'galary_image2', 9, '2021-12-09 17:57:10', '2021-12-09 17:57:10'),
(29, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/21.A22-03.jpg', 'galary_image3', 9, '2021-12-09 17:57:11', '2021-12-09 17:57:11'),
(30, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/82.A22-08.jpg', 'galary_image4', 9, '2021-12-09 17:57:11', '2021-12-09 17:57:11'),
(31, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/45.A22-07.jpg', 'galary_image5', 9, '2021-12-09 17:57:11', '2021-12-09 17:57:11'),
(32, 'Samsung A21 (6GB | 128GB)', 'SB0009', 'uploads/9/20.A22-05.jpg', 'galary_image6', 9, '2021-12-09 17:57:12', '2021-12-09 17:57:12'),
(33, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/10.Smartwatch3-removebg-preview.png', 'featured_image', 10, '2021-12-10 12:58:43', '2021-12-10 12:58:43'),
(34, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/21.A52-09.jpg', 'galary_image1', 10, '2021-12-09 18:12:13', '2021-12-09 18:12:13'),
(35, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/76.A52-08.jpg', 'galary_image2', 10, '2021-12-09 18:12:13', '2021-12-09 18:12:13'),
(36, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/76.A52-01.jpg', 'galary_image3', 10, '2021-12-09 18:12:14', '2021-12-09 18:12:14'),
(37, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/20.A52-04.jpg', 'galary_image4', 10, '2021-12-09 18:12:15', '2021-12-09 18:12:15'),
(38, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/99.A52-02.jpg', 'galary_image5', 10, '2021-12-09 18:12:16', '2021-12-09 18:12:16'),
(39, 'Samsung A52 (4GB / 64GB)', 'SB00002', 'uploads/10/82.A52-03.jpg', 'galary_image6', 10, '2021-12-09 18:12:17', '2021-12-09 18:12:17'),
(40, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/11.A52S-10.jpg', 'featured_image', 11, '2021-12-09 18:16:34', '2021-12-09 18:16:34'),
(41, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/55.A52S-09.jpg', 'galary_image1', 11, '2021-12-09 18:16:35', '2021-12-09 18:16:35'),
(42, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/15.A52S-08.jpg', 'galary_image2', 11, '2021-12-09 18:16:35', '2021-12-09 18:16:35'),
(43, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/17.A52S-04.jpg', 'galary_image3', 11, '2021-12-09 18:16:36', '2021-12-09 18:16:36'),
(44, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/27.A52S-03.jpg', 'galary_image4', 11, '2021-12-09 18:16:37', '2021-12-09 18:16:37'),
(45, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/16.A52S-02.jpg', 'galary_image5', 11, '2021-12-09 18:16:38', '2021-12-09 18:16:38'),
(46, 'Samsung A52S (6GB / 64GB)', 'SB15', 'uploads/11/57.A52S-01.jpg', 'galary_image6', 11, '2021-12-09 18:16:39', '2021-12-09 18:16:39'),
(47, 'Samsung A72', 'SB0011', 'uploads/12/12.A72-10.jpg', 'featured_image', 12, '2021-12-09 18:19:42', '2021-12-09 18:19:42'),
(48, 'Samsung A72', 'SB0011', 'uploads/12/89.A72-09.jpg', 'galary_image1', 12, '2021-12-09 18:19:43', '2021-12-09 18:19:43'),
(49, 'Samsung A72', 'SB0011', 'uploads/12/73.A72-05.jpg', 'galary_image2', 12, '2021-12-09 18:19:44', '2021-12-09 18:19:44'),
(50, 'Samsung A72', 'SB0011', 'uploads/12/63.A72-02.jpg', 'galary_image3', 12, '2021-12-09 18:19:44', '2021-12-09 18:19:44'),
(51, 'Samsung A72', 'SB0011', 'uploads/12/15.A72-05.jpg', 'galary_image4', 12, '2021-12-09 18:19:45', '2021-12-09 18:19:45'),
(52, 'Samsung A72', 'SB0011', 'uploads/12/15.A72-08.jpg', 'galary_image5', 12, '2021-12-09 18:19:46', '2021-12-09 18:19:46'),
(53, 'Samsung A72', 'SB0011', 'uploads/12/94.A72-03.jpg', 'galary_image6', 12, '2021-12-09 18:19:47', '2021-12-09 18:19:47'),
(54, 'Samsung F22 best product (8/128GB)', 'GX0012', 'uploads/13/13.1420.download (1).jpg', 'featured_image', 13, '2021-12-26 19:53:16', '2021-12-26 19:53:16'),
(55, 'Samsung F22', 'SB0012', 'uploads/13/17.F22-06.jpg', 'galary_image1', 13, '2021-12-09 18:22:59', '2021-12-09 18:22:59'),
(56, 'Samsung F22', 'SB0012', 'uploads/13/77.F22-05.jpg', 'galary_image2', 13, '2021-12-09 18:23:00', '2021-12-09 18:23:00'),
(57, 'Samsung F22', 'SB0012', 'uploads/13/82.F22-02.jpg', 'galary_image3', 13, '2021-12-09 18:23:01', '2021-12-09 18:23:01'),
(58, 'Samsung F22', 'SB0012', 'uploads/13/100.F22-01.jpg', 'galary_image4', 13, '2021-12-09 18:23:02', '2021-12-09 18:23:02'),
(59, 'Samsung F22', 'SB0012', 'uploads/13/35.F22-04.jpg', 'galary_image5', 13, '2021-12-09 18:23:03', '2021-12-09 18:23:03'),
(60, 'ABCDE', 'SB0013', 'uploads/14/14.BS (7).png', 'featured_image', 14, '2021-12-10 12:57:21', '2021-12-10 12:57:21'),
(61, 'ABCDE', 'SB0013', 'uploads/14/92.M32-04.jpg', 'galary_image1', 14, '2021-12-09 18:37:01', '2021-12-09 18:37:01'),
(62, 'Powerbank', 'SB0014', 'uploads/15/15.Powerbank (3).png', 'featured_image', 15, '2021-12-09 18:39:50', '2021-12-09 18:39:50'),
(63, 'Powerbank', 'SB0014', 'uploads/15/52.Powerbank (4).png', 'galary_image1', 15, '2021-12-09 18:39:51', '2021-12-09 18:39:51'),
(64, 'Powerbank', 'SB0014', 'uploads/15/93.Powerbank (1).png', 'galary_image2', 15, '2021-12-09 18:39:51', '2021-12-09 18:39:51'),
(65, 'Charger A2', 'SB0015', 'uploads/16/16.Mobile_Adapter_2-removebg-preview.png', 'featured_image', 16, '2021-12-09 18:43:11', '2021-12-09 18:43:11'),
(66, 'Charger A2', 'SB0015', 'uploads/16/60.Mobile_Adapter_5-removebg-preview.png', 'galary_image1', 16, '2021-12-09 18:43:11', '2021-12-09 18:43:11'),
(67, 'Charger A2', 'SB0015', 'uploads/16/55.Mobile_Adapter_3-removebg-preview.png', 'galary_image2', 16, '2021-12-09 18:43:12', '2021-12-09 18:43:12'),
(68, 'Special Tripod', 'SB0016', 'uploads/17/17.selfie-tripod.jpg', 'featured_image', 17, '2021-12-10 15:36:46', '2021-12-10 15:36:46'),
(69, 'Valo Charger', 'SB0016', 'uploads/17/84.Mobile_Adapter_1-removebg-preview.png', 'galary_image1', 17, '2021-12-09 18:44:53', '2021-12-09 18:44:53'),
(70, 'Smartwatch 1', 'SB0017', 'uploads/18/18.Smartwatch2-removebg-preview.png', 'featured_image', 18, '2021-12-09 18:48:44', '2021-12-09 18:48:44'),
(71, 'Smartwatch 1', 'SB0017', 'uploads/18/23.Smartwatch-removebg-preview.png', 'galary_image1', 18, '2021-12-09 18:48:44', '2021-12-09 18:48:44'),
(72, 'Samsung A7 Tablet', 'SB0018', 'uploads/19/19.Tab A7 - 6.jpg', 'featured_image', 19, '2021-12-09 18:51:50', '2021-12-09 18:51:50'),
(73, 'Samsung A7 Tablet', 'SB0018', 'uploads/19/40.Tab A7 - 7.jpg', 'galary_image1', 19, '2021-12-09 18:51:51', '2021-12-09 18:51:51'),
(74, 'Samsung A7 Tablet', 'SB0018', 'uploads/19/61.Tab A7 - 8.jpg', 'galary_image2', 19, '2021-12-09 18:51:51', '2021-12-09 18:51:51'),
(75, 'Samsung A7 Lite', 'SB0019', 'uploads/20/20.Gray - Front.png', 'featured_image', 20, '2021-12-09 18:54:04', '2021-12-09 18:54:04'),
(76, 'Samsung A7 Lite', 'SB0019', 'uploads/20/63.Gray - Back.png', 'galary_image1', 20, '2021-12-09 18:54:04', '2021-12-09 18:54:04'),
(77, 'ABVC Tablet', 'SB0020', 'uploads/21/21.Tab A8 - 4.jpg', 'featured_image', 21, '2021-12-10 11:19:32', '2021-12-10 11:19:32'),
(78, 'ABVC Tablet', 'SB0020', 'uploads/21/81.Tab A8 - 3.jpg', 'galary_image1', 21, '2021-12-10 11:19:32', '2021-12-10 11:19:32'),
(79, 'ABVC Tablet', 'SB0020', 'uploads/21/58.Tab A8 - 3.jpg', 'galary_image2', 21, '2021-12-10 11:19:32', '2021-12-10 11:19:32'),
(80, 'XYZ Tablet', 'SB0021', 'uploads/22/22.Tab A7 - 1.jpg', 'featured_image', 22, '2021-12-10 11:21:46', '2021-12-10 11:21:46'),
(81, 'XYZ Tablet', 'SB0021', 'uploads/22/95.Tab A7 - 4.jpg', 'galary_image1', 22, '2021-12-10 11:21:46', '2021-12-10 11:21:46'),
(82, 'XYZ Tablet', 'SB0021', 'uploads/22/96.Tab A7 - 3.jpg', 'galary_image2', 22, '2021-12-10 11:21:46', '2021-12-10 11:21:46'),
(83, 'XYZ Tablet', 'SB0021', 'uploads/22/41.Tab A7 - 1.jpg', 'galary_image3', 22, '2021-12-10 11:21:47', '2021-12-10 11:21:47'),
(84, 'QRS Tablet', 'SB0022', 'uploads/23/23.Gray - Front.png', 'featured_image', 23, '2021-12-10 11:23:07', '2021-12-10 11:23:07'),
(85, 'QRS Tablet', 'SB0022', 'uploads/23/72.Gray - Side.png', 'galary_image1', 23, '2021-12-10 11:23:07', '2021-12-10 11:23:07'),
(86, 'QRS Tablet', 'SB0022', 'uploads/23/64.Gray - Back.png', 'galary_image2', 23, '2021-12-10 11:23:08', '2021-12-10 11:23:08'),
(87, 'PQS Tablet', 'SB0023', 'uploads/24/24.Tab A8 - 3.jpg', 'featured_image', 24, '2021-12-10 11:25:04', '2021-12-10 11:25:04'),
(88, 'PQS Tablet', 'SB0023', 'uploads/24/12.Tab A8 - 4.jpg', 'galary_image1', 24, '2021-12-10 11:25:04', '2021-12-10 11:25:04'),
(89, 'PQS Tablet', 'SB0023', 'uploads/24/17.Tab A8 - 5.jpg', 'galary_image2', 24, '2021-12-10 11:25:05', '2021-12-10 11:25:05'),
(90, 'DEF Tablet', 'SB0024', 'uploads/25/25.Tab A8 - 4.jpg', 'featured_image', 25, '2021-12-10 11:27:02', '2021-12-10 11:27:02'),
(91, 'DEF Tablet', 'SB0024', 'uploads/25/63.Tab A8 - 3.jpg', 'galary_image1', 25, '2021-12-10 11:27:02', '2021-12-10 11:27:02'),
(92, 'DEF Tablet', 'SB0024', 'uploads/25/51.Tab A8 - 1.jpg', 'galary_image2', 25, '2021-12-10 11:27:02', '2021-12-10 11:27:02'),
(93, 'Tablet T10', 'SB0025', 'uploads/26/26.Tab A8 - 6.jpg', 'featured_image', 26, '2021-12-10 11:28:30', '2021-12-10 11:28:30'),
(94, 'Tablet T10', 'SB0025', 'uploads/26/57.Tab A8 - 2.jpg', 'galary_image1', 26, '2021-12-10 11:28:30', '2021-12-10 11:28:30'),
(95, 'Tablet T10', 'SB0025', 'uploads/26/99.Tab A8 - 1.jpg', 'galary_image2', 26, '2021-12-10 11:28:30', '2021-12-10 11:28:30'),
(96, 'BCD Tablet', 'SB0026', 'uploads/27/27.Tab A7 - 2.jpg', 'featured_image', 27, '2021-12-10 11:34:43', '2021-12-10 11:34:43'),
(97, 'BCD Tablet', 'SB0026', 'uploads/27/56.Tab A7 - 8.jpg', 'galary_image1', 27, '2021-12-10 11:34:43', '2021-12-10 11:34:43'),
(98, 'BCD Tablet', 'SB0026', 'uploads/27/85.Tab A7 - 4.jpg', 'galary_image2', 27, '2021-12-10 11:34:43', '2021-12-10 11:34:43'),
(99, 'BCD Tablet', 'SB0026', 'uploads/27/93.Tab A7 - 5.jpg', 'galary_image3', 27, '2021-12-10 11:34:44', '2021-12-10 11:34:44'),
(100, 'BCD Tablet', 'SB0026', 'uploads/27/22.Tab A7 - 6.jpg', 'galary_image4', 27, '2021-12-10 11:34:44', '2021-12-10 11:34:44'),
(101, 'GadgetEX Tablet', 'SB0027', 'uploads/28/28.Tab A7 - 1.jpg', 'featured_image', 28, '2021-12-10 11:36:22', '2021-12-10 11:36:22'),
(102, 'GadgetEX Tablet', 'SB0027', 'uploads/28/26.Tab A7 - 4.jpg', 'galary_image1', 28, '2021-12-10 11:36:22', '2021-12-10 11:36:22'),
(103, 'GadgetEX Tablet', 'SB0027', 'uploads/28/77.Tab A7 - 6.jpg', 'galary_image2', 28, '2021-12-10 11:36:22', '2021-12-10 11:36:22'),
(104, 'GadgetEX Tablet', 'SB0027', 'uploads/28/61.Tab A7 - 1.jpg', 'galary_image3', 28, '2021-12-10 11:36:23', '2021-12-10 11:36:23'),
(105, 'GadgetEX Tablet', 'SB0027', 'uploads/28/33.Tab A7 - 5.jpg', 'galary_image4', 28, '2021-12-10 11:36:24', '2021-12-10 11:36:24'),
(106, 'Realme 8 4G', 'SB0028', 'uploads/29/29.Realme 8 4G-10.jpg', 'featured_image', 29, '2021-12-10 11:40:00', '2021-12-10 11:40:00'),
(107, 'Realme 8 4G', 'SB0028', 'uploads/29/96.Realme 8 4G-04.jpg', 'galary_image1', 29, '2021-12-10 11:40:01', '2021-12-10 11:40:01'),
(108, 'Realme 8 4G', 'SB0028', 'uploads/29/90.Realme 8 4G-02.jpg', 'galary_image2', 29, '2021-12-10 11:40:02', '2021-12-10 11:40:02'),
(109, 'Realme 8 4G', 'SB0028', 'uploads/29/52.Realme 8 4G-01.jpg', 'galary_image3', 29, '2021-12-10 11:40:03', '2021-12-10 11:40:03'),
(110, 'Realme 8 4G', 'SB0028', 'uploads/29/28.Realme 8 4G-02.jpg', 'galary_image4', 29, '2021-12-10 11:40:04', '2021-12-10 11:40:04'),
(111, 'Realme 8 5G', 'SB0029', 'uploads/30/30.Realme 8 5G-10.jpg', 'featured_image', 30, '2021-12-10 11:42:21', '2021-12-10 11:42:21'),
(112, 'Realme 8 5G', 'SB0029', 'uploads/30/59.Realme 8 5G-02.jpg', 'galary_image1', 30, '2021-12-10 11:42:22', '2021-12-10 11:42:22'),
(113, 'Realme 8 5G', 'SB0029', 'uploads/30/97.Realme 8 5G-03.jpg', 'galary_image2', 30, '2021-12-10 11:42:23', '2021-12-10 11:42:23'),
(114, 'Realme 8 5G', 'SB0029', 'uploads/30/15.Realme 8 5G-02.jpg', 'galary_image3', 30, '2021-12-10 11:42:24', '2021-12-10 11:42:24'),
(115, 'Realme 8 5G', 'SB0029', 'uploads/30/12.Realme 8 5G-03.jpg', 'galary_image4', 30, '2021-12-10 11:42:25', '2021-12-10 11:42:25'),
(116, 'OPPO Reno 6', 'SB0030', 'uploads/31/31.Capture 04.JPG', 'featured_image', 31, '2021-12-10 11:44:11', '2021-12-10 11:44:11'),
(117, 'OPPO Reno 6', 'SB0030', 'uploads/31/31.Capture 02.JPG', 'galary_image1', 31, '2021-12-10 11:44:11', '2021-12-10 11:44:11'),
(118, 'OPPO Reno 6', 'SB0030', 'uploads/31/91.Capture 05.JPG', 'galary_image2', 31, '2021-12-10 11:44:12', '2021-12-10 11:44:12'),
(119, 'OPPO Reno 6', 'SB0030', 'uploads/31/98.Capture 01.JPG', 'galary_image3', 31, '2021-12-10 11:44:12', '2021-12-10 11:44:12'),
(120, 'OPPO Reno 6', 'SB0030', 'uploads/31/31.Capture 02.JPG', 'galary_image4', 31, '2021-12-10 11:44:12', '2021-12-10 11:44:12'),
(121, 'OPPO Reno 6', 'SB0030', 'uploads/31/83.Capture 03.JPG', 'galary_image5', 31, '2021-12-10 11:44:12', '2021-12-10 11:44:12'),
(122, 'OPPO F19 Pro', 'SB0031', 'uploads/32/32.F19 Pro-10.jpg', 'featured_image', 32, '2021-12-10 11:45:48', '2021-12-10 11:45:48'),
(123, 'OPPO F19 Pro', 'SB0031', 'uploads/32/100.F19 Pro-04.jpg', 'galary_image1', 32, '2021-12-10 11:45:48', '2021-12-10 11:45:48'),
(124, 'OPPO F19 Pro', 'SB0031', 'uploads/32/46.F19 Pro-02.jpg', 'galary_image2', 32, '2021-12-10 11:45:49', '2021-12-10 11:45:49'),
(125, 'OPPO F19 Pro', 'SB0031', 'uploads/32/65.F19 Pro-01.jpg', 'galary_image3', 32, '2021-12-10 11:45:49', '2021-12-10 11:45:49'),
(126, 'OPPO F19 Pro', 'SB0031', 'uploads/32/24.F19 Pro-06.jpg', 'galary_image4', 32, '2021-12-10 11:45:49', '2021-12-10 11:45:49'),
(127, 'OPPO F19 Pro', 'SB0031', 'uploads/32/52.F19 Pro-09.jpg', 'galary_image5', 32, '2021-12-10 11:45:49', '2021-12-10 11:45:49'),
(128, 'OPPO F19 Pro', 'SB0031', 'uploads/32/100.F19 Pro-02.jpg', 'galary_image6', 32, '2021-12-10 11:45:49', '2021-12-10 11:45:49'),
(129, 'OPPO F19', 'SB0032', 'uploads/33/33.Prism Black.jpeg', 'featured_image', 33, '2021-12-10 11:48:11', '2021-12-10 11:48:11'),
(130, 'OPPO F19', 'SB0032', 'uploads/33/56.Untitled design (6).png', 'galary_image1', 33, '2021-12-10 11:48:15', '2021-12-10 11:48:15'),
(131, 'OPPO F19', 'SB0032', 'uploads/33/11.Midnight Blue 1.png', 'galary_image2', 33, '2021-12-10 11:48:16', '2021-12-10 11:48:16'),
(132, 'OPPO F19', 'SB0032', 'uploads/33/14.Untitled design (5).png', 'galary_image3', 33, '2021-12-10 11:48:20', '2021-12-10 11:48:20'),
(133, 'OPPO F19', 'SB0032', 'uploads/33/75.Untitled design (2).png', 'galary_image4', 33, '2021-12-10 11:48:23', '2021-12-10 11:48:23'),
(134, 'OPPO F19', 'SB0032', 'uploads/33/58.Midnight Blue 1.png', 'galary_image5', 33, '2021-12-10 11:48:24', '2021-12-10 11:48:24'),
(135, 'OPPO F19', 'SB0032', 'uploads/33/88.Untitled design (6).png', 'galary_image6', 33, '2021-12-10 11:48:28', '2021-12-10 11:48:28'),
(136, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/34.BS (10).png', 'featured_image', 34, '2021-12-10 12:04:48', '2021-12-10 12:04:48'),
(137, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/95.BS (11).png', 'galary_image1', 34, '2021-12-10 12:04:48', '2021-12-10 12:04:48'),
(138, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/68.BS (9).png', 'galary_image2', 34, '2021-12-10 12:04:48', '2021-12-10 12:04:48'),
(139, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/54.BS (8).png', 'galary_image3', 34, '2021-12-10 12:04:49', '2021-12-10 12:04:49'),
(140, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/98.BS (7).png', 'galary_image4', 34, '2021-12-10 12:04:49', '2021-12-10 12:04:49'),
(141, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/78.BS (6).png', 'galary_image5', 34, '2021-12-10 12:04:50', '2021-12-10 12:04:50'),
(142, 'A1 Bluetooth Speaker', 'SB0033', 'uploads/34/48.BS (5).png', 'galary_image6', 34, '2021-12-10 12:04:50', '2021-12-10 12:04:50'),
(143, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/35.BS (2).png', 'featured_image', 35, '2021-12-10 12:06:42', '2021-12-10 12:06:42'),
(144, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/21.BS (1).png', 'galary_image1', 35, '2021-12-10 12:06:42', '2021-12-10 12:06:42'),
(145, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/56.BS (3).png', 'galary_image2', 35, '2021-12-10 12:06:42', '2021-12-10 12:06:42'),
(146, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/76.BS (5).png', 'galary_image3', 35, '2021-12-10 12:06:42', '2021-12-10 12:06:42'),
(147, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/83.BS (11).png', 'galary_image4', 35, '2021-12-10 12:06:43', '2021-12-10 12:06:43'),
(148, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/26.BS (9).png', 'galary_image5', 35, '2021-12-10 12:06:43', '2021-12-10 12:06:43'),
(149, 'B2 Bluetooth Speaker', 'SB0034', 'uploads/35/30.BS (7).png', 'galary_image6', 35, '2021-12-10 12:06:43', '2021-12-10 12:06:43'),
(150, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/36.Earbud_3-removebg-preview.png', 'featured_image', 36, '2021-12-10 12:09:00', '2021-12-10 12:09:00'),
(151, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/73.Earbud_6-removebg-preview.png', 'galary_image1', 36, '2021-12-10 12:09:00', '2021-12-10 12:09:00'),
(152, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/28.Earbud_7-removebg-preview.png', 'galary_image2', 36, '2021-12-10 12:09:00', '2021-12-10 12:09:00'),
(153, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/88.Earbud_2-removebg-preview.png', 'galary_image3', 36, '2021-12-10 12:09:00', '2021-12-10 12:09:00'),
(154, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/93.Earbud_5-removebg-preview.png', 'galary_image4', 36, '2021-12-10 12:09:01', '2021-12-10 12:09:01'),
(155, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/27.Earbud_1-removebg-preview.png', 'galary_image5', 36, '2021-12-10 12:09:01', '2021-12-10 12:09:01'),
(156, 'C3 Bluetooth Speaker', 'SB0035', 'uploads/36/22.Earbud_2-removebg-preview.png', 'galary_image6', 36, '2021-12-10 12:09:01', '2021-12-10 12:09:01'),
(157, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/37.Earphone_1-removebg-preview.png', 'featured_image', 37, '2021-12-10 12:10:41', '2021-12-10 12:10:41'),
(158, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/79.Earphone_6-removebg-preview.png', 'galary_image1', 37, '2021-12-10 12:10:41', '2021-12-10 12:10:41'),
(159, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/59.Earphone_4-removebg-preview.png', 'galary_image2', 37, '2021-12-10 12:10:42', '2021-12-10 12:10:42'),
(160, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/55.Earphone_2-removebg-preview.png', 'galary_image3', 37, '2021-12-10 12:10:42', '2021-12-10 12:10:42'),
(161, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/91.Earphone_5-removebg-preview.png', 'galary_image4', 37, '2021-12-10 12:10:42', '2021-12-10 12:10:42'),
(162, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/78.Earphone_2-removebg-preview.png', 'galary_image5', 37, '2021-12-10 12:10:42', '2021-12-10 12:10:42'),
(163, 'D4 Bluetooth Speaker', 'SB0036', 'uploads/37/89.Earphone_1-removebg-preview.png', 'galary_image6', 37, '2021-12-10 12:10:42', '2021-12-10 12:10:42'),
(164, 'Sound Item', 'SB0037', 'uploads/38/38.Earphone_6-removebg-preview.png', 'featured_image', 38, '2021-12-10 12:12:40', '2021-12-10 12:12:40'),
(165, 'Sound Item', 'SB0037', 'uploads/38/93.Earphone_2-removebg-preview.png', 'galary_image1', 38, '2021-12-10 12:12:40', '2021-12-10 12:12:40'),
(166, 'Sound Item', 'SB0037', 'uploads/38/86.Earphone_5-removebg-preview.png', 'galary_image2', 38, '2021-12-10 12:12:41', '2021-12-10 12:12:41'),
(167, 'Sound Item', 'SB0037', 'uploads/38/82.Earphone_5-removebg-preview.png', 'galary_image3', 38, '2021-12-10 12:12:41', '2021-12-10 12:12:41'),
(168, 'Sound Item', 'SB0037', 'uploads/38/93.Earphone_1-removebg-preview.png', 'galary_image4', 38, '2021-12-10 12:12:41', '2021-12-10 12:12:41'),
(169, 'Sound Item', 'SB0037', 'uploads/38/77.Earphone_2-removebg-preview.png', 'galary_image5', 38, '2021-12-10 12:12:41', '2021-12-10 12:12:41'),
(170, 'Sound Item', 'SB0037', 'uploads/38/65.Earphone_1-removebg-preview.png', 'galary_image6', 38, '2021-12-10 12:12:41', '2021-12-10 12:12:41'),
(171, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/39.Headphone_4-removebg-preview.png', 'featured_image', 39, '2021-12-10 12:14:28', '2021-12-10 12:14:28'),
(172, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/68.Headphone_8-removebg-preview.png', 'galary_image1', 39, '2021-12-10 12:14:28', '2021-12-10 12:14:28'),
(173, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/55.Headphone_5-removebg-preview.png', 'galary_image2', 39, '2021-12-10 12:14:28', '2021-12-10 12:14:28'),
(174, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/100.Headphone_3-removebg-preview.png', 'galary_image3', 39, '2021-12-10 12:14:29', '2021-12-10 12:14:29'),
(175, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/23.Headphone_1-removebg-preview.png', 'galary_image4', 39, '2021-12-10 12:14:29', '2021-12-10 12:14:29'),
(176, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/42.Headphone_2-removebg-preview.png', 'galary_image5', 39, '2021-12-10 12:14:29', '2021-12-10 12:14:29'),
(177, 'E5 Bluetooth Speaker', 'SB0038', 'uploads/39/32.Headphone_5-removebg-preview.png', 'galary_image6', 39, '2021-12-10 12:14:29', '2021-12-10 12:14:29'),
(178, 'Speaker PQR', 'SB0039', 'uploads/40/40.Earbud_5-removebg-preview.png', 'featured_image', 40, '2021-12-10 13:00:42', '2021-12-10 13:00:42'),
(179, 'Speaker PQR', 'SB0039', 'uploads/40/91.BS (5).png', 'galary_image1', 40, '2021-12-10 12:28:23', '2021-12-10 12:28:23'),
(180, 'Speaker PQR', 'SB0039', 'uploads/40/11.BS (2).png', 'galary_image2', 40, '2021-12-10 12:28:23', '2021-12-10 12:28:23'),
(181, 'Speaker PQR', 'SB0039', 'uploads/40/84.BS (5).png', 'galary_image3', 40, '2021-12-10 12:28:24', '2021-12-10 12:28:24'),
(182, 'Speaker PQR', 'SB0039', 'uploads/40/19.BS (9).png', 'galary_image4', 40, '2021-12-10 12:28:24', '2021-12-10 12:28:24'),
(183, 'Speaker PQR', 'SB0039', 'uploads/40/96.BS (5).png', 'galary_image5', 40, '2021-12-10 12:28:24', '2021-12-10 12:28:24'),
(184, 'Speaker PQR', 'SB0039', 'uploads/40/73.BS (3).png', 'galary_image6', 40, '2021-12-10 12:28:24', '2021-12-10 12:28:24'),
(185, 'A1 Speaker', 'SB0040', 'uploads/41/41.BS (1).png', 'featured_image', 41, '2021-12-10 12:56:53', '2021-12-10 12:56:53'),
(186, 'A1 Speaker', 'SB0040', 'uploads/41/88.BS (3).png', 'galary_image1', 41, '2021-12-10 12:56:53', '2021-12-10 12:56:53'),
(187, 'A1 Speaker', 'SB0040', 'uploads/41/55.BS (5).png', 'galary_image2', 41, '2021-12-10 12:56:53', '2021-12-10 12:56:53'),
(188, 'A1 Speaker', 'SB0040', 'uploads/41/19.BS (6).png', 'galary_image3', 41, '2021-12-10 12:56:53', '2021-12-10 12:56:53'),
(189, 'A1 Speaker', 'SB0040', 'uploads/41/26.BS (8).png', 'galary_image4', 41, '2021-12-10 12:56:53', '2021-12-10 12:56:53'),
(190, 'A1 Speaker', 'SB0040', 'uploads/41/99.BS (9).png', 'galary_image5', 41, '2021-12-10 12:56:53', '2021-12-10 12:56:53'),
(191, 'Fatafati Speaker', 'SB0041', 'uploads/42/42.Earbud_6-removebg-preview.png', 'featured_image', 42, '2021-12-10 13:00:20', '2021-12-10 13:00:20'),
(192, 'Fatafati Speaker', 'SB0041', 'uploads/42/14.Earbud_7-removebg-preview.png', 'galary_image1', 42, '2021-12-10 13:00:20', '2021-12-10 13:00:20'),
(193, 'Fatafati Speaker', 'SB0041', 'uploads/42/72.Earbud_3-removebg-preview.png', 'galary_image2', 42, '2021-12-10 13:00:20', '2021-12-10 13:00:20'),
(194, 'Fatafati Speaker', 'SB0041', 'uploads/42/43.Earbud_1-removebg-preview.png', 'galary_image3', 42, '2021-12-10 13:00:20', '2021-12-10 13:00:20'),
(195, 'Fatafati Speaker', 'SB0041', 'uploads/42/22.Earbud_2-removebg-preview.png', 'galary_image4', 42, '2021-12-10 13:00:21', '2021-12-10 13:00:21'),
(196, 'Fatafati Speaker', 'SB0041', 'uploads/42/76.Earbud_3-removebg-preview.png', 'galary_image5', 42, '2021-12-10 13:00:21', '2021-12-10 13:00:21'),
(197, 'Fatafati Speaker', 'SB0041', 'uploads/42/45.Earbud_1-removebg-preview.png', 'galary_image6', 42, '2021-12-10 13:00:21', '2021-12-10 13:00:21'),
(198, 'Moto E7 Plus', 'SB0042', 'uploads/43/43.Moto E7 Plus-10.jpg', 'featured_image', 43, '2021-12-10 13:02:32', '2021-12-10 13:02:32'),
(199, 'Moto E7 Plus', 'SB0042', 'uploads/43/58.Moto E7 Plus-07.jpg', 'galary_image1', 43, '2021-12-10 13:02:33', '2021-12-10 13:02:33'),
(200, 'Moto E7 Plus', 'SB0042', 'uploads/43/31.Moto E7 Plus-03.jpg', 'galary_image2', 43, '2021-12-10 13:02:33', '2021-12-10 13:02:33'),
(201, 'Moto E7 Plus', 'SB0042', 'uploads/43/85.Moto E7 Plus-02.jpg', 'galary_image3', 43, '2021-12-10 13:02:33', '2021-12-10 13:02:33'),
(202, 'Moto E7 Plus', 'SB0042', 'uploads/43/12.Moto E7 Plus-08.jpg', 'galary_image4', 43, '2021-12-10 13:02:33', '2021-12-10 13:02:33'),
(203, 'Moto E7 Plus', 'SB0042', 'uploads/43/10.Moto E7 Plus-02.jpg', 'galary_image5', 43, '2021-12-10 13:02:33', '2021-12-10 13:02:33'),
(204, 'Moto E7 Plus', 'SB0042', 'uploads/43/71.Moto E7 Plus-01.jpg', 'galary_image6', 43, '2021-12-10 13:02:33', '2021-12-10 13:02:33'),
(205, 'Moto G9 Play', 'SB0043', 'uploads/44/44.Moto G9 Play-10.jpg', 'featured_image', 44, '2021-12-10 13:04:50', '2021-12-10 13:04:50'),
(206, 'Moto G9 Play', 'SB0043', 'uploads/44/77.Moto G9 Play-03.jpg', 'galary_image1', 44, '2021-12-10 13:04:50', '2021-12-10 13:04:50'),
(207, 'Moto G9 Play', 'SB0043', 'uploads/44/81.Moto G9 Play-04.jpg', 'galary_image2', 44, '2021-12-10 13:04:50', '2021-12-10 13:04:50'),
(208, 'Moto G9 Play', 'SB0043', 'uploads/44/10.Moto G9 Play-02.jpg', 'galary_image3', 44, '2021-12-10 13:04:50', '2021-12-10 13:04:50'),
(209, 'Moto G9 Play', 'SB0043', 'uploads/44/20.Moto G9 Play-01.jpg', 'galary_image4', 44, '2021-12-10 13:04:50', '2021-12-10 13:04:50'),
(210, 'Moto G9 Play', 'SB0043', 'uploads/44/76.Moto G9 Play-03.jpg', 'galary_image5', 44, '2021-12-10 13:04:50', '2021-12-10 13:04:50'),
(211, 'Moto G9 Play', 'SB0043', 'uploads/44/49.Moto G9 Play-01.jpg', 'galary_image6', 44, '2021-12-10 13:04:51', '2021-12-10 13:04:51'),
(212, 'Moto g40 FUSION', 'SB0044', 'uploads/45/45.Moto g40 FUSION-10.jpg', 'featured_image', 45, '2021-12-10 13:06:35', '2021-12-10 13:06:35'),
(213, 'Moto g40 FUSION', 'SB0044', 'uploads/45/99.Moto g40 FUSION-09.jpg', 'galary_image1', 45, '2021-12-10 13:06:35', '2021-12-10 13:06:35'),
(214, 'Moto g40 FUSION', 'SB0044', 'uploads/45/22.Moto g40 FUSION-05.jpg', 'galary_image2', 45, '2021-12-10 13:06:36', '2021-12-10 13:06:36'),
(215, 'Moto g40 FUSION', 'SB0044', 'uploads/45/20.Moto g40 FUSION-03.jpg', 'galary_image3', 45, '2021-12-10 13:06:36', '2021-12-10 13:06:36'),
(216, 'Moto g40 FUSION', 'SB0044', 'uploads/45/78.Moto g40 FUSION-05.jpg', 'galary_image4', 45, '2021-12-10 13:06:36', '2021-12-10 13:06:36'),
(217, 'Moto g40 FUSION', 'SB0044', 'uploads/45/56.Moto g40 FUSION-02.jpg', 'galary_image5', 45, '2021-12-10 13:06:37', '2021-12-10 13:06:37'),
(218, 'Moto g40 FUSION', 'SB0044', 'uploads/45/14.Moto g40 FUSION-01.jpg', 'galary_image6', 45, '2021-12-10 13:06:38', '2021-12-10 13:06:38'),
(219, 'Moto g40 FUSION', 'SB0044', 'uploads/45/46.Moto g40 FUSION-10.jpg', 'featured_image', 46, '2021-12-10 13:06:44', '2021-12-10 13:06:44'),
(220, 'Moto g40 FUSION', 'SB0044', 'uploads/45/95.Moto g40 FUSION-09.jpg', 'galary_image1', 46, '2021-12-10 13:06:45', '2021-12-10 13:06:45'),
(221, 'Moto g40 FUSION', 'SB0044', 'uploads/45/70.Moto g40 FUSION-05.jpg', 'galary_image2', 46, '2021-12-10 13:06:46', '2021-12-10 13:06:46'),
(222, 'Moto g40 FUSION', 'SB0044', 'uploads/45/47.Moto g40 FUSION-03.jpg', 'galary_image3', 46, '2021-12-10 13:06:47', '2021-12-10 13:06:47'),
(223, 'Moto g40 FUSION', 'SB0044', 'uploads/45/96.Moto g40 FUSION-05.jpg', 'galary_image4', 46, '2021-12-10 13:06:48', '2021-12-10 13:06:48'),
(224, 'Moto g40 FUSION', 'SB0044', 'uploads/45/55.Moto g40 FUSION-02.jpg', 'galary_image5', 46, '2021-12-10 13:06:49', '2021-12-10 13:06:49'),
(225, 'Moto g40 FUSION', 'SB0044', 'uploads/45/94.Moto g40 FUSION-01.jpg', 'galary_image6', 46, '2021-12-10 13:06:50', '2021-12-10 13:06:50'),
(226, 'A1 Smartwatch', 'SB0046', 'uploads/47/47.tetqwtqwt.jpg', 'featured_image', 47, '2021-12-10 13:55:59', '2021-12-10 13:55:59'),
(227, 'A1 Smartwatch', 'SB0046', 'uploads/47/86.yweyweywey.jpg', 'galary_image1', 47, '2021-12-10 13:56:00', '2021-12-10 13:56:00'),
(228, 'A1 Smartwatch', 'SB0046', 'uploads/47/27.qwtrqwtqwt.jpg', 'galary_image2', 47, '2021-12-10 13:56:00', '2021-12-10 13:56:00'),
(229, 'A1 Smartwatch', 'SB0046', 'uploads/47/99.hsdhsd.jpg', 'galary_image3', 47, '2021-12-10 13:56:00', '2021-12-10 13:56:00'),
(230, 'A1 Smartwatch', 'SB0046', 'uploads/47/19.hsddshgs.jpg', 'galary_image4', 47, '2021-12-10 13:56:00', '2021-12-10 13:56:00'),
(231, 'A1 Smartwatch', 'SB0046', 'uploads/47/40.eyweywey.jpg', 'galary_image5', 47, '2021-12-10 13:56:00', '2021-12-10 13:56:00'),
(232, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/48.download.jpg', 'featured_image', 48, '2021-12-10 13:58:47', '2021-12-10 13:58:47'),
(233, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/69.yweyweywey.jpg', 'galary_image1', 48, '2021-12-10 13:58:48', '2021-12-10 13:58:48'),
(234, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/57.Smartwatch4-removebg-preview.png', 'galary_image2', 48, '2021-12-10 13:58:48', '2021-12-10 13:58:48'),
(235, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/48.Smartwatch1-removebg-preview.png', 'galary_image3', 48, '2021-12-10 13:58:48', '2021-12-10 13:58:48'),
(236, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/71.hsdhsd.jpg', 'galary_image4', 48, '2021-12-10 13:58:48', '2021-12-10 13:58:48'),
(237, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/82.Smartwatch1-removebg-preview.png', 'galary_image5', 48, '2021-12-10 13:58:48', '2021-12-10 13:58:48'),
(238, 'Exclusive Smartwatch', 'SB0047', 'uploads/48/10.Smartwatch2-removebg-preview.png', 'galary_image6', 48, '2021-12-10 13:58:48', '2021-12-10 13:58:48'),
(239, 'BV2 Smartwatch', 'SB0048', 'uploads/49/49.xgfdaga.jpeg', 'featured_image', 49, '2021-12-10 14:00:17', '2021-12-10 14:00:17'),
(240, 'BV2 Smartwatch', 'SB0048', 'uploads/49/50.yweyweywey.jpg', 'galary_image1', 49, '2021-12-10 14:00:17', '2021-12-10 14:00:17'),
(241, 'BV2 Smartwatch', 'SB0048', 'uploads/49/84.Smartwatch3-removebg-preview.png', 'galary_image2', 49, '2021-12-10 14:00:18', '2021-12-10 14:00:18'),
(242, 'BV2 Smartwatch', 'SB0048', 'uploads/49/38.qwtrqwtqwt.jpg', 'galary_image3', 49, '2021-12-10 14:00:18', '2021-12-10 14:00:18'),
(243, 'BV2 Smartwatch', 'SB0048', 'uploads/49/36.hsdhsd.jpg', 'galary_image4', 49, '2021-12-10 14:00:19', '2021-12-10 14:00:19'),
(244, 'BV2 Smartwatch', 'SB0048', 'uploads/49/94.eyweywey.jpg', 'galary_image5', 49, '2021-12-10 14:00:19', '2021-12-10 14:00:19'),
(245, 'BV2 Smartwatch', 'SB0048', 'uploads/49/78.download.jpg', 'galary_image6', 49, '2021-12-10 14:00:19', '2021-12-10 14:00:19'),
(246, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/50.qwtrqwtqwt.jpg', 'featured_image', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(247, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/95.xgfdaga.jpeg', 'galary_image1', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(248, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/86.yweyweywey.jpg', 'galary_image2', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(249, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/46.qwtqwtqwt.jpg', 'galary_image3', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(250, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/43.hsddshgs.jpg', 'galary_image4', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(251, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/91.eyweywey.jpg', 'galary_image5', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(252, 'Fatafati Smartwatch', 'SB0049', 'uploads/50/91.download.jpg', 'galary_image6', 50, '2021-12-10 14:01:52', '2021-12-10 14:01:52'),
(253, 'Latest Smartwatch', 'SB0050', 'uploads/51/51.qwtqwtqwt.jpg', 'featured_image', 51, '2021-12-10 14:03:14', '2021-12-10 14:03:14'),
(254, 'Latest Smartwatch', 'SB0050', 'uploads/51/78.Smartwatch3-removebg-preview.png', 'galary_image1', 51, '2021-12-10 14:03:15', '2021-12-10 14:03:15'),
(255, 'Latest Smartwatch', 'SB0050', 'uploads/51/79.tetqwtqwt.jpg', 'galary_image2', 51, '2021-12-10 14:03:15', '2021-12-10 14:03:15'),
(256, 'Latest Smartwatch', 'SB0050', 'uploads/51/77.xgfdaga.jpeg', 'galary_image3', 51, '2021-12-10 14:03:15', '2021-12-10 14:03:15'),
(257, 'Latest Smartwatch', 'SB0050', 'uploads/51/57.yweyweywey.jpg', 'galary_image4', 51, '2021-12-10 14:03:16', '2021-12-10 14:03:16'),
(258, 'Latest Smartwatch', 'SB0050', 'uploads/51/69.hsddshgs.jpg', 'galary_image5', 51, '2021-12-10 14:03:16', '2021-12-10 14:03:16'),
(259, 'Latest Smartwatch', 'SB0050', 'uploads/51/31.Smartwatch3-removebg-preview.png', 'galary_image6', 51, '2021-12-10 14:03:16', '2021-12-10 14:03:16'),
(260, 'O+ Smartwatch', 'SB0051', 'uploads/52/52.hsdhsd.jpg', 'featured_image', 52, '2021-12-10 14:05:05', '2021-12-10 14:05:05'),
(261, 'O+ Smartwatch', 'SB0051', 'uploads/52/90.Smartwatch4-removebg-preview.png', 'galary_image1', 52, '2021-12-10 14:05:05', '2021-12-10 14:05:05'),
(262, 'O+ Smartwatch', 'SB0051', 'uploads/52/43.xgfdaga.jpeg', 'galary_image2', 52, '2021-12-10 14:05:05', '2021-12-10 14:05:05'),
(263, 'O+ Smartwatch', 'SB0051', 'uploads/52/77.qwtrqwtqwt.jpg', 'galary_image3', 52, '2021-12-10 14:05:05', '2021-12-10 14:05:05'),
(264, 'O+ Smartwatch', 'SB0051', 'uploads/52/90.qwtqwtqwt.jpg', 'galary_image4', 52, '2021-12-10 14:05:06', '2021-12-10 14:05:06'),
(265, 'O+ Smartwatch', 'SB0051', 'uploads/52/32.yweyweywey.jpg', 'galary_image5', 52, '2021-12-10 14:05:06', '2021-12-10 14:05:06'),
(266, 'O+ Smartwatch', 'SB0051', 'uploads/52/50.hsdhsd.jpg', 'galary_image6', 52, '2021-12-10 14:05:06', '2021-12-10 14:05:06'),
(267, 'Smartwatch B2', 'SB0052', 'uploads/53/53.Smartwatch1-removebg-preview.png', 'featured_image', 53, '2021-12-10 14:08:49', '2021-12-10 14:08:49'),
(268, 'Smartwatch B2', 'SB0052', 'uploads/53/36.xgfdaga.jpeg', 'galary_image1', 53, '2021-12-10 14:08:49', '2021-12-10 14:08:49'),
(269, 'Smartwatch B2', 'SB0052', 'uploads/53/65.yweyweywey.jpg', 'galary_image2', 53, '2021-12-10 14:08:49', '2021-12-10 14:08:49'),
(270, 'Smartwatch B2', 'SB0052', 'uploads/53/76.Smartwatch4-removebg-preview.png', 'galary_image3', 53, '2021-12-10 14:08:49', '2021-12-10 14:08:49'),
(271, 'Smartwatch B2', 'SB0052', 'uploads/53/60.Smartwatch-removebg-preview.png', 'galary_image4', 53, '2021-12-10 14:08:49', '2021-12-10 14:08:49'),
(272, 'Smartwatch B2', 'SB0052', 'uploads/53/81.yweyweywey.jpg', 'galary_image5', 53, '2021-12-10 14:08:49', '2021-12-10 14:08:49'),
(273, 'Smartwatch B2', 'SB0052', 'uploads/53/58.hsddshgs.jpg', 'galary_image6', 53, '2021-12-10 14:08:50', '2021-12-10 14:08:50'),
(274, 'Smartwatch D4', 'SB0053', 'uploads/54/54.Smartwatch-removebg-preview.png', 'featured_image', 54, '2021-12-10 14:15:15', '2021-12-10 14:15:15'),
(275, 'Smartwatch D4', 'SB0053', 'uploads/54/11.xgfdaga.jpeg', 'galary_image1', 54, '2021-12-10 14:15:15', '2021-12-10 14:15:15'),
(276, 'Smartwatch D4', 'SB0053', 'uploads/54/23.yweyweywey.jpg', 'galary_image2', 54, '2021-12-10 14:15:16', '2021-12-10 14:15:16'),
(277, 'Smartwatch D4', 'SB0053', 'uploads/54/79.Smartwatch3-removebg-preview.png', 'galary_image3', 54, '2021-12-10 14:15:16', '2021-12-10 14:15:16'),
(278, 'Smartwatch D4', 'SB0053', 'uploads/54/100.hsddshgs.jpg', 'galary_image4', 54, '2021-12-10 14:15:16', '2021-12-10 14:15:16'),
(279, 'Smartwatch D4', 'SB0053', 'uploads/54/74.hsdhsd.jpg', 'galary_image5', 54, '2021-12-10 14:15:16', '2021-12-10 14:15:16'),
(280, 'Smartwatch D4', 'SB0053', 'uploads/54/53.eyweywey.jpg', 'galary_image6', 54, '2021-12-10 14:15:16', '2021-12-10 14:15:16'),
(281, 'B2 Powerbank', 'SB0054', 'uploads/55/55.Powerbank (2).png', 'featured_image', 55, '2021-12-10 14:21:58', '2021-12-10 14:21:58'),
(282, 'B2 Powerbank', 'SB0054', 'uploads/55/92.Powerbank (5).png', 'galary_image1', 55, '2021-12-10 14:21:58', '2021-12-10 14:21:58'),
(283, 'B2 Powerbank', 'SB0054', 'uploads/55/83.Powerbank (4).png', 'galary_image2', 55, '2021-12-10 14:21:59', '2021-12-10 14:21:59'),
(284, 'B2 Powerbank', 'SB0054', 'uploads/55/76.Powerbank (1).png', 'galary_image3', 55, '2021-12-10 14:21:59', '2021-12-10 14:21:59'),
(285, 'B2 Powerbank', 'SB0054', 'uploads/55/57.Powerbank (2).png', 'galary_image4', 55, '2021-12-10 14:21:59', '2021-12-10 14:21:59'),
(286, 'B2 Powerbank', 'SB0054', 'uploads/55/75.Powerbank (4).png', 'galary_image5', 55, '2021-12-10 14:21:59', '2021-12-10 14:21:59'),
(287, 'B2 Powerbank', 'SB0054', 'uploads/55/80.Powerbank (5).png', 'galary_image6', 55, '2021-12-10 14:21:59', '2021-12-10 14:21:59'),
(288, 'Powerbank t3', 'SB0055', 'uploads/56/56.download (2).jpg', 'featured_image', 56, '2021-12-10 14:35:11', '2021-12-10 14:35:11'),
(289, 'Powerbank t3', 'SB0055', 'uploads/56/34.power-bank-2000mah-pink-819-550x550.jpg', 'galary_image1', 56, '2021-12-10 14:35:11', '2021-12-10 14:35:11'),
(290, 'Powerbank t3', 'SB0055', 'uploads/56/26.Powerbank (3).png', 'galary_image2', 56, '2021-12-10 14:35:11', '2021-12-10 14:35:11'),
(291, 'Powerbank t3', 'SB0055', 'uploads/56/98.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', 'galary_image3', 56, '2021-12-10 14:35:11', '2021-12-10 14:35:11'),
(292, 'T7 Powerbank', 'SB0055', 'uploads/57/57.images (1).jpg', 'featured_image', 57, '2021-12-10 14:38:30', '2021-12-10 14:38:30'),
(293, 'T7 Powerbank', 'SB0055', 'uploads/57/46.power-bank-2000mah-pink-819-550x550.jpg', 'galary_image1', 57, '2021-12-10 14:38:18', '2021-12-10 14:38:18'),
(294, 'T7 Powerbank', 'SB0055', 'uploads/57/30.Powerbank (3).png', 'galary_image2', 57, '2021-12-10 14:38:18', '2021-12-10 14:38:18'),
(295, 'T7 Powerbank', 'SB0055', 'uploads/57/12.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', 'galary_image3', 57, '2021-12-10 14:38:18', '2021-12-10 14:38:18'),
(296, 'T7 Powerbank', 'SB0055', 'uploads/57/31.Powerbank (4).png', 'galary_image4', 57, '2021-12-10 14:38:18', '2021-12-10 14:38:18'),
(297, 'JPT Powerbank', 'SB0057', 'uploads/58/58.eng_pl_NonStop-PowerBank-Sella-Black-20800mAh-1295_5.jpg', 'featured_image', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(298, 'JPT Powerbank', 'SB0057', 'uploads/58/47.download (1).jpg', 'galary_image1', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(299, 'JPT Powerbank', 'SB0057', 'uploads/58/63.Powerbank (2).png', 'galary_image2', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(300, 'JPT Powerbank', 'SB0057', 'uploads/58/18.Powerbank (4).png', 'galary_image3', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(301, 'JPT Powerbank', 'SB0057', 'uploads/58/24.Powerbank (5).png', 'galary_image4', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(302, 'JPT Powerbank', 'SB0057', 'uploads/58/80.81mI9dvL8dL._AC_SL1500_.jpg', 'galary_image5', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(303, 'JPT Powerbank', 'SB0057', 'uploads/58/59.Powerbank (4).png', 'galary_image6', 58, '2021-12-10 14:40:10', '2021-12-10 14:40:10'),
(304, 'Super Powerbank', 'SB0058', 'uploads/59/59.download.jpg', 'featured_image', 59, '2021-12-10 14:49:43', '2021-12-10 14:49:43'),
(305, 'Super Powerbank', 'SB0058', 'uploads/59/40.Powerbank (1).png', 'galary_image1', 59, '2021-12-10 14:49:43', '2021-12-10 14:49:43'),
(306, 'Super Powerbank', 'SB0058', 'uploads/59/60.Powerbank (2).png', 'galary_image2', 59, '2021-12-10 14:49:43', '2021-12-10 14:49:43'),
(307, 'Super Powerbank', 'SB0058', 'uploads/59/43.81mI9dvL8dL._AC_SL1500_.jpg', 'galary_image3', 59, '2021-12-10 14:49:43', '2021-12-10 14:49:43'),
(308, 'Super Powerbank', 'SB0058', 'uploads/59/19.download (2).jpg', 'galary_image4', 59, '2021-12-10 14:49:43', '2021-12-10 14:49:43'),
(309, 'Super Powerbank', 'SB0058', 'uploads/59/52.images (1).jpg', 'galary_image5', 59, '2021-12-10 14:49:43', '2021-12-10 14:49:43'),
(310, 'P2 Powerbank', 'SB0059', 'uploads/60/60.download (1).jpg', 'featured_image', 60, '2021-12-10 14:50:59', '2021-12-10 14:50:59'),
(311, 'P2 Powerbank', 'SB0059', 'uploads/60/32.Powerbank (2).png', 'galary_image1', 60, '2021-12-10 14:51:00', '2021-12-10 14:51:00'),
(312, 'P2 Powerbank', 'SB0059', 'uploads/60/26.Powerbank (5).png', 'galary_image2', 60, '2021-12-10 14:51:00', '2021-12-10 14:51:00'),
(313, 'P2 Powerbank', 'SB0059', 'uploads/60/70.power-bank-2000mah-pink-819-550x550.jpg', 'galary_image3', 60, '2021-12-10 14:51:00', '2021-12-10 14:51:00'),
(314, 'P2 Powerbank', 'SB0059', 'uploads/60/93.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', 'galary_image4', 60, '2021-12-10 14:51:00', '2021-12-10 14:51:00'),
(315, 'P2 Powerbank', 'SB0059', 'uploads/60/84.Powerbank (4).png', 'galary_image5', 60, '2021-12-10 14:51:01', '2021-12-10 14:51:01'),
(316, 'HDB Powerbank', 'SB0060', 'uploads/61/61.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', 'featured_image', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(317, 'HDB Powerbank', 'SB0060', 'uploads/61/34.Powerbank (1).png', 'galary_image1', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(318, 'HDB Powerbank', 'SB0060', 'uploads/61/87.Powerbank (4).png', 'galary_image2', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(319, 'HDB Powerbank', 'SB0060', 'uploads/61/27.power-bank-2000mah-pink-819-550x550.jpg', 'galary_image3', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(320, 'HDB Powerbank', 'SB0060', 'uploads/61/45.images.jpg', 'galary_image4', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(321, 'HDB Powerbank', 'SB0060', 'uploads/61/63.download (2).jpg', 'galary_image5', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(322, 'HDB Powerbank', 'SB0060', 'uploads/61/99.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', 'galary_image6', 61, '2021-12-10 14:52:44', '2021-12-10 14:52:44'),
(323, 'UPB Powerbank', 'SB0061', 'uploads/62/62.Powerbank (1).png', 'featured_image', 62, '2021-12-10 14:56:15', '2021-12-10 14:56:15'),
(324, 'UPB Powerbank', 'SB0061', 'uploads/62/50.images (1).jpg', 'galary_image1', 62, '2021-12-10 14:56:15', '2021-12-10 14:56:15'),
(325, 'UPB Powerbank', 'SB0061', 'uploads/62/76.Powerbank (4).png', 'galary_image2', 62, '2021-12-10 14:56:15', '2021-12-10 14:56:15'),
(326, 'UPB Powerbank', 'SB0061', 'uploads/62/20.power-bank-2000mah-pink-819-550x550.jpg', 'galary_image3', 62, '2021-12-10 14:56:15', '2021-12-10 14:56:15'),
(327, 'UPB Powerbank', 'SB0061', 'uploads/62/47.images.jpg', 'galary_image4', 62, '2021-12-10 14:56:15', '2021-12-10 14:56:15'),
(328, 'UPB Powerbank', 'SB0061', 'uploads/62/45.download (1).jpg', 'galary_image5', 62, '2021-12-10 14:56:16', '2021-12-10 14:56:16'),
(329, 'UPB Powerbank', 'SB0061', 'uploads/62/91.81mI9dvL8dL._AC_SL1500_.jpg', 'galary_image6', 62, '2021-12-10 14:56:16', '2021-12-10 14:56:16'),
(330, 'Fatafati Charger', 'SB0062', 'uploads/63/63.download.jpg', 'featured_image', 63, '2021-12-10 15:07:59', '2021-12-10 15:07:59'),
(331, 'Fatafati Charger', 'SB0062', 'uploads/63/15.Mobile_Adapter_4-removebg-preview.png', 'galary_image1', 63, '2021-12-10 15:07:59', '2021-12-10 15:07:59'),
(332, 'Fatafati Charger', 'SB0062', 'uploads/63/83.Mobile_Adapter_6-removebg-preview.png', 'galary_image2', 63, '2021-12-10 15:08:00', '2021-12-10 15:08:00'),
(333, 'Fatafati Charger', 'SB0062', 'uploads/63/30.Mobile_Adapter_2-removebg-preview.png', 'galary_image3', 63, '2021-12-10 15:08:00', '2021-12-10 15:08:00'),
(334, 'Fatafati Charger', 'SB0062', 'uploads/63/100.download (3).jpg', 'galary_image4', 63, '2021-12-10 15:08:00', '2021-12-10 15:08:00'),
(335, 'Fatafati Charger', 'SB0062', 'uploads/63/51.680961349361_1-85962.jpg', 'galary_image5', 63, '2021-12-10 15:08:00', '2021-12-10 15:08:00'),
(336, 'A1 Charger', 'SB0063', 'uploads/64/64.Mobile_Adapter_5-removebg-preview.png', 'featured_image', 64, '2021-12-10 15:09:12', '2021-12-10 15:09:12'),
(337, 'A1 Charger', 'SB0063', 'uploads/64/100.Mobile_Adapter_6-removebg-preview.png', 'galary_image1', 64, '2021-12-10 15:09:13', '2021-12-10 15:09:13'),
(338, 'A1 Charger', 'SB0063', 'uploads/64/23.Mobile_Adapter_2-removebg-preview.png', 'galary_image2', 64, '2021-12-10 15:09:13', '2021-12-10 15:09:13'),
(339, 'A1 Charger', 'SB0063', 'uploads/64/28.download.jpg', 'galary_image3', 64, '2021-12-10 15:09:13', '2021-12-10 15:09:13'),
(340, 'A1 Charger', 'SB0063', 'uploads/64/11.download (3).jpg', 'galary_image4', 64, '2021-12-10 15:09:13', '2021-12-10 15:09:13'),
(341, 'A1 Charger', 'SB0063', 'uploads/64/34.680961349361_1-85962.jpg', 'galary_image5', 64, '2021-12-10 15:09:14', '2021-12-10 15:09:14'),
(342, 'A1 Charger', 'SB0063', 'uploads/64/74.61NfFCwsneL._SL1500_.jpg', 'galary_image6', 64, '2021-12-10 15:09:14', '2021-12-10 15:09:14'),
(343, 'PQRP Charger', 'SB0064', 'uploads/65/65.Mobile_Adapter_6-removebg-preview.png', 'featured_image', 65, '2021-12-10 15:10:18', '2021-12-10 15:10:18'),
(344, 'PQRP Charger', 'SB0064', 'uploads/65/14.Mobile_Adapter_4-removebg-preview.png', 'galary_image1', 65, '2021-12-10 15:10:18', '2021-12-10 15:10:18'),
(345, 'PQRP Charger', 'SB0064', 'uploads/65/50.Mobile_Adapter_3-removebg-preview.png', 'galary_image2', 65, '2021-12-10 15:10:18', '2021-12-10 15:10:18'),
(346, 'PQRP Charger', 'SB0064', 'uploads/65/98.Mobile_Adapter_1-removebg-preview.png', 'galary_image3', 65, '2021-12-10 15:10:18', '2021-12-10 15:10:18'),
(347, 'HRP Charger', 'SB0065', 'uploads/66/66.Mobile_Adapter_1-removebg-preview.png', 'featured_image', 66, '2021-12-10 15:11:45', '2021-12-10 15:11:45'),
(348, 'HRP Charger', 'SB0065', 'uploads/66/27.Mobile_Adapter_5-removebg-preview.png', 'galary_image1', 66, '2021-12-10 15:11:46', '2021-12-10 15:11:46'),
(349, 'HRP Charger', 'SB0065', 'uploads/66/74.Mobile_Adapter_6-removebg-preview.png', 'galary_image2', 66, '2021-12-10 15:11:46', '2021-12-10 15:11:46'),
(350, 'HRP Charger', 'SB0065', 'uploads/66/52.Mobile_Adapter_1-removebg-preview.png', 'galary_image3', 66, '2021-12-10 15:11:46', '2021-12-10 15:11:46'),
(351, 'HRP Charger', 'SB0065', 'uploads/66/40.download (3).jpg', 'galary_image4', 66, '2021-12-10 15:11:46', '2021-12-10 15:11:46'),
(352, 'HRP Charger', 'SB0065', 'uploads/66/70.Mobile_Adapter_6-removebg-preview.png', 'galary_image5', 66, '2021-12-10 15:11:46', '2021-12-10 15:11:46'),
(353, 'HRP Charger', 'SB0065', 'uploads/66/50.61NfFCwsneL._SL1500_.jpg', 'galary_image6', 66, '2021-12-10 15:11:46', '2021-12-10 15:11:46'),
(354, 'PPR Charger', 'SB0066', 'uploads/67/67.680961349361_1-85962.jpg', 'featured_image', 67, '2021-12-10 15:22:00', '2021-12-10 15:22:00'),
(355, 'PPR Charger', 'SB0066', 'uploads/67/89.Mobile_Adapter_4-removebg-preview.png', 'galary_image1', 67, '2021-12-10 15:13:46', '2021-12-10 15:13:46'),
(356, 'PPR Charger', 'SB0066', 'uploads/67/25.Mobile_Adapter_5-removebg-preview.png', 'galary_image2', 67, '2021-12-10 15:13:46', '2021-12-10 15:13:46'),
(357, 'PPR Charger', 'SB0066', 'uploads/67/18.Mobile_Adapter_6-removebg-preview.png', 'galary_image3', 67, '2021-12-10 15:13:47', '2021-12-10 15:13:47'),
(358, 'PPR Charger', 'SB0066', 'uploads/67/35.61NfFCwsneL._SL1500_.jpg', 'galary_image4', 67, '2021-12-10 15:13:47', '2021-12-10 15:13:47'),
(359, 'PPR Charger', 'SB0066', 'uploads/67/24.Mobile_Adapter_3-removebg-preview.png', 'galary_image5', 67, '2021-12-10 15:13:48', '2021-12-10 15:13:48'),
(360, 'PPR Charger', 'SB0066', 'uploads/67/27.Mobile_Adapter_5-removebg-preview.png', 'galary_image6', 67, '2021-12-10 15:13:48', '2021-12-10 15:13:48'),
(361, 'RTR Charger', 'SB0067', 'uploads/68/68.Mobile_Adapter_4-removebg-preview.png', 'featured_image', 68, '2021-12-10 15:15:47', '2021-12-10 15:15:47'),
(362, 'RTR Charger', 'SB0067', 'uploads/68/41.Mobile_Adapter_6-removebg-preview.png', 'galary_image1', 68, '2021-12-10 15:15:47', '2021-12-10 15:15:47');
INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(363, 'RTR Charger', 'SB0067', 'uploads/68/42.Mobile_Adapter_3-removebg-preview.png', 'galary_image2', 68, '2021-12-10 15:15:47', '2021-12-10 15:15:47'),
(364, 'RTR Charger', 'SB0067', 'uploads/68/99.Mobile_Adapter_1-removebg-preview.png', 'galary_image3', 68, '2021-12-10 15:15:47', '2021-12-10 15:15:47'),
(365, 'RTR Charger', 'SB0067', 'uploads/68/80.download (3).jpg', 'galary_image4', 68, '2021-12-10 15:15:47', '2021-12-10 15:15:47'),
(366, 'RTR Charger', 'SB0067', 'uploads/68/47.680961349361_1-85962.jpg', 'galary_image5', 68, '2021-12-10 15:15:48', '2021-12-10 15:15:48'),
(367, 'RTR Charger', 'SB0067', 'uploads/68/19.61NfFCwsneL._SL1500_.jpg', 'galary_image6', 68, '2021-12-10 15:15:48', '2021-12-10 15:15:48'),
(368, 'NBV Charger', 'SB0068', 'uploads/69/69.download (3).jpg', 'featured_image', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(369, 'NBV Charger', 'SB0068', 'uploads/69/43.Mobile_Adapter_6-removebg-preview.png', 'galary_image1', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(370, 'NBV Charger', 'SB0068', 'uploads/69/82.Mobile_Adapter_4-removebg-preview.png', 'galary_image2', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(371, 'NBV Charger', 'SB0068', 'uploads/69/80.Mobile_Adapter_1-removebg-preview.png', 'galary_image3', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(372, 'NBV Charger', 'SB0068', 'uploads/69/49.download.jpg', 'galary_image4', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(373, 'NBV Charger', 'SB0068', 'uploads/69/44.download (3).jpg', 'galary_image5', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(374, 'NBV Charger', 'SB0068', 'uploads/69/67.Mobile_Adapter_4-removebg-preview.png', 'galary_image6', 69, '2021-12-10 15:18:12', '2021-12-10 15:18:12'),
(375, 'HBTI Charger', 'SB0069', 'uploads/70/70.Mobile_Adapter_3-removebg-preview.png', 'featured_image', 70, '2021-12-10 15:20:21', '2021-12-10 15:20:21'),
(376, 'HBTI Charger', 'SB0069', 'uploads/70/65.Mobile_Adapter_6-removebg-preview.png', 'galary_image1', 70, '2021-12-10 15:20:22', '2021-12-10 15:20:22'),
(377, 'HBTI Charger', 'SB0069', 'uploads/70/27.Mobile_Adapter_4-removebg-preview.png', 'galary_image2', 70, '2021-12-10 15:20:22', '2021-12-10 15:20:22'),
(378, 'HBTI Charger', 'SB0069', 'uploads/70/96.Mobile_Adapter_1-removebg-preview.png', 'galary_image3', 70, '2021-12-10 15:20:23', '2021-12-10 15:20:23'),
(379, 'HBTI Charger', 'SB0069', 'uploads/70/32.Mobile_Adapter_5-removebg-preview.png', 'galary_image4', 70, '2021-12-10 15:20:23', '2021-12-10 15:20:23'),
(380, 'HBTI Charger', 'SB0069', 'uploads/70/18.Mobile_Adapter_6-removebg-preview.png', 'galary_image5', 70, '2021-12-10 15:20:23', '2021-12-10 15:20:23'),
(381, 'HBTI Charger', 'SB0069', 'uploads/70/56.download (3).jpg', 'galary_image6', 70, '2021-12-10 15:20:24', '2021-12-10 15:20:24'),
(382, 'YPR Charger', 'SB0070', 'uploads/71/71.61NfFCwsneL._SL1500_.jpg', 'featured_image', 71, '2021-12-10 15:24:30', '2021-12-10 15:24:30'),
(383, 'YPR Charger', 'SB0070', 'uploads/71/55.Mobile_Adapter_5-removebg-preview.png', 'galary_image1', 71, '2021-12-10 15:24:31', '2021-12-10 15:24:31'),
(384, 'YPR Charger', 'SB0070', 'uploads/71/94.Mobile_Adapter_6-removebg-preview.png', 'galary_image2', 71, '2021-12-10 15:24:31', '2021-12-10 15:24:31'),
(385, 'YPR Charger', 'SB0070', 'uploads/71/58.Mobile_Adapter_2-removebg-preview.png', 'galary_image3', 71, '2021-12-10 15:24:31', '2021-12-10 15:24:31'),
(386, 'YPR Charger', 'SB0070', 'uploads/71/16.download.jpg', 'galary_image4', 71, '2021-12-10 15:24:32', '2021-12-10 15:24:32'),
(387, 'YPR Charger', 'SB0070', 'uploads/71/86.Mobile_Adapter_5-removebg-preview.png', 'galary_image5', 71, '2021-12-10 15:24:32', '2021-12-10 15:24:32'),
(388, 'YPR Charger', 'SB0070', 'uploads/71/80.Mobile_Adapter_6-removebg-preview.png', 'galary_image6', 71, '2021-12-10 15:24:32', '2021-12-10 15:24:32'),
(389, 'Tripod A1', 'SB0071', 'uploads/72/72.godox-p90l-parabol-softbox-90-cm.jpg', 'featured_image', 72, '2021-12-10 15:39:53', '2021-12-10 15:39:53'),
(390, 'Tripod A1', 'SB0071', 'uploads/72/23.download (1).jpg', 'galary_image1', 72, '2021-12-10 15:39:53', '2021-12-10 15:39:53'),
(391, 'Tripod A1', 'SB0071', 'uploads/72/66.download (3).jpg', 'galary_image2', 72, '2021-12-10 15:39:53', '2021-12-10 15:39:53'),
(392, 'Tripod A1', 'SB0071', 'uploads/72/16.selfie-tripod.jpg', 'galary_image3', 72, '2021-12-10 15:39:53', '2021-12-10 15:39:53'),
(393, 'Tripod X2', 'GX0072', 'uploads/73/73.rode-tripod-2-folded-out-mar-2021-1080-1080-rgb.png', 'featured_image', 73, '2021-12-10 17:04:06', '2021-12-10 17:04:06'),
(394, 'Tripod X2', 'GX0072', 'uploads/73/68.u_10218727.jpg', 'galary_image1', 73, '2021-12-10 17:04:06', '2021-12-10 17:04:06'),
(395, 'Tripod X2', 'GX0072', 'uploads/73/57.dfdfdf.png', 'galary_image2', 73, '2021-12-10 17:04:06', '2021-12-10 17:04:06'),
(396, 'Tripod X2', 'GX0072', 'uploads/73/77.u_10218727.jpg', 'galary_image3', 73, '2021-12-10 17:04:06', '2021-12-10 17:04:06'),
(397, 'Softbox', 'GX0073', 'uploads/74/74.download (1).jpg', 'featured_image', 74, '2021-12-10 17:05:24', '2021-12-10 17:05:24'),
(398, 'Softbox', 'GX0073', 'uploads/74/13.godox-p90l-parabol-softbox-90-cm.jpg', 'galary_image1', 74, '2021-12-10 17:05:24', '2021-12-10 17:05:24'),
(399, 'Light Box', 'GX0074', 'uploads/75/75.wrqwrqw.jpg', 'featured_image', 75, '2021-12-10 17:06:42', '2021-12-10 17:06:42'),
(400, 'Light Box', 'GX0074', 'uploads/75/62.wrqwrqw.jpg', 'galary_image1', 75, '2021-12-10 17:06:42', '2021-12-10 17:06:42'),
(401, 'Softlight Box', 'GX0075', 'uploads/76/76.download (2).jpg', 'featured_image', 76, '2021-12-10 17:08:07', '2021-12-10 17:08:07'),
(402, 'Softlight Box', 'GX0075', 'uploads/76/46.download (1).jpg', 'galary_image1', 76, '2021-12-10 17:08:07', '2021-12-10 17:08:07'),
(403, 'FTR Trimmer', 'GX0076', 'uploads/77/77.0010067_philips-beard-trimmer-bt310215.jpeg', 'featured_image', 77, '2021-12-10 17:09:25', '2021-12-10 17:09:25'),
(404, 'FTR Trimmer', 'GX0076', 'uploads/77/56.51cOhvN5ZDL.jpg', 'galary_image1', 77, '2021-12-10 17:09:25', '2021-12-10 17:09:25'),
(405, 'FTR Trimmer', 'GX0076', 'uploads/77/85.o]ryr.jpg', 'galary_image2', 77, '2021-12-10 17:09:25', '2021-12-10 17:09:25'),
(406, 'T17 Trimmer', 'GX0077', 'uploads/78/78.0010066_philips-beard-trimmer-bt321515.jpeg', 'featured_image', 78, '2021-12-10 17:10:28', '2021-12-10 17:10:28'),
(407, 'T17 Trimmer', 'GX0077', 'uploads/78/77.yreyrey.jpg', 'galary_image1', 78, '2021-12-10 17:10:28', '2021-12-10 17:10:28'),
(408, 'T17 Trimmer', 'GX0077', 'uploads/78/24.0010066_philips-beard-trimmer-bt321515.jpeg', 'galary_image2', 78, '2021-12-10 17:10:28', '2021-12-10 17:10:28'),
(409, 'TURA Vacuum Cleaner', 'GX0078', 'uploads/79/79.d0.jpg', 'featured_image', 79, '2021-12-10 17:11:40', '2021-12-10 17:11:40'),
(410, 'TURA Vacuum Cleaner', 'GX0078', 'uploads/79/13.Panasonic-MC-CG331-Vacuum-Cleaner.jpg', 'galary_image1', 79, '2021-12-10 17:11:40', '2021-12-10 17:11:40'),
(411, 'TURA Vacuum Cleaner', 'GX0078', 'uploads/79/23.61tH1osluML._SL1200_.jpg', 'galary_image2', 79, '2021-12-10 17:11:40', '2021-12-10 17:11:40'),
(412, 'HERO Floor Cleaner', 'GX0079', 'uploads/80/80.8835343200-LO2-20200106-082623.png', 'featured_image', 80, '2021-12-10 17:12:43', '2021-12-10 17:12:43'),
(413, 'HERO Floor Cleaner', 'GX0079', 'uploads/80/71.Panasonic-MC-CG331-Vacuum-Cleaner.jpg', 'galary_image1', 80, '2021-12-10 17:12:43', '2021-12-10 17:12:43'),
(414, 'HERO Floor Cleaner', 'GX0079', 'uploads/80/14.philips-canister-vacuum-cleaner-1800w-fc9350.jpg', 'galary_image2', 80, '2021-12-10 17:12:43', '2021-12-10 17:12:43'),
(415, 'Fatafati Floor Cleaner', 'GX0080', 'uploads/81/81.61tH1osluML._SL1200_.jpg', 'featured_image', 81, '2021-12-10 17:13:51', '2021-12-10 17:13:51'),
(416, 'Fatafati Floor Cleaner', 'GX0080', 'uploads/81/25.Panasonic-MC-CG331-Vacuum-Cleaner.jpg', 'galary_image1', 81, '2021-12-10 17:13:51', '2021-12-10 17:13:51'),
(417, 'Fatafati Floor Cleaner', 'GX0080', 'uploads/81/86.d0.jpg', 'galary_image2', 81, '2021-12-10 17:13:51', '2021-12-10 17:13:51'),
(418, 'Fatafati Floor Cleaner', 'GX0080', 'uploads/81/48.8835343200-LO2-20200106-082623.png', 'galary_image3', 81, '2021-12-10 17:13:51', '2021-12-10 17:13:51'),
(419, 'Exclusive Cleaner', 'GX0081', 'uploads/82/82.8835343200-LO2-20200106-082623.png', 'featured_image', 82, '2021-12-10 17:15:02', '2021-12-10 17:15:02'),
(420, 'Sei Rokom Trimmer', 'GX0082', 'uploads/83/83.beardo-pr3051-beast.jpg', 'featured_image', 83, '2021-12-10 17:16:21', '2021-12-10 17:16:21'),
(421, 'Sei Rokom Trimmer', 'GX0082', 'uploads/83/53.o]ryr.jpg', 'galary_image1', 83, '2021-12-10 17:16:21', '2021-12-10 17:16:21'),
(422, 'ABC', 'GX0083', 'uploads/84/84.gsmarena_004.jpg', 'featured_image', 84, '2021-12-13 17:59:28', '2021-12-13 17:59:28');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messages_id` int(11) NOT NULL,
  `affiliate_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `message_by` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_read` tinyint(4) DEFAULT NULL,
  `message_status` tinyint(4) DEFAULT 0 COMMENT '0 new\r\n1 pending\r\n2 done\r\n',
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `newsletter_id` int(11) NOT NULL,
  `newsletter_email` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`newsletter_id`, `newsletter_email`, `created_time`, `status`) VALUES
(9, 'ss@hhhh.jjj', '2019-12-12 09:10:39', 0),
(10, 'ssf@ggg.jjj', '2019-12-17 03:22:42', 0),
(11, 'ssf@ggg.jjj', '2019-12-17 03:22:45', 0),
(12, 'ff@ffffgg.jjjj', '2020-01-04 05:12:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banner` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  `order_by` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `name`, `picture`, `banner`, `start_date`, `ending_date`, `order_by`, `status`, `description`, `link`, `created_at`) VALUES
(2, 'Student Pass Offer', 'uploads/category/2_offer_picture_.png', 'uploads/category/2_offer_banner_.jpg', '2021-12-21', '2021-12-15', 4, 1, '<p>dddhfdhfdf fdf ffffd</p>', 'http://127.0.0.1:8000/realme-8-5g-354-30-30', '2021-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `option_id` int(11) NOT NULL,
  `option_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`option_id`, `option_name`, `option_value`) VALUES
(59, 'home_page_category_id', '58,65'),
(60, 'logo', 'https://gadget.jibonpata.com/images/ICON/logo.svg'),
(61, 'icon', 'https://gadget.jibonpata.com/images/ICON/icon.svg'),
(62, 'site_title', 'GadgetEx | Exclusive Gadgets for Your Daily Life'),
(63, 'order_image', NULL),
(64, 'phone', '+880 1726 003 324'),
(65, 'phone_order', '<i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\">   </i> 123456789 <br>\r\n <i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\"> </i> 123456789 <br>'),
(66, 'address', 'fggffggf'),
(67, 'admin_email', 'info@sohojbuy.com'),
(68, 'shipping_charge_in_dhaka', '60'),
(69, 'shipping_charge_out_of_dhaka', '130'),
(70, 'footer', NULL),
(71, 'google_map', NULL),
(72, 'copyright', NULL),
(73, 'default_product_terms', '<ul>\r\n	<li>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন, জননী, সুন্দরবন ও করোতোয়া কুরিয়ারের মাধ্যমে ডেলিভারি করে থাকি।</li>\r\n	<li>পণ্যর সম্পূর্ণ মূল্য অথবা কুরিয়ার চার্জ 120 টাকা, আপনাকে অগ্রিম প্রদান করতে হবে।</li>\r\n	<li>অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য নেওয়ার সময়, কুরিয়ার আফিসে পেমেন্ট করতে হবে।</li>\r\n	<li>ঢাকার মধ্যে হোম ডেলিভারি চার্জ 70 টাকা, ঢাকার বাইরে 130 টাকা।</li>\r\n	<li>পন্যের কোয়ালিটি যাচাই করতে চাইলে আমাদের অফিসে চলে আসুন।</li>\r\n	<li>Call For Order 01750445553</li>\r\n</ul>'),
(74, 'home_cat_section', '11,12,4,3,5,6,8,7,9,10'),
(75, 'home_seo_title', NULL),
(76, 'home_seo_content', 'Your domain description here'),
(77, 'home_seo_keywords', 'your,meta,tag,here'),
(78, 'home_about_title', NULL),
(79, 'home_about_content', NULL),
(80, 'bkash', 'Payment- 01300884747'),
(81, 'facebook', 'https://www.facebook.com/gadgetex.com.bd'),
(82, 'youtube', 'https://www.youtube.com/channel/UCiwyycs1VI0yoTJ3s8oCPFg'),
(83, 'twitter', NULL),
(84, 'linked', NULL),
(85, 'map', NULL),
(86, 'home_share_image', '2'),
(87, 'bad_word', 'yes no very good'),
(88, 'bonus', '20'),
(89, 'promosion_offer_active', '1');

-- --------------------------------------------------------

--
-- Table structure for table `order_data`
--

CREATE TABLE `order_data` (
  `order_id` bigint(20) NOT NULL,
  `created_by` varchar(55) COLLATE utf8_unicode_ci DEFAULT 'customer',
  `order_from` varchar(30) COLLATE utf8_unicode_ci DEFAULT 'sohojaffilate.com',
  `staff_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `order_from_affilite_id` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) DEFAULT NULL,
  `order_total` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `shipping_charge` int(11) DEFAULT NULL,
  `discount_price` int(11) NOT NULL DEFAULT 0,
  `affiliate_discount` int(11) DEFAULT NULL,
  `advabced_price` int(11) DEFAULT 0,
  `order_status` varchar(55) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'new',
  `payment_type` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  `products` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `courier_service` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipment_time` datetime DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `order_date` date NOT NULL,
  `modified_time` datetime DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_email` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delevery_address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_area` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_note` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_order_note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `affiliate_order_note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cash_back` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `bonus_balance` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `payWith` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `cashback_balance` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `changed_affilite_commision` float DEFAULT NULL,
  `payment_method` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_data`
--

INSERT INTO `order_data` (`order_id`, `created_by`, `order_from`, `staff_id`, `user_id`, `order_from_affilite_id`, `customer_id`, `order_total`, `shipping_charge`, `discount_price`, `affiliate_discount`, `advabced_price`, `order_status`, `payment_type`, `products`, `courier_service`, `shipment_time`, `created_time`, `order_date`, `modified_time`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `delevery_address`, `coupon_code`, `order_area`, `order_note`, `customer_order_note`, `affiliate_order_note`, `cash_back`, `bonus_balance`, `payWith`, `cashback_balance`, `changed_affilite_commision`, `payment_method`, `transaction_id`) VALUES
(1, 'Customer', 'sohojaffilate.com', 0, 0, 0, NULL, '52130', 60, 0, NULL, 0, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:27;a:5:{s:14:\"featured_image\";s:56:\"http://127.0.0.1:8000/uploads/27/small/27.Tab A7 - 2.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:5:\"52000\";s:8:\"subtotal\";s:5:\"52000\";s:4:\"name\";s:10:\"BCD Tablet\";}}}', NULL, NULL, '2021-12-20 07:23:20', '2021-12-20', NULL, 'sujon ali', '01738305670', 'suzonice15@gmail.com', 'dfdfd', NULL, NULL, 'outside', NULL, 'dfdf', NULL, '0', '0', '0', '0', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_edit_track`
--

CREATE TABLE `order_edit_track` (
  `order_edit_track_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_note` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `page_link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `page_content` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`page_id`, `page_name`, `page_link`, `page_content`, `created_time`) VALUES
(3, 'Contact us', 'contact-us', '<p>test</p>', '2019-10-07 10:18:01'),
(4, 'About Us', 'about-us', '<h1><strong>Your company description</strong></h1>', '2019-11-13 11:56:27'),
(5, 'TERMS & CONDITIONS', 'terms-and-conditions', '<p>description</p>', '2019-10-06 07:30:58'),
(6, 'Track Your Order ', 'page_track', '<ul style=\"list-style-type:circle\">\r\n	<li>1.আপনার অর্ডারের আপডেট জানতে নিচের বক্সে অর্ডার নাম্বার অথবা আপনার মোবাইল নাম্বার দিয়ে Track order বাটনে চাপুন।</li>\r\n	<li>2.To get latest update about your order please enter your order number or mobile number and click on the Track order button</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n', '2019-12-01 12:10:59'),
(8, 'Return Policy', 'return_policy', '<p>Your return policy</p>', '2019-09-01 07:07:54'),
(10, 'Customer  service', 'customer-service', '<p>ddd</p>\r\n\r\n<p>gggg</p>', '2020-07-05 08:13:01'),
(11, 'Guide line', 'shopping', '<p>ffff</p>', '2020-07-14 06:56:48'),
(12, 'Help Center', 'help-center', '<p><span style=\"color:#8e44ad\"><span style=\"font-size:18px\"><strong>your help center description</strong></span></span></p>', '2020-07-14 06:59:33'),
(15, 'promosion term and condition', 'promosion-terms-and-condition', '<ul>\r\n	<li><strong>Your terms and condition</strong></li>\r\n</ul>', '2021-10-01 12:54:37'),
(16, 'SA Paribahan courierdddd', 'ddfdfd', '<p>bhhh</p>', '2021-11-26 02:46:47');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_order_count` int(11) DEFAULT 0,
  `product_price` double DEFAULT NULL,
  `purchase_price` double DEFAULT NULL,
  `product_specification` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount_price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_summary` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_category_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `sub_category` int(11) DEFAULT NULL,
  `product_description` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `warranty_policy` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_terms` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_stock` int(11) DEFAULT NULL,
  `product_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_video` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 active 0 in active',
  `product_ram_rom` varchar(199) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_type` varchar(15) COLLATE utf8_unicode_ci DEFAULT 'general',
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL,
  `folder` int(11) NOT NULL,
  `feasured_image` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_6` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_7` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_8` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_9` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_10` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_1` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_2` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_by` int(11) DEFAULT NULL,
  `galary_image_3` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_4` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `galary_image_5` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_keywords` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_content` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `stock_alert` int(11) DEFAULT NULL,
  `discount` int(11) NOT NULL DEFAULT 0,
  `delivery_in_dhaka` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_out_dhaka` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_order_count`, `product_price`, `purchase_price`, `product_specification`, `discount_price`, `product_summary`, `main_category_id`, `brand_id`, `sub_category`, `product_description`, `warranty_policy`, `product_terms`, `sku`, `product_stock`, `product_color`, `product_video`, `status`, `product_ram_rom`, `product_type`, `created_time`, `modified_time`, `folder`, `feasured_image`, `galary_image_6`, `galary_image_7`, `galary_image_8`, `galary_image_9`, `galary_image_10`, `galary_image_1`, `galary_image_2`, `order_by`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `seo_title`, `seo_keywords`, `seo_content`, `stock_alert`, `discount`, `delivery_in_dhaka`, `delivery_out_dhaka`) VALUES
(5, 'Samsung A32 (4GB | 64GB)', 'Samsung-A32-4GB-64GB-5-5-5-5-5', 0, 90000, 82000, NULL, '86000', NULL, 8, NULL, NULL, NULL, '<p>*** 12 Months Official Warranty Available</p>', NULL, 'GX0001', 20, NULL, NULL, 1, '4GB / 64GB', 'home', '2021-12-09 12:51:26', '2021-12-14 15:31:47', 5, '5.A32-10.jpg', '37.333.jpg', NULL, NULL, NULL, NULL, '97.A32-01.jpg', '42.fsdfdsf.jpg', NULL, '81.111.jpg', '72.222.jpg', '21.222.jpg', NULL, NULL, NULL, NULL, 4, '60', '130'),
(8, 'A1 Powerbank', 'samsung-z-flip-3-172-8-8-8-8-8-8-8-8', 0, 65000, 60000, NULL, '62000', NULL, 5, 7, NULL, NULL, '<p>*** 12 Months Official Warranty</p>', NULL, 'GX0007', 10, NULL, NULL, 1, '8GB / 256GB', 'home', '2021-12-09 17:34:34', '2021-12-11 12:23:00', 8, '8.Powerbank (4).png', '57.Z Flip3-08.jpg', NULL, NULL, NULL, NULL, '68.Powerbank (5).png', '35.Powerbank (1).png', NULL, '28.Z Flip3-03.jpg', '62.Z Flip3-04.jpg', '10.Z Flip3-05.jpg', NULL, NULL, NULL, NULL, 5, '60', '130'),
(9, 'Samsung A21 (6GB | 128GB)', 'samsung-a21-6gb--128gb-233-9-9-9', 0, 60000, 55000, NULL, '57000', NULL, 8, NULL, NULL, NULL, NULL, NULL, 'GX0009', 20, NULL, NULL, 1, '6GB / 128GB', 'home', '2021-12-09 17:57:06', '2021-12-14 15:32:34', 9, '9.A22-10.jpg', '20.A22-05.jpg', NULL, NULL, NULL, NULL, '60.A22-09.jpg', '79.A22-02.jpg', NULL, '21.A22-03.jpg', '82.A22-08.jpg', '45.A22-07.jpg', NULL, NULL, NULL, NULL, 5, '60', '130'),
(10, 'Fantastic Smartwatch', 'samsung-a52-4gb--64gb-226-10-10-10-10-10', 0, 58000, 54000, NULL, '57000', NULL, 4, NULL, NULL, NULL, NULL, NULL, 'GX00002', 15, NULL, NULL, 1, '4GB / 64GB', 'home', '2021-12-09 18:12:10', '2021-12-11 11:53:24', 10, '10.Smartwatch3-removebg-preview.png', '82.A52-03.jpg', NULL, NULL, NULL, NULL, '21.A52-09.jpg', '76.A52-08.jpg', NULL, '76.A52-01.jpg', '20.A52-04.jpg', '99.A52-02.jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(11, 'Samsung A52S (6GB / 64GB)', 'samsung-a52s-6gb--64gb-572-11-11-11-11', 0, 60000, 55000, NULL, '57000', NULL, 8, NULL, NULL, NULL, NULL, NULL, 'GX0015', 20, NULL, NULL, 1, '6GB / 64GB', 'home', '2021-12-09 18:16:32', '2021-12-14 15:33:05', 11, '11.A52S-10.jpg', '57.A52S-01.jpg', NULL, NULL, NULL, NULL, '55.A52S-09.jpg', '15.A52S-08.jpg', NULL, '17.A52S-04.jpg', '27.A52S-03.jpg', '16.A52S-02.jpg', NULL, NULL, NULL, NULL, 5, '60', '130'),
(12, 'Samsung A72', 'samsung-a72--39-12-12-12', 0, 60000, 50000, NULL, '55000', NULL, 8, NULL, NULL, NULL, NULL, NULL, 'GX0011', 50, NULL, NULL, 1, 'sdgdsg', 'home', '2021-12-09 18:19:40', '2021-12-14 15:33:32', 12, '12.A72-10.jpg', '94.A72-03.jpg', NULL, NULL, NULL, NULL, '89.A72-09.jpg', '73.A72-05.jpg', NULL, '63.A72-02.jpg', '15.A72-05.jpg', '15.A72-08.jpg', NULL, NULL, NULL, NULL, 8, '60', '130'),
(13, 'Samsung F22 best product (8/128GB)', 'samsung-f22-612-13-13-13-13-13', 0, 50000, 45000, NULL, '48000', NULL, 11, NULL, NULL, NULL, NULL, NULL, 'GX0012', 20, NULL, NULL, 1, 'dfdf', 'home', '2021-12-09 18:22:57', '2021-12-26 19:53:15', 13, '13.1420.download (1).jpg', NULL, NULL, NULL, NULL, NULL, '17.F22-06.jpg', '77.F22-05.jpg', NULL, '82.F22-02.jpg', '100.F22-01.jpg', '35.F22-04.jpg', NULL, NULL, NULL, NULL, 4, '60', '130'),
(14, 'ABCDE', 'abcde-44-14-14-14', 0, 58000, 60000, NULL, '57000', NULL, 3, NULL, NULL, NULL, NULL, NULL, 'GX0013', 20, NULL, NULL, 1, '6GB / 64GB', 'home', '2021-12-09 18:37:00', '2021-12-11 12:45:40', 14, '14.BS (7).png', NULL, NULL, NULL, NULL, NULL, '92.M32-04.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '60', '130'),
(15, 'Powerbank', 'powerbank-89-15-15-15', 0, 22000, 20000, NULL, '21500', NULL, 5, 6, NULL, NULL, NULL, NULL, 'GX0014', 20, NULL, NULL, 1, '6GB / 128GB', 'home', '2021-12-09 18:39:49', '2021-12-11 12:45:49', 15, '15.Powerbank (3).png', NULL, NULL, NULL, NULL, NULL, '52.Powerbank (4).png', '93.Powerbank (1).png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '60', '130'),
(16, 'Charger A2', 'charger-a2-155-16-16', 0, 57000, 54000, NULL, '55000', NULL, 8, 5, NULL, NULL, NULL, NULL, 'GX0015', 20, NULL, NULL, 1, '4GB / 128GB', 'home', '2021-12-09 18:43:10', '2021-12-14 15:38:34', 16, '16.Mobile_Adapter_2-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, '60.Mobile_Adapter_5-removebg-preview.png', '55.Mobile_Adapter_3-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(17, 'Special Tripod', 'valo-charger-161-17-17', 0, 28000, 25000, NULL, '27000', NULL, 7, 7, NULL, NULL, NULL, NULL, 'GX0016', 30, NULL, NULL, 1, '2GB / 64GB', 'home', '2021-12-09 18:44:52', '2021-12-10 17:39:18', 17, '17.selfie-tripod.jpg', NULL, NULL, NULL, NULL, NULL, '84.Mobile_Adapter_1-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(18, 'Smartwatch 1', 'smartwatch-1-235-18-18-18', 0, 18000, 15000, NULL, '17000', NULL, 7, NULL, NULL, NULL, NULL, NULL, 'GX0017', 30, NULL, NULL, 1, '6GB / 128GB', 'home', '2021-12-09 18:48:43', '2021-12-14 15:40:34', 18, '18.Smartwatch2-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, '23.Smartwatch-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, '60', '130'),
(19, 'Samsung A7 Tablet', 'samsung-a7-tablet-124-19-19', 0, 128000, 120000, NULL, '125000', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0018', 30, NULL, NULL, 1, '6GB / 256GB', 'home', '2021-12-09 18:51:50', '2021-12-14 14:52:33', 19, '19.Tab A7 - 6.jpg', NULL, NULL, NULL, NULL, NULL, '40.Tab A7 - 7.jpg', '61.Tab A7 - 8.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '60', '130'),
(20, 'Samsung A7 Lite', 'samsung-a7-lite-635-20-20', 0, 202000, 200000, NULL, '201500', NULL, 12, NULL, NULL, NULL, NULL, NULL, 'GX0019', 50, NULL, NULL, 1, '8GB / 512GB', 'home', '2021-12-09 18:54:02', '2021-12-14 14:51:59', 20, '20.Gray - Front.png', NULL, NULL, NULL, NULL, NULL, '63.Gray - Back.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '60', '130'),
(21, 'ABVC Tablet', 'abvc-tablet-448-21-21', 0, 25000, 20000, NULL, '24500', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0020', 20, NULL, NULL, 1, '12/24', 'home', '2021-12-10 11:19:31', '2021-12-14 14:51:19', 21, '21.Tab A8 - 4.jpg', NULL, NULL, NULL, NULL, NULL, '81.Tab A8 - 3.jpg', '58.Tab A8 - 3.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '60', '130'),
(22, 'XYZ Tablet', 'xyz-tablet-33-22-22-22', 0, 55000, 50000, NULL, '53000', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0021', 20, NULL, NULL, 1, '8GB/256GB', 'home', '2021-12-10 11:21:44', '2021-12-14 14:50:44', 22, '22.Tab A7 - 1.jpg', NULL, NULL, NULL, NULL, NULL, '95.Tab A7 - 4.jpg', '96.Tab A7 - 3.jpg', NULL, '41.Tab A7 - 1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(23, 'QRS Tablet', 'qrs-tablet-550-23-23-23', 0, 25000, 22000, NULL, '23500', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0022', 50, NULL, NULL, 1, '8GB/128GB', 'home', '2021-12-10 11:23:06', '2021-12-14 14:49:13', 23, '23.Gray - Front.png', NULL, NULL, NULL, NULL, NULL, '72.Gray - Side.png', '64.Gray - Back.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, '60', '130'),
(24, 'PQS Tablet', 'pqs-tablet-415-24-24', 0, 60000, 55000, NULL, '52000', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0023', 50, NULL, NULL, 1, '4GB/64GB', 'home', '2021-12-10 11:25:04', '2021-12-14 14:48:47', 24, '24.Tab A8 - 3.jpg', NULL, NULL, NULL, NULL, NULL, '12.Tab A8 - 4.jpg', '17.Tab A8 - 5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, '60', '130'),
(25, 'DEF Tablet', 'def-tablet-481-25-25', 0, 25000, 20000, NULL, '24000', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0024', 30, NULL, NULL, 1, '6GB/128GB', 'home', '2021-12-10 11:27:01', '2021-12-14 14:45:13', 25, '25.Tab A8 - 4.jpg', NULL, NULL, NULL, NULL, NULL, '63.Tab A8 - 3.jpg', '51.Tab A8 - 1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(26, 'Tablet T10', 'tablet-t10-349-26-26', 0, 28000, 25000, NULL, '27000', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0025', 50, NULL, NULL, 1, '8GB/256GB', 'home', '2021-12-10 11:28:30', '2021-12-14 14:46:43', 26, '26.Tab A8 - 6.jpg', NULL, NULL, NULL, NULL, NULL, '57.Tab A8 - 2.jpg', '99.Tab A8 - 1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(27, 'BCD Tablet', 'bcd-tablet-545-27-27', 0, 55000, 50000, NULL, '52000', NULL, 12, 7, NULL, NULL, NULL, NULL, 'GX0026', 49, NULL, NULL, 1, '6GB/128GB', 'home', '2021-12-10 11:34:42', '2021-12-14 14:47:27', 27, '27.Tab A7 - 2.jpg', NULL, NULL, NULL, NULL, NULL, '56.Tab A7 - 8.jpg', '85.Tab A7 - 4.jpg', NULL, '93.Tab A7 - 5.jpg', '22.Tab A7 - 6.jpg', NULL, NULL, NULL, NULL, NULL, 5, '60', '130'),
(28, 'GadgetEX Tablet', 'gadgetex-tablet-275-28-28-28', 0, 85000, 80000, NULL, '83500', NULL, 12, 6, NULL, NULL, NULL, NULL, 'GX0027', 50, NULL, NULL, 1, '8GB/128GB', 'home', '2021-12-10 11:36:21', '2021-12-14 14:47:55', 28, '28.Tab A7 - 1.jpg', NULL, NULL, NULL, NULL, NULL, '26.Tab A7 - 4.jpg', '77.Tab A7 - 6.jpg', NULL, '61.Tab A7 - 1.jpg', '33.Tab A7 - 5.jpg', NULL, NULL, NULL, NULL, NULL, 2, '60', '130'),
(29, 'Realme 8 4G', 'realme-8-4g-487-29-29-29', 0, 55000, 50000, NULL, '53500', NULL, 11, 7, NULL, NULL, NULL, NULL, 'GX0028', 50, NULL, NULL, 1, '6GB/128GB', 'home', '2021-12-10 11:39:59', '2021-12-14 15:25:54', 29, '29.Realme 8 4G-10.jpg', NULL, NULL, NULL, NULL, NULL, '96.Realme 8 4G-04.jpg', '90.Realme 8 4G-02.jpg', NULL, '52.Realme 8 4G-01.jpg', '28.Realme 8 4G-02.jpg', NULL, NULL, NULL, NULL, NULL, 3, '60', '130'),
(30, 'Realme 8 5G', 'realme-8-5g-354-30-30', 0, 55000, 50000, NULL, '53500', NULL, 11, 4, NULL, NULL, NULL, NULL, 'GX0029', 50, NULL, NULL, 1, '8GB/128GB', 'home', '2021-12-10 11:42:20', '2021-12-14 15:26:55', 30, '30.Realme 8 5G-10.jpg', NULL, NULL, NULL, NULL, NULL, '59.Realme 8 5G-02.jpg', '97.Realme 8 5G-03.jpg', NULL, '15.Realme 8 5G-02.jpg', '12.Realme 8 5G-03.jpg', NULL, NULL, NULL, NULL, NULL, 3, '60', '130'),
(31, 'OPPO Reno 6', 'oppo-reno-6-584-31-31-31', 0, 58000, 55000, NULL, '57000', NULL, 11, 5, NULL, NULL, NULL, NULL, 'GX0030', 50, NULL, NULL, 1, '6GB / 128GB', 'home', '2021-12-10 11:44:11', '2021-12-14 15:27:39', 31, '31.Capture 04.JPG', NULL, NULL, NULL, NULL, NULL, '31.Capture 02.JPG', '91.Capture 05.JPG', NULL, '98.Capture 01.JPG', '31.Capture 02.JPG', '83.Capture 03.JPG', NULL, NULL, NULL, NULL, 2, '60', '130'),
(32, 'OPPO F19 Pro', 'oppo-f19-pro-258-32-32-32', 0, 53000, 50000, NULL, '52000', NULL, 11, 7, NULL, NULL, NULL, NULL, 'GX0031', 50, NULL, NULL, 1, '6GB/128GB', 'home', '2021-12-10 11:45:48', '2021-12-14 15:28:11', 32, '32.F19 Pro-10.jpg', '100.F19 Pro-02.jpg', NULL, NULL, NULL, NULL, '100.F19 Pro-04.jpg', '46.F19 Pro-02.jpg', NULL, '65.F19 Pro-01.jpg', '24.F19 Pro-06.jpg', '52.F19 Pro-09.jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(33, 'OPPO F19', 'oppo-f19-595-33-33-33', 0, 23000, 20000, NULL, '21500', NULL, 11, 4, NULL, NULL, NULL, NULL, 'GX0032', 30, NULL, NULL, 1, '4/28', 'home', '2021-12-10 11:48:10', '2021-12-14 15:28:48', 33, '33.Prism Black.jpeg', '88.Untitled design (6).png', NULL, NULL, NULL, NULL, '56.Untitled design (6).png', '11.Midnight Blue 1.png', NULL, '14.Untitled design (5).png', '75.Untitled design (2).png', '58.Midnight Blue 1.png', NULL, NULL, NULL, NULL, 7, '60', '130'),
(34, 'A1 Bluetooth Speaker', 'a1-bluetooth-speaker-185-34', 0, 28000, 25000, NULL, '27000', NULL, 3, 5, NULL, NULL, NULL, NULL, 'GX0033', 35, NULL, NULL, 1, '4/128', 'home', '2021-12-10 12:04:47', '2021-12-10 17:31:49', 34, '34.BS (10).png', '48.BS (5).png', NULL, NULL, NULL, NULL, '95.BS (11).png', '68.BS (9).png', NULL, '54.BS (8).png', '98.BS (7).png', '78.BS (6).png', NULL, NULL, NULL, NULL, 4, '60', '130'),
(35, 'B2 Bluetooth Speaker', 'b2-bluetooth-speaker-190-35-35', 0, 23000, 20000, NULL, '22000', NULL, 3, 2, NULL, NULL, NULL, NULL, 'GX0034', 50, NULL, NULL, 1, '6/256', 'home', '2021-12-10 12:06:41', '2021-12-13 20:51:11', 35, '35.BS (2).png', '30.BS (7).png', NULL, NULL, NULL, NULL, '21.BS (1).png', '56.BS (3).png', NULL, '76.BS (5).png', '83.BS (11).png', '26.BS (9).png', NULL, NULL, NULL, NULL, 4, '60', '130'),
(36, 'C3 Bluetooth Speaker', 'c3-bluetooth-speaker-75-36-36', 0, 8000, 5000, NULL, '6000', NULL, 3, 7, NULL, NULL, NULL, NULL, 'GX0035', 50, NULL, NULL, 1, '6/128', 'home', '2021-12-10 12:09:00', '2021-12-13 20:50:55', 36, '36.Earbud_3-removebg-preview.png', '22.Earbud_2-removebg-preview.png', NULL, NULL, NULL, NULL, '73.Earbud_6-removebg-preview.png', '28.Earbud_7-removebg-preview.png', NULL, '88.Earbud_2-removebg-preview.png', '93.Earbud_5-removebg-preview.png', '27.Earbud_1-removebg-preview.png', NULL, NULL, NULL, NULL, 25, '60', '130'),
(37, 'D4 Bluetooth Speaker', 'd4-bluetooth-speaker-534-37-37', 0, 33000, 30000, NULL, '31500', NULL, 3, 4, NULL, NULL, NULL, NULL, 'GX0036', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 12:10:41', '2021-12-13 20:50:30', 37, '37.Earphone_1-removebg-preview.png', '89.Earphone_1-removebg-preview.png', NULL, NULL, NULL, NULL, '79.Earphone_6-removebg-preview.png', '59.Earphone_4-removebg-preview.png', NULL, '55.Earphone_2-removebg-preview.png', '91.Earphone_5-removebg-preview.png', '78.Earphone_2-removebg-preview.png', NULL, NULL, NULL, NULL, 5, '60', '130'),
(38, 'Sound Item', 'sound-item-347-38-38', 0, 33000, 30000, NULL, '32000', NULL, 3, 8, NULL, NULL, NULL, NULL, 'GX0037', 50, NULL, NULL, 1, '6GB/128GB', 'home', '2021-12-10 12:12:40', '2021-12-13 20:50:10', 38, '38.Earphone_6-removebg-preview.png', '65.Earphone_1-removebg-preview.png', NULL, NULL, NULL, NULL, '93.Earphone_2-removebg-preview.png', '86.Earphone_5-removebg-preview.png', NULL, '82.Earphone_5-removebg-preview.png', '93.Earphone_1-removebg-preview.png', '77.Earphone_2-removebg-preview.png', NULL, NULL, NULL, NULL, 3, '60', '130'),
(39, 'E5 Bluetooth Speaker', 'e5-bluetooth-speaker-181-39-39', 0, 25000, 23000, NULL, '24000', NULL, 3, 7, NULL, NULL, NULL, NULL, 'GX0038', 30, NULL, NULL, 1, '4GB/128GB', 'home', '2021-12-10 12:14:28', '2021-12-13 20:49:34', 39, '39.Headphone_4-removebg-preview.png', '32.Headphone_5-removebg-preview.png', NULL, NULL, NULL, NULL, '68.Headphone_8-removebg-preview.png', '55.Headphone_5-removebg-preview.png', NULL, '100.Headphone_3-removebg-preview.png', '23.Headphone_1-removebg-preview.png', '42.Headphone_2-removebg-preview.png', NULL, NULL, NULL, NULL, 4, '60', '130'),
(40, 'Speaker PQR', 'speaker-pqr-270-40-40-40', 0, 7000, 5000, NULL, '6000', NULL, 3, 6, NULL, NULL, NULL, NULL, 'GX0039', 20, NULL, NULL, 1, '4/128', 'home', '2021-12-10 12:28:23', '2021-12-13 20:47:54', 40, '40.Earbud_5-removebg-preview.png', '73.BS (3).png', NULL, NULL, NULL, NULL, '91.BS (5).png', '11.BS (2).png', NULL, '84.BS (5).png', '19.BS (9).png', '96.BS (5).png', NULL, NULL, NULL, NULL, 14, '60', '130'),
(41, 'A1 Speaker', 'a1-speaker-610-41-41', 0, 22200, 20000, NULL, '21200', NULL, 3, 7, NULL, NULL, NULL, NULL, 'GX0040', 50, NULL, NULL, 1, '4/64', 'home', '2021-12-10 12:56:52', '2021-12-13 20:47:31', 41, '41.BS (1).png', NULL, NULL, NULL, NULL, NULL, '88.BS (3).png', '55.BS (5).png', NULL, '19.BS (6).png', '26.BS (8).png', '99.BS (9).png', NULL, NULL, NULL, NULL, 5, '60', '130'),
(42, 'Fatafati Speaker', 'fatafati-speaker-130-42-42', 0, 28000, 25000, NULL, '27000', NULL, 3, 4, NULL, NULL, NULL, NULL, 'GX0041', 20, NULL, NULL, 1, '4/64', 'home', '2021-12-10 13:00:20', '2021-12-13 20:47:12', 42, '42.Earbud_6-removebg-preview.png', '45.Earbud_1-removebg-preview.png', NULL, NULL, NULL, NULL, '14.Earbud_7-removebg-preview.png', '72.Earbud_3-removebg-preview.png', NULL, '43.Earbud_1-removebg-preview.png', '22.Earbud_2-removebg-preview.png', '76.Earbud_3-removebg-preview.png', NULL, NULL, NULL, NULL, 4, '60', '130'),
(43, 'Moto E7 Plus', 'moto-e7-plus-354-43-43-43', 0, 55000, 52000, NULL, '53500', NULL, 11, 8, NULL, NULL, NULL, NULL, 'GX0042', 50, NULL, NULL, 1, '8/64', 'home', '2021-12-10 13:02:32', '2021-12-13 20:46:44', 43, '43.Moto E7 Plus-10.jpg', '71.Moto E7 Plus-01.jpg', NULL, NULL, NULL, NULL, '58.Moto E7 Plus-07.jpg', '31.Moto E7 Plus-03.jpg', NULL, '85.Moto E7 Plus-02.jpg', '12.Moto E7 Plus-08.jpg', '10.Moto E7 Plus-02.jpg', NULL, NULL, NULL, NULL, 3, '60', '130'),
(44, 'Moto G9 Play', 'moto-g9-play-161-44-44', 0, 55000, 52000, NULL, '54000', NULL, 11, 2, NULL, NULL, NULL, NULL, 'GX0043', 40, NULL, NULL, 1, '4/64', 'home', '2021-12-10 13:04:49', '2021-12-13 20:46:23', 44, '44.Moto G9 Play-10.jpg', '49.Moto G9 Play-01.jpg', NULL, NULL, NULL, NULL, '77.Moto G9 Play-03.jpg', '81.Moto G9 Play-04.jpg', NULL, '10.Moto G9 Play-02.jpg', '20.Moto G9 Play-01.jpg', '76.Moto G9 Play-03.jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(45, 'Moto g40 FUSION', 'moto-g40-fusion-44-45-45', 0, 85000, 82000, NULL, '84500', NULL, 11, 4, NULL, NULL, NULL, NULL, 'GX0044', 50, NULL, NULL, 1, '8GB/256GB', 'home', '2021-12-10 13:06:35', '2021-12-13 20:45:39', 45, '45.Moto g40 FUSION-10.jpg', '14.Moto g40 FUSION-01.jpg', NULL, NULL, NULL, NULL, '99.Moto g40 FUSION-09.jpg', '22.Moto g40 FUSION-05.jpg', NULL, '20.Moto g40 FUSION-03.jpg', '78.Moto g40 FUSION-05.jpg', '56.Moto g40 FUSION-02.jpg', NULL, NULL, NULL, NULL, 1, '60', '130'),
(46, 'Moto G10 power', 'moto-g40-fusion-111-46-46-46', 0, 85000, 82000, NULL, '84500', NULL, 11, 4, NULL, NULL, NULL, NULL, 'GX0044', 50, NULL, NULL, 1, '8GB/256GB', 'home', '2021-12-10 13:06:42', '2021-12-13 20:45:01', 45, '46.Moto g40 FUSION-10.jpg', '94.Moto g40 FUSION-01.jpg', NULL, NULL, NULL, NULL, '95.Moto g40 FUSION-09.jpg', '70.Moto g40 FUSION-05.jpg', NULL, '47.Moto g40 FUSION-03.jpg', '96.Moto g40 FUSION-05.jpg', '55.Moto g40 FUSION-02.jpg', NULL, NULL, NULL, NULL, 1, '60', '130'),
(47, 'A1 Smartwatch', 'a1-smartwatch--89-47-47', 0, 27000, 25000, NULL, '26000', NULL, 4, 4, NULL, NULL, NULL, NULL, 'GX0046', 30, NULL, NULL, 1, '4/64', 'home', '2021-12-10 13:55:59', '2021-12-13 20:44:25', 47, '47.tetqwtqwt.jpg', NULL, NULL, NULL, NULL, NULL, '86.yweyweywey.jpg', '27.qwtrqwtqwt.jpg', NULL, '99.hsdhsd.jpg', '19.hsddshgs.jpg', '40.eyweywey.jpg', NULL, NULL, NULL, NULL, 4, '60', '130'),
(48, 'Exclusive Smartwatch', 'exclusive-smartwatch-211-48-48', 0, 27000, 25000, NULL, '26500', NULL, 4, 4, NULL, NULL, NULL, NULL, 'GX0047', 20, NULL, NULL, 1, '6/128', 'home', '2021-12-10 13:58:47', '2021-12-13 20:44:04', 48, '48.download.jpg', '10.Smartwatch2-removebg-preview.png', NULL, NULL, NULL, NULL, '69.yweyweywey.jpg', '57.Smartwatch4-removebg-preview.png', NULL, '48.Smartwatch1-removebg-preview.png', '71.hsdhsd.jpg', '82.Smartwatch1-removebg-preview.png', NULL, NULL, NULL, NULL, 2, '60', '130'),
(49, 'BV2 Smartwatch', 'bv2-smartwatch-548-49-49', 0, 5300, 5000, NULL, '5250', NULL, 4, 7, NULL, NULL, NULL, NULL, 'GX0048', 30, NULL, NULL, 1, '8/256', 'home', '2021-12-10 14:00:16', '2021-12-13 20:43:44', 49, '49.xgfdaga.jpeg', '78.download.jpg', NULL, NULL, NULL, NULL, '50.yweyweywey.jpg', '84.Smartwatch3-removebg-preview.png', NULL, '38.qwtrqwtqwt.jpg', '36.hsdhsd.jpg', '94.eyweywey.jpg', NULL, NULL, NULL, NULL, 1, '60', '130'),
(50, 'Fatafati Smartwatch', 'fatafati-smartwatch-127-50-50', 0, 27000, 25000, NULL, '26000', NULL, 4, 4, NULL, NULL, NULL, NULL, 'GX0049', 20, NULL, NULL, 1, '6/256', 'home', '2021-12-10 14:01:51', '2021-12-13 20:43:24', 50, '50.qwtrqwtqwt.jpg', '91.download.jpg', NULL, NULL, NULL, NULL, '95.xgfdaga.jpeg', '86.yweyweywey.jpg', NULL, '46.qwtqwtqwt.jpg', '43.hsddshgs.jpg', '91.eyweywey.jpg', NULL, NULL, NULL, NULL, 4, '60', '130'),
(51, 'Latest Smartwatch', 'latest-smartwatch-538-51-51', 0, 17000, 15000, NULL, '16200', NULL, 4, 6, NULL, NULL, NULL, NULL, 'GX0050', 20, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:03:14', '2021-12-13 20:43:00', 51, '51.qwtqwtqwt.jpg', '31.Smartwatch3-removebg-preview.png', NULL, NULL, NULL, NULL, '78.Smartwatch3-removebg-preview.png', '79.tetqwtqwt.jpg', NULL, '77.xgfdaga.jpeg', '57.yweyweywey.jpg', '69.hsddshgs.jpg', NULL, NULL, NULL, NULL, 5, '60', '130'),
(52, 'Opp Smartwatch', 'o-smartwatch-131-52-52-52-52-52', 0, 26000, 25000, NULL, '25500', NULL, 4, 6, NULL, NULL, NULL, NULL, 'GX0051', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:05:05', '2021-12-13 20:41:43', 52, '52.hsdhsd.jpg', '50.hsdhsd.jpg', NULL, NULL, NULL, NULL, '90.Smartwatch4-removebg-preview.png', '43.xgfdaga.jpeg', NULL, '77.qwtrqwtqwt.jpg', '90.qwtqwtqwt.jpg', '32.yweyweywey.jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(53, 'Smartwatch B2', 'smartwatch-b2-473-53-53-53', 0, 27000, 25000, NULL, '26500', NULL, 4, 8, NULL, NULL, NULL, NULL, 'GX0052', 20, NULL, NULL, 1, '6/256', 'home', '2021-12-10 14:08:49', '2021-12-13 20:40:55', 53, '53.Smartwatch1-removebg-preview.png', '58.hsddshgs.jpg', NULL, NULL, NULL, NULL, '36.xgfdaga.jpeg', '65.yweyweywey.jpg', NULL, '76.Smartwatch4-removebg-preview.png', '60.Smartwatch-removebg-preview.png', '81.yweyweywey.jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(54, 'Smartwatch D4', 'smartwatch-d4-297-54-54', 0, 26000, 25000, NULL, '25700', NULL, 4, 4, NULL, NULL, NULL, NULL, 'GX0053', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:15:15', '2021-12-13 20:40:34', 54, '54.Smartwatch-removebg-preview.png', '53.eyweywey.jpg', NULL, NULL, NULL, NULL, '11.xgfdaga.jpeg', '23.yweyweywey.jpg', NULL, '79.Smartwatch3-removebg-preview.png', '100.hsddshgs.jpg', '74.hsdhsd.jpg', NULL, NULL, NULL, NULL, 1, '60', '130'),
(55, 'B2 Powerbank', 'b2-powerbank-601-55-55-55', 0, 25000, 22000, NULL, '23500', NULL, 5, 9, NULL, NULL, NULL, NULL, 'GX0054', NULL, NULL, NULL, 1, '6/256', 'home', '2021-12-10 14:21:58', '2021-12-13 20:36:26', 55, '55.Powerbank (2).png', '80.Powerbank (5).png', NULL, NULL, NULL, NULL, '92.Powerbank (5).png', '83.Powerbank (4).png', NULL, '76.Powerbank (1).png', '57.Powerbank (2).png', '75.Powerbank (4).png', NULL, NULL, NULL, NULL, 6, '60', '130'),
(56, 'Powerbank t3', 'powerbank-t3-513-56-56', 0, 22000, 20000, NULL, '21000', NULL, 5, 2, NULL, NULL, NULL, NULL, 'GX0055', NULL, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:35:11', '2021-12-13 20:36:06', 56, '56.download (2).jpg', NULL, NULL, NULL, NULL, NULL, '34.power-bank-2000mah-pink-819-550x550.jpg', '26.Powerbank (3).png', NULL, '98.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 5, '60', '130'),
(57, 'T7 Powerbank', 't7-powerbank-559-57-57-57', 0, 27000, 25000, NULL, '26000', NULL, 5, 2, NULL, NULL, NULL, NULL, 'GX0055', 20, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:38:18', '2021-12-13 20:35:47', 57, '57.images (1).jpg', NULL, NULL, NULL, NULL, NULL, '46.power-bank-2000mah-pink-819-550x550.jpg', '30.Powerbank (3).png', NULL, '12.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', '31.Powerbank (4).png', NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(58, 'JPT Powerbank', 'jpt-powerbank-564-58-58', 0, 17000, 15000, NULL, '16500', NULL, 5, 5, NULL, NULL, NULL, NULL, 'GX0057', 30, NULL, NULL, 1, '6/256', 'home', '2021-12-10 14:40:10', '2021-12-13 20:35:30', 58, '58.eng_pl_NonStop-PowerBank-Sella-Black-20800mAh-1295_5.jpg', '59.Powerbank (4).png', NULL, NULL, NULL, NULL, '47.download (1).jpg', '63.Powerbank (2).png', NULL, '18.Powerbank (4).png', '24.Powerbank (5).png', '80.81mI9dvL8dL._AC_SL1500_.jpg', NULL, NULL, NULL, NULL, 3, '60', '130'),
(59, 'Super Powerbank', 'super-powerbank-355-59-59', 0, 22000, 21000, NULL, '21500', NULL, 5, 9, NULL, NULL, NULL, NULL, 'GX0058', 30, NULL, NULL, 1, '6/256', 'home', '2021-12-10 14:49:43', '2021-12-13 20:34:42', 59, '59.download.jpg', NULL, NULL, NULL, NULL, NULL, '40.Powerbank (1).png', '60.Powerbank (2).png', NULL, '43.81mI9dvL8dL._AC_SL1500_.jpg', '19.download (2).jpg', '52.images (1).jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(60, 'P2 Powerbank', 'p2-powerbank-12-60-60', 0, 26000, 25000, NULL, '25500', NULL, 5, 4, NULL, NULL, NULL, NULL, 'GX0059', 40, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:50:59', '2021-12-13 20:34:11', 60, '60.download (1).jpg', NULL, NULL, NULL, NULL, NULL, '32.Powerbank (2).png', '26.Powerbank (5).png', NULL, '70.power-bank-2000mah-pink-819-550x550.jpg', '93.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', '84.Powerbank (4).png', NULL, NULL, NULL, NULL, 2, '60', '130'),
(61, 'HDB Powerbank', 'hdb-powerbank-414-61-61', 0, 26000, 25000, NULL, '25500', NULL, 5, 4, NULL, NULL, NULL, NULL, 'GX0060', 30, NULL, NULL, 1, '4/256', 'home', '2021-12-10 14:52:44', '2021-12-13 20:33:46', 61, '61.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', '99.black-and-white-power-bank-5200mah-type-travel-500x500.jpg', NULL, NULL, NULL, NULL, '34.Powerbank (1).png', '87.Powerbank (4).png', NULL, '27.power-bank-2000mah-pink-819-550x550.jpg', '45.images.jpg', '63.download (2).jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(62, 'UPB Powerbank', 'upb-powerbank-284-62-62', 0, 22000, 21000, NULL, '21500', NULL, 5, 8, NULL, NULL, NULL, NULL, 'GX0061', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 14:56:15', '2021-12-13 20:32:44', 62, '62.Powerbank (1).png', '91.81mI9dvL8dL._AC_SL1500_.jpg', NULL, NULL, NULL, NULL, '50.images (1).jpg', '76.Powerbank (4).png', NULL, '20.power-bank-2000mah-pink-819-550x550.jpg', '47.images.jpg', '45.download (1).jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(63, 'Fatafati Charger', 'fatafati-charger-348-63-63-63', 0, 26500, 25000, NULL, '26000', NULL, 8, 4, NULL, NULL, NULL, NULL, 'GX0062', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 15:07:58', '2021-12-14 15:37:33', 63, '63.download.jpg', NULL, NULL, NULL, NULL, NULL, '15.Mobile_Adapter_4-removebg-preview.png', '83.Mobile_Adapter_6-removebg-preview.png', NULL, '30.Mobile_Adapter_2-removebg-preview.png', '100.download (3).jpg', '51.680961349361_1-85962.jpg', NULL, NULL, NULL, NULL, 2, '60', '130'),
(64, 'A1 Charger', 'a1-charger-484-64-64-64', 0, 16000, 15000, NULL, '15500', NULL, 8, 8, NULL, NULL, NULL, NULL, 'GX0063', 40, NULL, NULL, 1, '6/256', 'home', '2021-12-10 15:09:11', '2021-12-14 15:38:05', 64, '64.Mobile_Adapter_5-removebg-preview.png', '74.61NfFCwsneL._SL1500_.jpg', NULL, NULL, NULL, NULL, '100.Mobile_Adapter_6-removebg-preview.png', '23.Mobile_Adapter_2-removebg-preview.png', NULL, '28.download.jpg', '11.download (3).jpg', '34.680961349361_1-85962.jpg', NULL, NULL, NULL, NULL, 3, '60', '130'),
(65, 'PQRP Charger', 'pqrp-charger-483-65-65', 0, 14500, 13000, NULL, '14000', NULL, 6, 2, NULL, NULL, NULL, NULL, 'GX0064', 50, NULL, NULL, 1, '4/64', 'home', '2021-12-10 15:10:18', '2021-12-11 11:40:58', 65, '65.Mobile_Adapter_6-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, '14.Mobile_Adapter_4-removebg-preview.png', '50.Mobile_Adapter_3-removebg-preview.png', NULL, '98.Mobile_Adapter_1-removebg-preview.png', NULL, NULL, NULL, NULL, NULL, NULL, 3, '60', '130'),
(66, 'HRP Charger', 'hrp-charger-444-66-66', 0, 16500, 15000, NULL, '16000', NULL, 6, 8, NULL, NULL, NULL, NULL, 'GX0065', 30, NULL, NULL, 1, '4/64', 'home', '2021-12-10 15:11:44', '2021-12-11 11:41:18', 66, '66.Mobile_Adapter_1-removebg-preview.png', '50.61NfFCwsneL._SL1500_.jpg', NULL, NULL, NULL, NULL, '27.Mobile_Adapter_5-removebg-preview.png', '74.Mobile_Adapter_6-removebg-preview.png', NULL, '52.Mobile_Adapter_1-removebg-preview.png', '40.download (3).jpg', '70.Mobile_Adapter_6-removebg-preview.png', NULL, NULL, NULL, NULL, 3, '60', '130'),
(67, 'PPR Charger', 'ppr-charger-487-67-67-67', 0, 19000, 18000, NULL, '20000', NULL, 6, 8, NULL, NULL, NULL, NULL, 'GX0066', 40, NULL, NULL, 1, '4/64', 'home', '2021-12-10 15:13:45', '2021-12-11 11:41:38', 67, '67.680961349361_1-85962.jpg', '27.Mobile_Adapter_5-removebg-preview.png', NULL, NULL, NULL, NULL, '89.Mobile_Adapter_4-removebg-preview.png', '25.Mobile_Adapter_5-removebg-preview.png', NULL, '18.Mobile_Adapter_6-removebg-preview.png', '35.61NfFCwsneL._SL1500_.jpg', '24.Mobile_Adapter_3-removebg-preview.png', NULL, NULL, NULL, NULL, -5, '60', '130'),
(68, 'RTR Charger', 'rtr-charger-215-68-68', 0, 16500, 15000, NULL, '16000', NULL, 6, 7, NULL, NULL, NULL, NULL, 'GX0067', 20, NULL, NULL, 1, '4/128', 'home', '2021-12-10 15:15:47', '2021-12-11 11:41:48', 68, '68.Mobile_Adapter_4-removebg-preview.png', '19.61NfFCwsneL._SL1500_.jpg', NULL, NULL, NULL, NULL, '41.Mobile_Adapter_6-removebg-preview.png', '42.Mobile_Adapter_3-removebg-preview.png', NULL, '99.Mobile_Adapter_1-removebg-preview.png', '80.download (3).jpg', '47.680961349361_1-85962.jpg', NULL, NULL, NULL, NULL, 3, '60', '130'),
(69, 'NBV Charger', 'nbv-charger-539-69-69', 0, 16500, 15000, NULL, '16000', NULL, 6, 9, NULL, NULL, NULL, NULL, 'GX0068', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 15:18:12', '2021-12-11 11:42:18', 69, '69.download (3).jpg', '67.Mobile_Adapter_4-removebg-preview.png', NULL, NULL, NULL, NULL, '43.Mobile_Adapter_6-removebg-preview.png', '82.Mobile_Adapter_4-removebg-preview.png', NULL, '80.Mobile_Adapter_1-removebg-preview.png', '49.download.jpg', '44.download (3).jpg', NULL, NULL, NULL, NULL, 3, '60', '130'),
(70, 'HBTI Charger', 'hbti-charger-316-70-70-70', 0, 16500, 15000, NULL, '16000', NULL, 6, 4, NULL, NULL, NULL, NULL, 'GX0069', 30, NULL, NULL, 1, '6/128', 'home', '2021-12-10 15:20:21', '2021-12-11 11:51:46', 70, '70.Mobile_Adapter_3-removebg-preview.png', '56.download (3).jpg', NULL, NULL, NULL, NULL, '65.Mobile_Adapter_6-removebg-preview.png', '27.Mobile_Adapter_4-removebg-preview.png', NULL, '96.Mobile_Adapter_1-removebg-preview.png', '32.Mobile_Adapter_5-removebg-preview.png', '18.Mobile_Adapter_6-removebg-preview.png', NULL, NULL, NULL, NULL, 3, '60', '130'),
(71, 'YPR Charger', 'ypr-charger-225-71-71-71', 0, 15500, 14000, NULL, '15000', NULL, 6, 7, NULL, NULL, NULL, NULL, 'GX0070', 40, NULL, NULL, 1, '4/64', 'home', '2021-12-10 15:24:30', '2021-12-13 20:29:16', 71, '71.61NfFCwsneL._SL1500_.jpg', '80.Mobile_Adapter_6-removebg-preview.png', NULL, NULL, NULL, NULL, '55.Mobile_Adapter_5-removebg-preview.png', '94.Mobile_Adapter_6-removebg-preview.png', NULL, '58.Mobile_Adapter_2-removebg-preview.png', '16.download.jpg', '86.Mobile_Adapter_5-removebg-preview.png', NULL, NULL, NULL, NULL, 3, '60', '130'),
(72, 'Tripod A1', 'tripod-a1-566-72-72', 0, 13500, 12000, NULL, '13000', NULL, 7, 8, NULL, NULL, NULL, NULL, 'GX0071', 40, NULL, NULL, 1, '4/64', 'home', '2021-12-10 15:39:52', '2021-12-13 20:28:51', 72, '72.godox-p90l-parabol-softbox-90-cm.jpg', NULL, NULL, NULL, NULL, NULL, '23.download (1).jpg', '66.download (3).jpg', NULL, '16.selfie-tripod.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(73, 'Tripod X2', 'tripod-x2-455-73-73', 0, 2700, 2500, NULL, '2600', NULL, 7, 8, NULL, NULL, NULL, NULL, 'GX0072', 40, NULL, NULL, 1, '4/64', 'home', '2021-12-10 17:04:06', '2021-12-13 20:28:27', 73, '73.rode-tripod-2-folded-out-mar-2021-1080-1080-rgb.png', NULL, NULL, NULL, NULL, NULL, '68.u_10218727.jpg', '57.dfdfdf.png', NULL, '77.u_10218727.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(74, 'Softbox', 'softbox-608-74-74', 0, 3750, 3500, NULL, '3700', NULL, 7, 4, NULL, NULL, NULL, NULL, 'GX0073', 20, NULL, NULL, 1, '4GB/256GB', 'home', '2021-12-10 17:05:24', '2021-12-13 20:27:24', 74, '74.download (1).jpg', NULL, NULL, NULL, NULL, NULL, '13.godox-p90l-parabol-softbox-90-cm.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '60', '130'),
(75, 'Light Box', 'light-box-471-75-75', 0, 5700, 5500, NULL, '5600', NULL, 7, 5, NULL, NULL, NULL, NULL, 'GX0074', 30, NULL, NULL, 1, '4GB/64GB', 'home', '2021-12-10 17:06:42', '2021-12-13 20:27:04', 75, '75.wrqwrqw.jpg', NULL, NULL, NULL, NULL, NULL, '62.wrqwrqw.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '60', '130'),
(76, 'Softlight Box', 'softlight-box-581-76-76', 0, 9000, 8500, NULL, '8700', NULL, 7, 5, NULL, NULL, NULL, NULL, 'GX0075', 50, NULL, NULL, 1, '8/128', 'home', '2021-12-10 17:08:07', '2021-12-13 20:26:21', 76, '76.download (2).jpg', NULL, NULL, NULL, NULL, NULL, '46.download (1).jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, '60', '130'),
(77, 'FTR Trimmer', 'ftr-trimmer-589-77-77', 0, 7500, 6000, NULL, '7100', NULL, 9, 5, NULL, NULL, NULL, NULL, 'GX0076', 50, NULL, NULL, 1, '5/60', 'home', '2021-12-10 17:09:24', '2021-12-13 20:26:02', 77, '77.0010067_philips-beard-trimmer-bt310215.jpeg', NULL, NULL, NULL, NULL, NULL, '56.51cOhvN5ZDL.jpg', '85.o]ryr.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, '60', '130'),
(78, 'T17 Trimmer', 't17-trimmer-510-78-78', 0, 2800, 2500, NULL, '2700', NULL, 9, 4, NULL, NULL, NULL, NULL, 'GX0077', 50, NULL, NULL, 1, '6/180', 'home', '2021-12-10 17:10:28', '2021-12-13 20:25:42', 78, '78.0010066_philips-beard-trimmer-bt321515.jpeg', NULL, NULL, NULL, NULL, NULL, '77.yreyrey.jpg', '24.0010066_philips-beard-trimmer-bt321515.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(79, 'TURA Vacuum Cleaner', 'tura-vacuum-cleaner-543-79-79', 0, 12000, 10000, NULL, '11000', NULL, 9, 6, NULL, NULL, NULL, NULL, 'GX0078', 50, NULL, NULL, 1, '6/256', 'home', '2021-12-10 17:11:39', '2021-12-13 20:25:18', 79, '79.d0.jpg', NULL, NULL, NULL, NULL, NULL, '13.Panasonic-MC-CG331-Vacuum-Cleaner.jpg', '23.61tH1osluML._SL1200_.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, '60', '130'),
(80, 'HERO Floor Cleaner', 'hero-floor-cleaner-589-80-80', 0, 50000, 45000, NULL, '48000', NULL, 9, 6, NULL, NULL, NULL, NULL, 'GX0079', 50, NULL, NULL, 1, '10/80', 'home', '2021-12-10 17:12:43', '2021-12-13 20:25:04', 80, '80.8835343200-LO2-20200106-082623.png', NULL, NULL, NULL, NULL, NULL, '71.Panasonic-MC-CG331-Vacuum-Cleaner.jpg', '14.philips-canister-vacuum-cleaner-1800w-fc9350.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '60', '130'),
(81, 'Fatafati Floor Cleaner', 'fatafati-floor-cleaner-481-81-81', 0, 60000, 50000, NULL, '57000', NULL, 9, 8, NULL, NULL, NULL, NULL, 'GX0080', 50, NULL, NULL, 1, '10/500', 'home', '2021-12-10 17:13:51', '2021-12-13 20:24:24', 81, '81.61tH1osluML._SL1200_.jpg', NULL, NULL, NULL, NULL, NULL, '25.Panasonic-MC-CG331-Vacuum-Cleaner.jpg', '86.d0.jpg', NULL, '48.8835343200-LO2-20200106-082623.png', NULL, NULL, NULL, NULL, NULL, NULL, 5, '60', '130'),
(82, 'Exclusive Cleaner', 'exclusive-cleaner-475-82-82', 0, 6000, 5000, NULL, '5500', NULL, 9, 4, NULL, NULL, NULL, NULL, 'GX0081', 50, NULL, NULL, 1, '10/100', 'home', '2021-12-10 17:15:02', '2021-12-13 20:23:56', 82, '82.8835343200-LO2-20200106-082623.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, '60', '130');
INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_order_count`, `product_price`, `purchase_price`, `product_specification`, `discount_price`, `product_summary`, `main_category_id`, `brand_id`, `sub_category`, `product_description`, `warranty_policy`, `product_terms`, `sku`, `product_stock`, `product_color`, `product_video`, `status`, `product_ram_rom`, `product_type`, `created_time`, `modified_time`, `folder`, `feasured_image`, `galary_image_6`, `galary_image_7`, `galary_image_8`, `galary_image_9`, `galary_image_10`, `galary_image_1`, `galary_image_2`, `order_by`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `seo_title`, `seo_keywords`, `seo_content`, `stock_alert`, `discount`, `delivery_in_dhaka`, `delivery_out_dhaka`) VALUES
(83, 'Sei Rokom Trimmer', 'sei-rokom-trimmer-579-83-83-83', 0, 6000, 5000, '<table cellspacing=\"0\" class=\"MsoTableGrid\" style=\"border-collapse:collapse; border:none; width:732px\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"height:28px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Brand</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:28px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Samsung</span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Model</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">A32</span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Network</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/samsung_galaxy_a22-10948.php\" style=\"color:blue; text-decoration:underline\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">GSM / HSPA / LTE</span></span></span></a></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Display Type</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Super AMOLED, 90Hz, 800 nits (HBM)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Display Size</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">6.4 inches, 98.9 cm</span></span></span><sup><span style=\"font-size:8.5pt\"><span style=\"font-family:&quot;inherit&quot;,&quot;serif&quot;\"><span style=\"color:black\">2</span></span></span></sup><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">&nbsp;(~84.6% screen-to-body ratio)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Body Dimensions</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">158.9 x 73.6 x 8.4 mm (6.26 x 2.90 x 0.33 in)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Weight</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">184 g (6.49 oz)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Build</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Glass front (Gorilla Glass 5), plastic frame, plastic back</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Sim</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Single SIM (Nano-SIM) or Dual SIM (Nano-SIM, dual stand-by)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:28px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Operating System</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:28px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Android 11, One UI 3.1</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Chipset</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">MediatekHelio G80 (12 nm)&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">CPU</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Octa-core (2x2.0 GHz Cortex-A75 &amp; 6x1.8 GHz Cortex-A55)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">GPU</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Mali-G52 MC2</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Ram</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">4GB</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Storage</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">64GB</span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Back Camera</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=camera\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">Quad</span></span></span></strong></a> - </span></span></p>\r\n\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">64 MP, f/1.8, 26mm (wide), PDAF<br />\r\n			8 MP, f/2.2, 123˚, (ultrawide), 1/4.0&quot;, 1.12&micro;m<br />\r\n			5 MP, f/2.4, (macro)<br />\r\n			5 MP, f/2.4, (depth)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Front Camera</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">20 MP, f/2.2, (wide)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"6\" style=\"height:3px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Connectivities</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:114px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=wi-fi\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">WLAN</span></span></span></strong></a></span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:396px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Wi-Fi 802.11 a/b/g/n/ac, dual-band, Wi-Fi Direct, hotspot</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:114px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=bluetooth\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">Bluetooth</span></span></span></strong></a></span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:396px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">5.0, A2DP, LE</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:114px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=gps\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">GPS</span></span></span></strong></a></span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:396px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Yes, with A-GPS, GLONASS, GALILEO, BDS</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:114px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=nfc\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">NFC</span></span></span></strong></a></span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:396px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">No</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:114px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=fm-radio\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">Radio</span></span></span></strong></a></span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:396px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Unspecified</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:114px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=usb\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">USB</span></span></span></strong></a></span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:396px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">USB Type-C 2.0</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Sensors</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Fingerprint (side-mounted), accelerometer, gyro, compass, Virtual proximity sensing</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:28px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Battery</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:28px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Fast charging 15W, Li-Po 5000 mAh, non-removable</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Charging</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Fast charging 15W</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:186px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Colors</span></span></p>\r\n			</td>\r\n			<td colspan=\"2\" style=\"height:29px; vertical-align:top; width:510px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Black, White, Mint, Violet</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '5500', NULL, 9, 4, NULL, NULL, NULL, NULL, 'GX0082', 50, NULL, NULL, 1, '5/80', 'general', '2021-12-10 17:16:21', '2021-12-14 17:10:29', 83, '83.beardo-pr3051-beast.jpg', NULL, NULL, NULL, NULL, NULL, '53.o]ryr.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, '60', '130'),
(84, 'ABCsss', 'abc-490-84-84-84-84-84-84-84-84', 0, 1500, NULL, '<table cellspacing=\"0\" class=\"MsoTableGrid\" style=\"border-collapse:collapse; border:none; width:733px\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"height:28px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Brand</span></span></p>\r\n			</td>\r\n			<td style=\"height:28px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:28px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">Samsung</span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Model</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">A32</span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Network</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/samsung_galaxy_a22-10948.php\" style=\"color:blue; text-decoration:underline\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">GSM / HSPA / LTE</span></span></span></a></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Display Type</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Super AMOLED, 90Hz, 800 nits (HBM)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Display Size</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">6.4 inches, 98.9 cm</span></span></span><sup><span style=\"font-size:8.5pt\"><span style=\"font-family:&quot;inherit&quot;,&quot;serif&quot;\"><span style=\"color:black\">2</span></span></span></sup><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">&nbsp;(~84.6% screen-to-body ratio)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Body Dimensions</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">158.9 x 73.6 x 8.4 mm (6.26 x 2.90 x 0.33 in)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Weight</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">184 g (6.49 oz)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Build</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Glass front (Gorilla Glass 5), plastic frame, plastic back</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Sim</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Single SIM (Nano-SIM) or Dual SIM (Nano-SIM, dual stand-by)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:28px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Operating System</span></span></p>\r\n			</td>\r\n			<td style=\"height:28px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:28px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Android 11, One UI 3.1</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Chipset</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">MediatekHelio G80 (12 nm)&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● CPU</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Octa-core (2x2.0 GHz Cortex-A75 &amp; 6x1.8 GHz Cortex-A55)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● GPU</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Mali-G52 MC2</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Ram</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">4GB</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Storage</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">64GB</span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Back Camera</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><a href=\"https://www.gsmarena.com/glossary.php3?term=camera\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">Quad</span></span></span></strong></a> - </span></span></p>\r\n\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">64 MP, f/1.8, 26mm (wide), PDAF<br />\r\n			8 MP, f/2.2, 123˚, (ultrawide), 1/4.0&quot;, 1.12&micro;m<br />\r\n			5 MP, f/2.4, (macro)<br />\r\n			5 MP, f/2.4, (depth)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Front Camera</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">20 MP, f/2.2, (wide)</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"6\" style=\"height:3px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Connectivities</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:9.0pt\"><a href=\"https://www.gsmarena.com/glossary.php3?term=wi-fi\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">WLAN</span></span></strong></a>, </span><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Wi-Fi 802.11 a/b/g/n/ac, dual-band, Wi-Fi Direct, hotspot</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:9.0pt\"><a href=\"https://www.gsmarena.com/glossary.php3?term=bluetooth\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">Bluetooth</span></span></strong></a>, </span><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">5.0, A2DP, LE</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:9.0pt\"><a href=\"https://www.gsmarena.com/glossary.php3?term=gps\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">GPS</span></span></strong></a>, </span><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Yes, with A-GPS, GLONASS, GALILEO, BDS</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:9.0pt\"><a href=\"https://www.gsmarena.com/glossary.php3?term=nfc\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">NFC</span></span></strong></a>, </span><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">No</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:9.0pt\"><a href=\"https://www.gsmarena.com/glossary.php3?term=fm-radio\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">Radio</span></span></strong></a>, </span><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Unspecified</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:3px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:3px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:9.0pt\"><a href=\"https://www.gsmarena.com/glossary.php3?term=usb\" style=\"color:blue; text-decoration:underline\"><strong><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:#555555\">USB</span></span></strong></a>, </span><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">USB Type-C 2.0</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Sensors</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Fingerprint (side-mounted), accelerometer, gyro, compass, Virtual proximity sensing</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:28px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Battery</span></span></p>\r\n			</td>\r\n			<td style=\"height:28px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:28px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Fast charging 15W, Li-Po 5000 mAh, non-removable</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Charging</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Fast charging 15W</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:29px; vertical-align:top; width:153px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">● Colors</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:18px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\">:</span></span></p>\r\n			</td>\r\n			<td style=\"height:29px; vertical-align:top; width:562px\">\r\n			<p><span style=\"font-size:11pt\"><span style=\"font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;\"><span style=\"font-size:10.5pt\"><span style=\"font-family:&quot;Arial&quot;,&quot;sans-serif&quot;\"><span style=\"color:black\">Black, White, Mint, Violet</span></span></span></span></span></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '1450', NULL, 11, 2, NULL, '<p><img class=\"img-fluid\" src=\"http://127.0.0.1:8000/uploads/product_detail/1.jpg\" /></p>\r\n\r\n<p><img class=\"img-fluid\" src=\"http://127.0.0.1:8000/uploads/product_detail/47.png\" /></p>', NULL, NULL, 'GX0083', 10, NULL, NULL, 1, NULL, 'home', '2021-12-13 17:59:28', '2021-12-16 12:21:19', 84, '84.gsmarena_004.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, '60', '130');

-- --------------------------------------------------------

--
-- Table structure for table `product_click`
--

CREATE TABLE `product_click` (
  `click_id` bigint(20) NOT NULL,
  `view_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `ip` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `click_date` date DEFAULT NULL,
  `click_date_time` datetime DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_color`
--

CREATE TABLE `product_color` (
  `product_color_id` int(11) NOT NULL,
  `product_color_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_color`
--

INSERT INTO `product_color` (`product_color_id`, `product_color_name`) VALUES
(1, 'Black'),
(2, 'Red'),
(3, 'Blue'),
(4, 'White');

-- --------------------------------------------------------

--
-- Table structure for table `product_comment`
--

CREATE TABLE `product_comment` (
  `comment_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `comment_from_customer` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_from_admin` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `staus` tinyint(4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `question_email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_detail_media`
--

CREATE TABLE `product_detail_media` (
  `id` int(11) NOT NULL,
  `picture` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_detail_media`
--

INSERT INTO `product_detail_media` (`id`, `picture`, `created_at`) VALUES
(46, 'uploads/product_detail/1.jpg', '2021-12-16'),
(47, 'uploads/product_detail/47.png', '2021-12-16');

-- --------------------------------------------------------

--
-- Table structure for table `product_hit_count`
--

CREATE TABLE `product_hit_count` (
  `id` int(11) NOT NULL,
  `user_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `unique_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `hit_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_of_order_data`
--

CREATE TABLE `product_of_order_data` (
  `id` bigint(20) NOT NULL,
  `product_code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_of_order_data`
--

INSERT INTO `product_of_order_data` (`id`, `product_code`, `order_id`, `date`) VALUES
(1, 'GX0026', 1, '2021-12-20');

-- --------------------------------------------------------

--
-- Table structure for table `product_order_history`
--

CREATE TABLE `product_order_history` (
  `product_order_history_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `order_count` tinyint(4) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_permission_report`
--

CREATE TABLE `product_permission_report` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `comission` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `affilate_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_permission_report`
--

INSERT INTO `product_permission_report` (`id`, `order_id`, `product_id`, `comission`, `date`, `affilate_id`) VALUES
(5, 152, 17, '20', '2020-12-16', 3),
(6, 152, 113, '107.5', '2020-12-16', 3),
(7, 152, 22, '80', '2020-12-16', 3),
(8, 153, 23, '500', '2020-12-16', 2235),
(9, 153, 25, '44', '2020-12-16', 2235),
(10, 152, 17, '300', '2020-12-16', 3),
(11, 152, 113, '40', '2020-12-16', 3),
(12, 152, 22, '48', '2020-12-16', 3),
(13, 537, 773, '200', '2020-12-16', 1),
(14, 537, 789, '64.5', '2020-12-16', 1),
(15, 537, 79, '72', '2020-12-16', 1),
(16, 538, 773, '200', '2020-12-16', 3),
(17, 538, 368, '150', '2020-12-16', 3),
(18, 538, 695, '132', '2020-12-16', 3),
(19, 531, 789, '700', '2020-12-17', 2113),
(20, 540, 44, '15', '2020-12-18', 2113),
(21, 539, 44, '15', '2020-12-18', 2113),
(22, 525, 426, '53.4', '2020-12-18', 2113),
(23, 535, 733, '26', '2020-12-19', 2113),
(24, 546, 60, '72', '2020-12-21', 2113),
(25, 559, 463, '9', '2020-12-21', 1),
(26, 561, 463, '9', '2020-12-22', 1),
(27, 549, 480, '200', '2020-12-23', 2113),
(28, 516, 50, '54', '2020-12-23', 2113),
(29, 516, 317, '60', '2020-12-23', 2113),
(30, 516, 334, '47.94', '2020-12-23', 2113),
(31, 516, 368, '81', '2020-12-23', 2113),
(32, 516, 459, '39', '2020-12-23', 2113),
(33, 516, 480, '143.94', '2020-12-23', 2113),
(34, 516, 481, '111', '2020-12-23', 2113),
(35, 516, 628, '33', '2020-12-23', 2113),
(36, 516, 773, '750', '2020-12-23', 2113),
(37, 596, 445, '25.5', '2020-12-27', 2610),
(38, 592, 67, '11.94', '2020-12-27', 2113),
(39, 548, 404, '30', '2020-12-30', 2113),
(40, 556, 468, '100', '2020-12-31', 2113),
(41, 560, 232, '31.5', '2020-12-31', 2113),
(42, 575, 48, '56', '2020-12-31', 2113),
(43, 562, 85, '52.5', '2020-12-31', 2113),
(44, 562, 795, '29.05', '2020-12-31', 2113),
(45, 610, 467, '19.6', '2021-01-04', 2113),
(46, 603, 67, '13.93', '2021-01-06', 2113),
(47, 622, 404, '30', '2021-01-06', 3508),
(48, 609, 467, '39.2', '2021-01-06', 2113),
(49, 637, 91, '28', '2021-01-07', 3),
(50, 636, 904, '45', '2021-01-08', 3508),
(51, 616, 734, '39.9', '2021-01-09', 2113),
(52, 498, 706, '5.79', '2021-01-09', 1),
(53, 640, 749, '250', '2021-01-11', 3508),
(54, 663, 919, '42', '2021-01-12', 1),
(55, 620, 480, '200', '2021-01-13', 2113),
(56, 656, 749, '250', '2021-01-13', 3508),
(57, 639, 33, '24', '2021-01-16', 2113),
(58, 639, 354, '14.4', '2021-01-16', 2113),
(59, 641, 60, '96', '2021-01-16', 2113),
(60, 673, 27, '25.5', '2021-01-17', 2789),
(61, 658, 455, '56.97', '2021-01-17', 3508),
(62, 448, 116, '4.5', '2021-01-18', 2106),
(63, 448, 404, '12', '2021-01-18', 2106),
(64, 448, 661, '28.8', '2021-01-18', 2106),
(65, 679, 38, '52', '2021-01-23', 2113),
(66, 686, 92, '150', '2021-01-23', 2113),
(67, 666, 535, '64', '2021-01-23', 2113),
(68, 668, 734, '45.6', '2021-01-23', 2113),
(69, 654, 876, '111.92', '2021-01-23', 2113),
(70, 670, 215, '30', '2021-01-25', 2113),
(71, 681, 202, '36', '2021-01-25', 3508),
(72, 688, 893, '23.92', '2021-01-29', 2113),
(73, 697, 928, '108', '2021-01-29', 3508),
(74, 699, 215, '30', '2021-01-29', 2113),
(75, 701, 547, '120', '2021-01-29', 3508),
(76, 702, 68, '64', '2021-01-29', 2113),
(77, 706, 354, '16.2', '2021-01-30', 3508),
(78, 711, 282, '250', '2021-01-31', 3855),
(79, 700, 98, '23.92', '2021-02-05', 2113),
(80, 700, 700, '28.8', '2021-02-05', 2113),
(81, 700, 774, '26.4', '2021-02-05', 2113),
(82, 700, 926, '28', '2021-02-05', 2113),
(83, 722, 969, '180', '2021-02-11', 2113),
(84, 736, 907, '13.6', '2021-02-12', 2113),
(85, 761, 1035, '30000', '2021-02-12', 1),
(86, 761, 1034, '6000', '2021-02-12', 1),
(87, 761, 715, '2000', '2021-02-12', 1),
(88, 761, 870, '350', '2021-02-12', 1),
(89, 755, 950, '9', '2021-02-12', 3508),
(90, 747, 547, '120', '2021-02-14', 3508),
(91, 708, 67, '24', '2021-02-17', 2113),
(92, 751, 215, '30', '2021-02-17', 4001),
(93, 745, 805, '250', '2021-02-17', 4043),
(94, 781, 976, '25', '2021-02-19', 2113),
(95, 764, 599, '30', '2021-02-19', 3508),
(96, 764, 749, '300', '2021-02-19', 3508),
(97, 764, 926, '14', '2021-02-19', 3508),
(98, 764, 1070, '32', '2021-02-19', 3508),
(99, 776, 1019, '500', '2021-02-20', 3855),
(100, 782, 1019, '500', '2021-02-20', 3508),
(101, 810, 1036, '45', '2021-02-21', 3587),
(102, 766, 282, '48', '2021-02-23', 4001),
(103, 754, 982, '15', '2021-02-23', 2113),
(104, 765, 239, '12', '2021-02-23', 2113),
(105, 768, 805, '43.5', '2021-02-23', 3900),
(106, 772, 931, '26.7', '2021-02-23', 78),
(107, 777, 211, '37.5', '2021-02-23', 4001),
(108, 778, 459, '150', '2021-02-23', 2113),
(109, 778, 56, '55.92', '2021-02-23', 2113),
(110, 778, 946, '450', '2021-02-23', 2113),
(111, 779, 450, '21', '2021-02-23', 78),
(112, 773, 175, '69.2', '2021-02-23', 3508),
(113, 794, 977, '15', '2021-02-23', 2113),
(114, 793, 805, '43.5', '2021-02-23', 3900),
(115, 831, 1035, '30000', '2021-02-23', 1),
(116, 833, 1099, '200', '2021-02-23', 3),
(117, 830, 1099, '42', '2021-02-24', 4106),
(118, 829, 1064, '16.5', '2021-02-24', 4106),
(119, 827, 1064, '16.5', '2021-02-24', 78),
(120, 760, 805, '174', '2021-02-25', 4043),
(121, 744, 805, '250', '2021-02-25', 4043),
(122, 786, 1056, '42', '2021-02-25', 3900),
(123, 785, 215, '8.4', '2021-02-25', 4001),
(124, 840, 805, '43.5', '2021-02-25', 3855),
(125, 842, 1064, '16.5', '2021-02-26', 4106),
(126, 783, 805, '43.5', '2021-02-26', 3900),
(127, 716, 227, '35.96', '2021-02-26', 3508),
(128, 850, 976, '25', '2021-02-26', 2113),
(129, 859, 1064, '200', '2021-02-28', 4106),
(130, 864, 1064, '100', '2021-03-01', 4106),
(131, 870, 1107, '39', '2021-03-01', 74),
(132, 888, 1025, '100', '2021-03-02', 57),
(133, 813, 1064, '33', '2021-03-02', 78),
(134, 820, 459, '19.5', '2021-03-02', 78),
(135, 887, 282, '250', '2021-03-03', 2113),
(136, 804, 1079, '44', '2021-03-03', 3855),
(137, 799, 1078, '120', '2021-03-03', 2113),
(138, 800, 1078, '240', '2021-03-03', 2113),
(139, 812, 535, '64', '2021-03-03', 2113),
(140, 795, 860, '14.5', '2021-03-03', 2113),
(141, 821, 749, '300', '2021-03-03', 2113),
(142, 851, 804, '150', '2021-03-03', 3508),
(143, 860, 116, '6', '2021-03-03', 3508),
(144, 822, 1064, '44', '2021-03-04', 2113),
(145, 826, 1064, '16.5', '2021-03-04', 78),
(146, 823, 460, '58.5', '2021-03-04', 78),
(147, 836, 214, '33', '2021-03-04', 78),
(148, 849, 354, '25', '2021-03-04', 3508),
(149, 855, 805, '87', '2021-03-04', 3900),
(150, 861, 56, '19.5', '2021-03-04', 74),
(151, 698, 98, '11.96', '2021-03-04', 3508),
(152, 848, 354, '25', '2021-03-04', 3508),
(153, 854, 215, '30', '2021-03-04', 4001),
(154, 891, 203, '49.5', '2021-03-04', 3855),
(155, 926, 33, '25', '2021-03-05', 3587),
(156, 867, 1078, '100', '2021-03-07', 78),
(157, 871, 1078, '200', '2021-03-07', 78),
(158, 874, 1100, '46', '2021-03-07', 78),
(159, 884, 1078, '100', '2021-03-07', 78),
(160, 886, 1078, '100', '2021-03-07', 78),
(161, 879, 56, '19.5', '2021-03-07', 74),
(162, 890, 869, '13', '2021-03-07', 2113),
(163, 889, 1078, '100', '2021-03-07', 78),
(164, 892, 56, '125', '2021-03-07', 2113),
(165, 895, 946, '150', '2021-03-07', 78),
(166, 897, 56, '125', '2021-03-07', 2113),
(167, 909, 1092, '95', '2021-03-07', 78),
(168, 910, 1054, '12', '2021-03-07', 74),
(169, 919, 931, '90', '2021-03-07', 78),
(170, 914, 573, '60', '2021-03-07', 4001),
(171, 927, 946, '150', '2021-03-07', 78),
(172, 707, 907, '8.5', '2021-03-07', 2113),
(173, 896, 749, '300', '2021-03-07', 2113),
(174, 880, 1078, '100', '2021-03-07', 78),
(175, 898, 1051, '150', '2021-03-07', 78),
(176, 862, 1078, '150', '2021-03-07', 78),
(177, 881, 56, '19.5', '2021-03-07', 74),
(178, 912, 213, '44.7', '2021-03-07', 3855),
(179, 908, 749, '300', '2021-03-07', 3508),
(180, 952, 1070, '24', '2021-03-09', 4001),
(181, 913, 977, '15', '2021-03-11', 2448),
(182, 937, 469, '100', '2021-03-11', 74),
(183, 939, 56, '125', '2021-03-11', 78),
(184, 940, 977, '15', '2021-03-11', 2113),
(185, 941, 977, '15', '2021-03-11', 2113),
(186, 948, 56, '125', '2021-03-11', 74),
(187, 901, 1025, '100', '2021-03-11', 78),
(188, 903, 1104, '120', '2021-03-11', 2113),
(189, 944, 1078, '200', '2021-03-11', 2448),
(190, 904, 54, '8.97', '2021-03-11', 74),
(191, 945, 354, '25', '2021-03-11', 74),
(192, 915, 1048, '200', '2021-03-18', 79),
(193, 882, 1078, '100', '2021-03-18', 78),
(194, 934, 1078, '100', '2021-03-18', 78),
(195, 966, 485, '100', '2021-03-19', 2448),
(196, 966, 404, '100', '2021-03-19', 2448),
(197, 961, 354, '25', '2021-03-19', 74),
(198, 1029, 1036, '750', '2021-03-19', 4907),
(199, 955, 946, '150', '2021-03-20', 78),
(200, 956, 1064, '100', '2021-03-20', 78),
(201, 959, 977, '15', '2021-03-20', 2113),
(202, 960, 1100, '200', '2021-03-20', 78),
(203, 963, 215, '30', '2021-03-20', 4280),
(204, 964, 354, '25', '2021-03-20', 74),
(205, 972, 1100, '200', '2021-03-20', 78),
(206, 982, 970, '45', '2021-03-20', 78),
(207, 984, 1113, '200', '2021-03-20', 3508),
(208, 993, 1109, '200', '2021-03-20', 4106),
(209, 995, 1113, '225', '2021-03-20', 74),
(210, 998, 214, '200', '2021-03-20', 3508),
(211, 1000, 997, '250', '2021-03-20', 2448),
(212, 970, 218, '21', '2021-03-20', 4043),
(213, 967, 805, '300', '2021-03-20', 74),
(214, 1013, 1078, '200', '2021-03-20', 78),
(215, 977, 805, '300', '2021-03-20', 4571),
(216, 974, 354, '25', '2021-03-20', 74),
(217, 991, 22, '64', '2021-03-20', 74),
(218, 990, 22, '48', '2021-03-20', 3855),
(219, 1028, 1051, '150', '2021-03-20', 78),
(220, 1022, 1064, '16.5', '2021-03-20', 2283),
(221, 981, 52, '30', '2021-03-20', 78),
(222, 938, 213, '200', '2021-03-20', 3855),
(223, 1030, 531, '30', '2021-03-20', 78),
(224, 1056, 694, '300', '2021-03-22', 3),
(225, 1057, 282, '250', '2021-03-22', 3),
(226, 1058, 444, '300', '2021-03-22', 3),
(227, 1059, 1036, '750', '2021-03-22', 4930),
(228, 1042, 1121, '76', '2021-03-22', 2113),
(229, 1009, 1076, '300', '2021-03-24', 2113),
(230, 1014, 1098, '200', '2021-03-24', 78),
(231, 1017, 982, '15', '2021-03-24', 2113),
(232, 1033, 1064, '100', '2021-03-24', 78),
(233, 1034, 1033, '56', '2021-03-24', 78),
(234, 1035, 977, '15', '2021-03-24', 2113),
(235, 1041, 1064, '100', '2021-03-24', 78),
(236, 1038, 892, '9.5', '2021-03-24', 2113),
(237, 1044, 1065, '250', '2021-03-24', 3508),
(238, 1037, 566, '50', '2021-03-24', 78),
(239, 1053, 1064, '100', '2021-03-24', 78),
(240, 999, 1100, '200', '2021-03-24', 3508),
(241, 997, 213, '200', '2021-03-24', 4106),
(242, 1075, 1064, '100', '2021-03-24', 3900),
(243, 1064, 1054, '100', '2021-03-24', 4106),
(244, 1063, 50, '100', '2021-03-24', 4106),
(245, 1019, 1061, '200', '2021-03-25', 4650),
(246, 1084, 224, '210', '2021-03-31', 3929),
(247, 1055, 559, '50', '2021-04-01', 78),
(248, 1055, 561, '50', '2021-04-01', 78),
(249, 1065, 559, '50', '2021-04-01', 78),
(250, 1021, 213, '200', '2021-04-01', 4060),
(251, 1089, 1059, '200', '2021-04-01', 2448),
(252, 1090, 1125, '150', '2021-04-01', 4310),
(253, 1090, 749, '300', '2021-04-01', 4310),
(254, 1026, 617, '130', '2021-04-01', 78),
(255, 1079, 1078, '400', '2021-04-01', 2448),
(256, 1129, 213, '100', '2021-04-02', 4809),
(257, 1083, 1051, '150', '2021-04-04', 78),
(258, 1095, 1051, '150', '2021-04-04', 78),
(259, 1076, 200, '150', '2021-04-04', 2113),
(260, 1101, 1061, '200', '2021-04-04', 4566),
(261, 1062, 1061, '200', '2021-04-04', 4897),
(262, 1049, 1048, '250', '2021-04-06', 4929),
(263, 1164, 1036, '750', '2021-04-07', 4907),
(264, 1092, 734, '28.5', '2021-04-07', 2113),
(265, 1096, 1078, '100', '2021-04-07', 78),
(266, 1099, 1139, '150', '2021-04-07', 2113),
(267, 1100, 1139, '150', '2021-04-07', 2113),
(268, 1106, 67, '70', '2021-04-07', 2113),
(269, 1107, 52, '100', '2021-04-07', 74),
(270, 1109, 1121, '70', '2021-04-07', 2113),
(271, 1117, 1103, '120', '2021-04-07', 4566),
(272, 1119, 1061, '200', '2021-04-07', 4566),
(273, 1120, 429, '400', '2021-04-07', 4001),
(274, 1122, 451, '130', '2021-04-07', 78),
(275, 1123, 1061, '200', '2021-04-07', 4566),
(276, 1124, 1033, '80', '2021-04-07', 78),
(277, 1128, 1064, '100', '2021-04-07', 78),
(278, 1130, 215, '30', '2021-04-07', 4001),
(279, 1139, 469, '100', '2021-04-07', 74),
(280, 1138, 1064, '100', '2021-04-07', 78),
(281, 1143, 213, '100', '2021-04-07', 4809),
(282, 1140, 474, '200', '2021-04-07', 4988),
(283, 1148, 1061, '200', '2021-04-07', 4968),
(284, 1152, 56, '100', '2021-04-07', 3900),
(285, 1244, 455, '350', '2021-04-11', 4988),
(286, 1146, 973, '150', '2021-04-14', 2283),
(287, 1174, 202, '300', '2021-04-14', 4935),
(288, 996, 983, '18', '2021-04-15', 2113),
(289, 1086, 1109, '200', '2021-04-15', 2448),
(290, 1159, 1024, '150', '2021-04-15', 4988),
(291, 1165, 282, '250', '2021-04-15', 2280),
(292, 1173, 617, '260', '2021-04-15', 4106),
(293, 1162, 1140, '300', '2021-04-15', 4106),
(294, 1160, 1121, '80', '2021-04-15', 2113),
(295, 1179, 1121, '80', '2021-04-15', 2113),
(296, 1185, 222, '150', '2021-04-15', 74),
(297, 1185, 1092, '95', '2021-04-15', 74),
(298, 1185, 1148, '40', '2021-04-15', 74),
(299, 1197, 467, '30', '2021-04-15', 4805),
(300, 1202, 485, '50', '2021-04-15', 74),
(301, 1213, 977, '50', '2021-04-15', 4566),
(302, 1191, 604, '30', '2021-04-15', 74),
(303, 1210, 977, '60', '2021-04-15', 4566),
(304, 1248, 977, '30', '2021-04-15', 4566),
(305, 1051, 1109, '200', '2021-04-15', 4809),
(306, 1167, 1124, '120', '2021-04-15', 4106),
(307, 1175, 749, '600', '2021-04-15', 4106),
(308, 1261, 205, '110', '2021-04-15', 4106),
(309, 906, 52, '80', '2021-04-16', 78),
(310, 1015, 617, '100', '2021-04-16', 78),
(311, 1114, 1054, '100', '2021-04-16', 4566),
(312, 1131, 214, '125', '2021-04-16', 3900),
(313, 1156, 1108, '125', '2021-04-16', 3900),
(314, 1180, 468, '100', '2021-04-16', 4106),
(315, 1262, 1152, '200', '2021-04-16', 4106),
(316, 1304, 249, '100', '2021-04-16', 78),
(317, 1171, 555, '50', '2021-04-17', 74),
(318, 1104, 1109, '200', '2021-04-17', 4566),
(319, 1243, 474, '200', '2021-04-17', 4988),
(320, 1158, 1061, '200', '2021-04-17', 4566),
(321, 1303, 808, '148', '2021-04-19', 78),
(322, 1193, 805, '300', '2021-04-19', 4571),
(323, 1177, 1078, '100', '2021-04-19', 78),
(324, 1275, 1123, '250', '2021-04-19', 4566),
(325, 1263, 1124, '120', '2021-04-19', 2448),
(326, 1337, 1149, '250', '2021-04-20', 4566),
(327, 1357, 1121, '80', '2021-04-21', 2113),
(328, 1218, 977, '15', '2021-04-22', 4566),
(329, 1216, 453, '55', '2021-04-22', 4988),
(330, 1247, 36, '200', '2021-04-22', 74),
(331, 1260, 977, '15', '2021-04-22', 4566),
(332, 1267, 1124, '120', '2021-04-22', 4988),
(333, 1268, 213, '200', '2021-04-22', 5036),
(334, 1284, 214, '200', '2021-04-23', 78),
(335, 1188, 977, '15', '2021-04-23', 2448),
(336, 1280, 205, '110', '2021-04-23', 4566),
(337, 1281, 215, '30', '2021-04-23', 4566),
(338, 1278, 1065, '250', '2021-04-23', 4106),
(339, 1294, 1116, '120', '2021-04-23', 74),
(340, 1301, 1153, '150', '2021-04-23', 5083),
(341, 1307, 749, '300', '2021-04-23', 5133),
(342, 1308, 1100, '200', '2021-04-23', 78),
(343, 1309, 1109, '200', '2021-04-23', 5036),
(344, 1314, 205, '110', '2021-04-23', 4106),
(345, 1305, 75, '80', '2021-04-23', 74),
(346, 1383, 213, '400', '2021-04-23', 2448),
(347, 1081, 213, '200', '2021-04-23', 61),
(348, 1372, 1121, '80', '2021-04-23', 2113),
(349, 1408, 1141, '60', '2021-04-23', 3),
(350, 1270, 1141, '60', '2021-04-23', 4566),
(351, 1279, 1141, '60', '2021-04-23', 78),
(352, 1364, 928, '200', '2021-04-23', 4809),
(353, 1110, 1109, '200', '2021-04-23', 4566),
(354, 1121, 1061, '200', '2021-04-23', 4968),
(355, 1132, 1061, '200', '2021-04-23', 4566),
(356, 1142, 1108, '150', '2021-04-23', 3900),
(357, 1172, 1051, '150', '2021-04-23', 4566),
(358, 1401, 213, '200', '2021-04-23', 2448),
(359, 1377, 977, '15', '2021-04-23', 4566),
(360, 1396, 1121, '80', '2021-04-23', 2113),
(361, 1208, 1113, '125', '2021-04-24', 4935),
(362, 1376, 749, '900', '2021-04-25', 2448),
(363, 1373, 213, '200', '2021-04-25', 2448),
(364, 1347, 325, '120', '2021-04-25', 5259),
(365, 1363, 354, '75', '2021-04-25', 5259),
(366, 1320, 1061, '200', '2021-04-25', 4566),
(367, 1414, 1080, '150', '2021-04-25', 2283),
(368, 1469, 213, '200', '2021-04-26', 18),
(369, 1473, 1036, '750', '2021-04-26', 4146),
(370, 1490, 213, '200', '2021-04-27', 78),
(371, 1464, 213, '170', '2021-04-27', 4971),
(372, 1462, 213, '400', '2021-04-27', 5150),
(373, 1456, 215, '60', '2021-04-27', 4001),
(374, 1315, 749, '300', '2021-04-29', 3508),
(375, 1311, 1064, '100', '2021-04-29', 78),
(376, 1313, 462, '37.5', '2021-04-29', 4988),
(377, 1325, 977, '15', '2021-04-29', 4566),
(378, 1338, 1061, '200', '2021-04-29', 5036),
(379, 1339, 1124, '120', '2021-04-29', 4106),
(380, 1340, 1064, '100', '2021-04-29', 78),
(381, 1341, 282, '250', '2021-04-29', 2448),
(382, 1343, 1153, '150', '2021-04-29', 5036),
(383, 1346, 1124, '120', '2021-04-29', 4106),
(384, 1349, 1161, '200', '2021-04-29', 4106),
(385, 1359, 617, '130', '2021-04-29', 4106),
(386, 1350, 354, '25', '2021-04-29', 5259),
(387, 1365, 749, '300', '2021-04-29', 5133),
(388, 1355, 213, '200', '2021-04-29', 2448),
(389, 1287, 1100, '200', '2021-04-29', 78),
(390, 1327, 543, '9.2', '2021-04-29', 2448),
(391, 1393, 1121, '80', '2021-04-29', 2113),
(392, 1394, 213, '200', '2021-04-29', 5036),
(393, 1399, 213, '200', '2021-04-29', 78),
(394, 1374, 1153, '150', '2021-04-29', 4566),
(395, 1397, 599, '150', '2021-04-29', 5133),
(396, 1406, 804, '150', '2021-04-29', 4809),
(397, 1407, 977, '15', '2021-04-29', 4566),
(398, 1418, 1064, '200', '2021-04-29', 78),
(399, 1425, 1153, '150', '2021-04-29', 5133),
(400, 1428, 1070, '130', '2021-04-29', 4971),
(401, 1433, 1064, '100', '2021-04-29', 78),
(402, 1436, 282, '250', '2021-04-29', 4809),
(403, 1440, 565, '50', '2021-04-29', 5433),
(404, 1443, 977, '15', '2021-04-29', 4971),
(405, 1444, 1153, '150', '2021-04-29', 5440),
(406, 1194, 700, '200', '2021-04-29', 2113),
(407, 1370, 213, '200', '2021-04-29', 2448),
(408, 1375, 354, '25', '2021-04-29', 4566),
(409, 1319, 213, '200', '2021-04-29', 4809),
(410, 1318, 213, '200', '2021-04-29', 5036),
(411, 1334, 469, '100', '2021-04-29', 4566),
(412, 1405, 805, '300', '2021-04-30', 5336),
(413, 1548, 1149, '500', '2021-05-02', 2448),
(414, 1548, 22, '66', '2021-05-02', 2448),
(415, 1548, 213, '200', '2021-05-02', 2448),
(416, 1548, 898, '250', '2021-05-02', 2448),
(417, 1548, 1119, '200', '2021-05-02', 2448),
(418, 1548, 85, '30', '2021-05-02', 2448),
(419, 1534, 1033, '44.8', '2021-05-02', 78),
(420, 1411, 555, '50', '2021-05-04', 74),
(421, 1497, 749, '135', '2021-05-04', 3508),
(422, 1495, 354, '25', '2021-05-04', 5433),
(423, 1487, 213, '200', '2021-05-04', 2448),
(424, 1483, 1064, '100', '2021-05-04', 78),
(425, 1482, 213, '200', '2021-05-04', 2448),
(426, 1463, 900, '150', '2021-05-04', 2448),
(427, 1455, 977, '75', '2021-05-04', 4971),
(428, 1512, 1152, '200', '2021-05-04', 4809),
(429, 1503, 213, '200', '2021-05-04', 2448),
(430, 1502, 213, '200', '2021-05-04', 2448),
(431, 1499, 1166, '800', '2021-05-04', 4809),
(432, 1513, 213, '200', '2021-05-04', 78),
(433, 1493, 213, '200', '2021-05-04', 5458),
(434, 1523, 1152, '200', '2021-05-04', 4809),
(435, 1536, 1064, '300', '2021-05-04', 4988),
(436, 1538, 1140, '150', '2021-05-04', 4106),
(437, 1530, 977, '75', '2021-05-04', 4971),
(438, 1535, 1025, '200', '2021-05-04', 4106),
(439, 1542, 1025, '100', '2021-05-04', 78),
(440, 1574, 213, '200', '2021-05-04', 5415),
(441, 1569, 213, '200', '2021-05-04', 5468),
(442, 1564, 1169, '12', '2021-05-04', 2113),
(443, 1468, 1153, '150', '2021-05-04', 5250),
(444, 1354, 555, '50', '2021-05-04', 5029),
(445, 1324, 900, '150', '2021-05-04', 4566),
(446, 1484, 35, '8.7', '2021-05-04', 4650),
(447, 1484, 213, '37.5', '2021-05-04', 4650),
(448, 1486, 213, '200', '2021-05-04', 4809),
(449, 1409, 213, '200', '2021-05-04', 5117),
(450, 1431, 1103, '120', '2021-05-04', 5117),
(451, 1453, 1103, '240', '2021-05-04', 5117),
(452, 1554, 203, '52.5', '2021-05-05', 5468),
(453, 1560, 213, '200', '2021-05-06', 5455),
(454, 1582, 411, '40', '2021-05-06', 4106),
(455, 1606, 583, '100', '2021-05-07', 4106),
(456, 1605, 583, '100', '2021-05-07', 4106),
(457, 1559, 434, '150', '2021-05-07', 4106),
(458, 1545, 434, '150', '2021-05-07', 4106),
(459, 1544, 598, '50', '2021-05-07', 4106),
(460, 1543, 583, '100', '2021-05-07', 4106),
(461, 1649, 573, '60', '2021-05-08', 18),
(462, 1650, 1054, '70', '2021-05-08', 18),
(463, 1651, 43, '17.97', '2021-05-08', 18),
(464, 1652, 30, '4.5', '2021-05-08', 18),
(465, 1417, 58, '22.5', '2021-05-08', 4971),
(466, 1417, 75, '80', '2021-05-08', 4971),
(467, 1421, 1153, '150', '2021-05-08', 5250),
(468, 1432, 1061, '200', '2021-05-08', 4106),
(469, 1460, 213, '37.5', '2021-05-08', 4650),
(470, 1439, 354, '25', '2021-05-08', 5433),
(471, 1448, 213, '200', '2021-05-08', 5415),
(472, 1501, 1109, '200', '2021-05-08', 4988),
(473, 1506, 213, '200', '2021-05-08', 5415),
(474, 1507, 1124, '120', '2021-05-08', 2448),
(475, 1526, 327, '36', '2021-05-08', 2283),
(476, 1575, 1149, '250', '2021-05-08', 5018),
(477, 1642, 1153, '45', '2021-05-09', 4106),
(478, 1666, 1124, '120', '2021-05-09', 4106),
(479, 1670, 591, '41.4', '2021-05-09', 4106),
(480, 1540, 213, '50', '2021-05-09', 4809),
(481, 1569, 213, '200', '2021-05-09', 5468),
(482, 1563, 1025, '100', '2021-05-09', 4106),
(483, 1576, 86, '25.5', '2021-05-09', 5468),
(484, 1458, 1109, '200', '2021-05-09', 4988),
(485, 1466, 565, '50', '2021-05-09', 5433),
(486, 1471, 213, '50', '2021-05-09', 4988),
(487, 1475, 213, '37.5', '2021-05-09', 5339),
(488, 1476, 749, '300', '2021-05-09', 3508),
(489, 1472, 1153, '150', '2021-05-09', 5440),
(490, 1477, 749, '300', '2021-05-09', 2429),
(491, 1479, 1108, '200', '2021-05-09', 5473),
(492, 1552, 977, '4.5', '2021-05-09', 5133),
(493, 1583, 1108, '300', '2021-05-09', 4935),
(494, 1591, 977, '4.5', '2021-05-09', 5133),
(495, 1595, 1149, '500', '2021-05-09', 4809),
(496, 1547, 977, '40', '2021-05-09', 5133),
(497, 1604, 202, '150', '2021-05-09', 4935),
(498, 1608, 213, '200', '2021-05-09', 2448),
(499, 1619, 205, '110', '2021-05-09', 78),
(500, 1621, 461, '250', '2021-05-09', 5133),
(501, 1529, 977, '40', '2021-05-09', 4971),
(502, 1557, 556, '0', '2021-05-09', 74),
(503, 1392, 213, '400', '2021-05-09', 2448),
(504, 1609, 1149, '250', '2021-05-09', 4106),
(505, 1672, 401, '40', '2021-05-09', 18),
(506, 1531, 213, '200', '2021-05-10', 4988),
(507, 1661, 898, '200', '2021-05-10', 4106),
(508, 1496, 213, '200', '2021-05-10', 2448),
(509, 1573, 213, '200', '2021-05-10', 5415),
(510, 1622, 317, '170', '2021-05-10', 5415),
(511, 1525, 213, '200', '2021-05-10', 78),
(512, 1561, 547, '120', '2021-05-10', 5495),
(513, 1673, 578, NULL, '2021-05-10', 4106),
(514, 1612, 1112, '150', '2021-05-12', 4571),
(515, 1691, 1124, '120', '2021-05-12', 4106),
(516, 1692, 404, '50', '2021-05-12', 4106),
(517, 1747, 203, '250', '2021-05-22', 5834),
(518, 1794, 558, '50', '2021-05-25', 1),
(519, 1787, 213, '200', '2021-05-25', 5797),
(520, 1795, 1033, '16.8', '2021-06-02', 1),
(521, 1548, 22, NULL, '2021-06-06', 2448),
(522, 1548, 85, NULL, '2021-06-06', 2448),
(523, 1548, 213, '800', '2021-06-06', 2448),
(524, 1548, 898, '1250', '2021-06-06', 2448),
(525, 1548, 1119, '800', '2021-06-06', 2448),
(526, 1548, 1149, '500', '2021-06-06', 2448),
(527, 1824, 1199, '0', '2021-08-12', 1),
(528, 1739, 580, '0', '2021-08-14', 4106),
(529, 1836, 1042, '0', '2021-09-17', 2),
(530, 1738, 1124, '120', '2021-09-17', 4106),
(531, 1712, 1149, '250', '2021-09-24', 4106),
(532, 1707, 1051, '150', '2021-09-28', 5543),
(533, 1684, 977, '40', '2021-09-28', 5468),
(534, 1809, 1195, '500', '2021-10-11', 5284),
(535, 1781, 14, '100', '2021-10-11', 5543),
(536, 1781, 38, '0', '2021-10-11', 5543),
(537, 1781, 48, '0', '2021-10-11', 5543),
(538, 1781, 50, '100', '2021-10-11', 5543);

-- --------------------------------------------------------

--
-- Table structure for table `product_size`
--

CREATE TABLE `product_size` (
  `product_size_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_size`
--

INSERT INTO `product_size` (`product_size_id`, `name`) VALUES
(1, '38'),
(2, '39'),
(3, '40'),
(4, '45');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `rating` varchar(5) COLLATE utf8_unicode_ci DEFAULT '1',
  `review_active` int(11) NOT NULL DEFAULT 0,
  `created_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `product_id`, `name`, `email`, `comment`, `rating`, `review_active`, `created_time`) VALUES
(1, 84, 'sujon', 'suzonice15@gmail.com', 'good', '5', 0, NULL),
(2, 84, 'mitul', 'fjjfjf@fmao.com', 'ok		', '3', 1, '2019-09-20 05:40:29'),
(3, 169, 'suzon', 'suzonice15@gmail.com', 'ttt', '5', 1, '2019-09-19 14:14:06'),
(4, 169, 'suzon', 'suzonice15@gmail.com', 'hh				', '5', 1, '2019-09-20 05:40:22'),
(5, 169, 'suzon', 'suzonice15@gmail.com', 'ok', '3', 1, '2019-09-19 14:17:05'),
(8, 180, 'sumon', 'suzonice15@gmail.com', 'ddd', '5', 0, '2019-09-20 09:42:36'),
(9, 167, 'mitul', 'suzonice1@gmal.com', 'hhh', '5', 0, '2019-09-20 16:28:07'),
(10, 169, 'raihan', 'mitul@gmail.com', 'ddd', '5', 1, '2019-09-20 16:30:26'),
(11, 169, 'abu', 'abu@gmail.com', 'ok\n', '5', 1, '2019-09-20 16:34:44'),
(12, 178, 'suzon', 'suzonice15@gmail.com', 'ok', '5', 1, '2019-09-22 09:57:49'),
(13, 178, 'mitul', 'suzonice15@gmail.com', 'nice		2e', '5', 1, '2019-10-10 02:13:18'),
(14, 167, 'Full HD 1080P স্পোর্টস অ্যাকশন ওয়াটারপ্রুফ ক্যামেরা 12MP - Black', 'anisurrups@gmail.com', 'kk		', '5', 1, '2019-11-18 05:24:57'),
(15, 186, 'Asia', 'anisur134@gmail.com', 'ok', '5', 1, '2019-10-17 13:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `smtp`
--

CREATE TABLE `smtp` (
  `id` int(11) NOT NULL,
  `driver` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encryption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `smtp`
--

INSERT INTO `smtp` (`id`, `driver`, `host`, `port`, `username`, `password`, `encryption`) VALUES
(1, 'smtp', 'server.jibonpata.com', '465', 'support@sohojaffiliates.com', '!D1Nm*=hT,Me', 'ssl');

-- --------------------------------------------------------

--
-- Table structure for table `specifications`
--

CREATE TABLE `specifications` (
  `id` bigint(20) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `specifications`
--

INSERT INTO `specifications` (`id`, `product_id`, `value`) VALUES
(20, 7, '164.8 x 77.2 x 8.1 mm (6.49 x 3.04 x 0.32 in)'),
(21, 7, '208 g (7.34 oz)'),
(22, 7, '1440 x 3088 pixels (~496 ppi density)'),
(23, 7, 'Android 10, upgradable to Android 11, One UI 3.0'),
(24, 7, 'Exynos 990 (7 nm+) - Global Qualcomm SM8250 Snapdragon 865 5G+ (7 nm+) - USA'),
(25, 7, '164.8 x 77.2 x 8.1 mm (6.49 x 3.04 x 0.32 in)'),
(26, 7, 'Octa-core (2x2.73 GHz Mongoose M5 & 2x2.50 GHz Cortex-A76 & 4x2.0 GHz Cortex-A55) - Global,   Octa-core (1x3.0 GHz Kryo 585 & 3x2.42 GHz Kryo 585 & 4x1.8 GHz Kryo 585) - USA'),
(27, 7, 'Single SIM (Nano-SIM and/or eSIM) or Hybrid Dual SIM (Nano-SIM, dual stand-by)'),
(28, 7, 'Li-Ion 4500 mAh, non-removable'),
(29, 7, 'Fast charging 25W, USB Power Delivery 3.0, Fast Qi/PMA wireless charging 15W, Reverse wireless charging 4.5W'),
(30, 7, 'INTERNAL - 128GB 12GB RAM, 256GB 8GB RAM, 256GB 12GB RAM, 512GB 12GB RAM UFS 3.0, EXTERNAL - microSDXC (uses shared SIM slot)'),
(31, 7, 'GSM / CDMA / HSPA / EVDO / LTE / 5G'),
(32, 7, '12 MP, f/2.2, 120˚, 13mm (ultrawide), 1/2.55\", 1.4µm, FEATURE - LED flash, auto-HDR, panorama, VIDEO - 8K@24fps, 4K@30/60fps, 1080p@30/60/240fps, 720p@960fps, HDR10+, stereo sound rec., gyro-EIS & OIS'),
(33, 7, '18 Months EMI Available'),
(34, 7, '12 Months Official Warranty'),
(1140, 34, 'dstdstdst'),
(1141, 34, 'sarfsarsar'),
(1142, 34, 'sarsarsa'),
(1143, 34, 'asrasrasr'),
(1144, 34, 'atastsat'),
(1145, 34, 'satasta'),
(1146, 34, 'astata'),
(1147, 34, 'reueruereu'),
(1148, 34, 'ruerureureu'),
(1149, 34, 'ruerurueru'),
(1150, 34, 'uerureu'),
(1324, 17, 'uruwreuyewy'),
(1325, 17, 'trqwtqtqt'),
(1326, 17, 'ewtqyyuj'),
(1327, 17, 'etet'),
(1328, 17, 'ewytweyt'),
(1329, 17, 'weytewy'),
(1330, 17, 'ewywuuewu'),
(1331, 17, 'eytweywu'),
(1332, 17, 'ewtewuu'),
(1333, 17, 'etewt'),
(1334, 17, 'reureueru'),
(1335, 17, 'eteqwqwy'),
(1336, 17, 'ewtwet'),
(1337, 17, 'wetwetwe'),
(1338, 17, 'ujjttujujtu'),
(1496, 65, 'wtrqwtrqw'),
(1497, 65, 'wqtqwtqw'),
(1498, 65, 'wqtqwtqwtqw'),
(1499, 65, 'qwtqwtqwtq'),
(1500, 66, 'wrqwretqwtqw'),
(1501, 66, 'qrqwtqwtqwt'),
(1502, 66, 'tq3wt32t'),
(1503, 66, 'aetwtqwtqw'),
(1504, 67, 'etgetrqwrqw'),
(1505, 67, 'ewtet3qwtqwt'),
(1506, 67, 'dtgewtet'),
(1507, 67, 'etyewtewtewt'),
(1508, 68, 'dsgsdgdsg'),
(1509, 68, 'qwrqwrqwrqwrqw'),
(1510, 68, 'qwrqwdwstgsd'),
(1511, 68, 'etrerqwerqw'),
(1512, 68, 'yfhfdhdf'),
(1513, 68, 'qwryreyryrey'),
(1514, 69, 'eteqwtqwtqw'),
(1515, 69, 'qwwetwet'),
(1516, 69, 'ryetwetewtewt'),
(1517, 69, 'fjhreyreytrw'),
(1518, 69, 'hgrerewtewt'),
(1519, 69, 'ywteqtqwetqw'),
(1520, 69, 'dgdsgdsgsd'),
(1521, 69, 'tewt332edf'),
(1531, 70, 'qwrrwqrqwr'),
(1532, 70, 'qewrrrqwrqwrqwr'),
(1533, 70, 'qrrwqqwwqr'),
(1534, 70, 'qwrqwywetwtwetwe'),
(1535, 70, 'qytwe4ytewyt'),
(1536, 70, 'qwrqwrqwt32'),
(1537, 70, 'wrwrqwr2'),
(1538, 70, 'yrweyewywe'),
(1539, 70, 'uy5ryrewerqwr'),
(1570, 10, 'ryhrhrwhrwh'),
(1571, 10, 'wetewtwet'),
(1572, 10, 'wreywywet'),
(1573, 10, 'ewtwetwet'),
(1574, 10, 'ewytweyewy'),
(1575, 10, 'ewytewyewy'),
(1576, 10, 'ewyewyewy'),
(1577, 10, 'ewytewywey'),
(1578, 10, 'weyweyewy'),
(1579, 10, 'ewyewyewy'),
(1580, 10, 'ewtewt'),
(1581, 10, 'ewtewtwey'),
(1582, 10, 'ewtewtewt'),
(1583, 10, 'ewtwet'),
(1584, 10, 'ewtweywreywrey'),
(1645, 8, 'GSM / CDMA / HSPA / EVDO / LTE / 5G'),
(1646, 8, 'Foldable Dynamic AMOLED 2X, 120Hz, HDR10+, 1200 nits (peak)'),
(1647, 8, '6.7 inches, 101.5 cm2 (~84.7% screen-to-body ratio)'),
(1648, 8, 'Unfolded: 166 x 72.2 x 6.9 mm, Folded: 86.4 x 72.2 x 15.9-17.1 mm'),
(1649, 8, '183 g (6.46 oz)'),
(1650, 8, 'Front : Plastic, Back : Glass (Gorilla Glass Victus), Aluminum frame'),
(1651, 8, 'Nano-SIM, eSIM, IPX8 water resistant (up to 1.5m for 30 mins)'),
(1652, 8, 'Android 11, One UI 3.1.1'),
(1653, 8, 'Qualcomm SM8350 Snapdragon 888 5G (5 nm)'),
(1654, 8, 'Octa-core (1x2.84 GHz Kryo 680 & 3x2.42 GHz Kryo 680 & 4x1.80 GHz Kryo 680)'),
(1655, 8, 'Adreno 660'),
(1656, 8, '8GB'),
(1657, 8, '256GB, External Card Slot (No)'),
(1658, 8, 'Dual (12 MP, f/1.8, 27mm (wide), 1/2.55\", 1.4µm, Dual Pixel PDAF, OIS 12 MP, f/2.2, 123˚ (ultrawide), 1.12µm) |  LED flash, HDR, panorama  |  4K@30/60fps, 1080p@60/240fps, 720p@960fps, HDR10+'),
(1659, 8, 'Single (10 MP, f/2.4, 26mm (wide), 1.22µm)'),
(1682, 14, 'ewtewt'),
(1683, 14, 'ewtewt'),
(1684, 14, 'etwetew'),
(1685, 14, 'etrewt'),
(1686, 14, 'twetwetewtewt'),
(1687, 14, 'tetetwt'),
(1688, 14, 'etetet'),
(1689, 14, 'etewtewt'),
(1690, 14, 'ewyewy'),
(1691, 14, 'eytewyew'),
(1692, 14, 'yewey'),
(1693, 14, 'eyewy'),
(1694, 14, 'hgdwghwetg'),
(1695, 14, 'eytewyew'),
(1696, 14, 'ewyweyewy'),
(1697, 15, 'wqrqwr'),
(1698, 15, 'tetyhwyrwey'),
(1699, 15, 'reqw'),
(1700, 15, 'wtrw'),
(1701, 15, 'wqtqwt'),
(1702, 15, 'eytewyewyewy'),
(1703, 15, 'wrqwrqwr'),
(1704, 15, 'qwrqwr'),
(1705, 15, 'qwrqwr'),
(1706, 15, 'wrqwr'),
(1707, 15, 'wrqwr'),
(1708, 15, 'eytytewywey'),
(1709, 15, 'ete'),
(1710, 15, 'qetewtewt'),
(1711, 15, 'etet'),
(1755, 82, 'ewtwetwetewt'),
(1756, 81, 'qwtqwtqwtqwtqwtqwt'),
(1757, 80, 'rqwrqwrqwrqwrqwrqwr'),
(1758, 79, 'etqwtqwtqwtqwtqwtqwt'),
(1759, 78, 'qw5tqwtqwtqwt'),
(1760, 77, 'teeteqwtqwetqtq'),
(1761, 76, '5tatgqatsafsasafa'),
(1762, 75, 'qtrqwtrqwtqw'),
(1763, 74, 'qwrqwrqwrqwr'),
(1764, 73, 'sfasfasfaf'),
(1765, 72, 'sarfafafafafa'),
(1766, 72, 'safasfasfaf'),
(1767, 72, 'wqrqwrqwr'),
(1768, 72, 'wrqwrqwr'),
(1769, 72, 'wrqwrqwrqwr'),
(1770, 72, 'fgsdgsdgdsdsg'),
(1771, 72, 'trq3trqwrqw'),
(1772, 71, 'fasfsaf'),
(1773, 71, 'dfsdfdsfdsf'),
(1774, 71, 'drfdfdsf'),
(1775, 71, 'dfdsfdffdfdf'),
(1776, 71, 'dsfdfdsfsd'),
(1777, 71, 'dfdsfdsfdfds'),
(1778, 71, 'hhdfhwetrewrewr'),
(1786, 62, 'dgsdgwetgewt'),
(1787, 62, 'sfasfsa'),
(1788, 62, 'sarfsarqwreqw'),
(1789, 62, 'teeqwtqwtqw'),
(1790, 62, 'sfasgga'),
(1791, 62, 'fhfeterqwr'),
(1792, 62, 'hhshfde'),
(1793, 62, 'fdhrfhrtwetew'),
(1794, 62, 'fhreyreyrey'),
(1795, 62, 'fjuyewrywey'),
(1796, 61, 'qwtqwtqw'),
(1797, 61, 'qwtqwtqwtqwtqw'),
(1798, 61, 'qwtqsdgdsgf'),
(1799, 61, 'qwrqwrqwrqw'),
(1800, 61, 'dsherwhewwe'),
(1801, 61, 'qwrqwrqwrqw'),
(1802, 61, 'qwrqwrqwrrqwr'),
(1803, 61, 'qwdsgsdgds'),
(1804, 61, 'qwtr212'),
(1805, 60, 'wqtqwtqw'),
(1806, 60, 'tdsgdsgds'),
(1807, 60, 'qwtqwtq'),
(1808, 60, 'qawtqwtqw'),
(1809, 60, 'qwtqwtqwtq'),
(1810, 59, 'qwrqwrqwr'),
(1811, 59, 'destrewt'),
(1812, 59, 'dsgadsagsa'),
(1813, 58, 'wqtqwtqwtq'),
(1814, 58, 'wqtrqwt'),
(1815, 58, 'wqtqwtqwtqwt'),
(1816, 58, 'qwtegdgdsa'),
(1817, 58, 'egdsgsdgsdgdsg'),
(1818, 58, 'qdgdsfsadas'),
(1819, 57, 'qwtqwtqwt'),
(1820, 57, 'wqtqwtqwtqwtqw'),
(1821, 57, 'wtrqwrqw'),
(1822, 57, 'wqrqwrqwrqw'),
(1823, 57, 'qwrqwrqwr'),
(1824, 57, 'rqwtqeqwtqw'),
(1825, 57, 'yewytwet'),
(1826, 57, 'sarwwqtrqwrqwr'),
(1827, 57, 'qewytqwtqwtq'),
(1828, 57, 'hsdhsdhsd'),
(1829, 57, 'wqrqwrqwrqw'),
(1830, 55, 'wtqwtqwttd'),
(1831, 55, 'qtqwtwqtqwtwqt'),
(1832, 55, 'ttqwrgdsg'),
(1833, 55, 'etegfeaqwrwqtr'),
(1834, 54, 'qwtrqwtqwtqwt2'),
(1835, 54, 'dstdsgdsg'),
(1836, 54, 'yhweyewtewte'),
(1837, 54, 'wywetew'),
(1838, 54, 'y43325325'),
(1839, 54, 'wtrqwtqt'),
(1840, 54, 't3535'),
(1841, 54, '35325325'),
(1842, 53, 'w4rqrwtredtewt'),
(1843, 53, 'qretetwet'),
(1844, 53, 'qwetewtwetw'),
(1845, 53, 'qwrqwrrqw'),
(1846, 53, 'wrqwrqwrqwqwr'),
(1847, 53, '2424234erfaerqw'),
(1848, 53, 'qw5q36534'),
(1854, 52, 'qtqwtqwttqwtq'),
(1855, 52, 'qwtqwtqwt'),
(1856, 52, 'wqtqwtqwtq'),
(1857, 52, 'qwtqwtqwtqwtqwt'),
(1858, 52, 'qwtqwtqwt'),
(1859, 51, 'qwtqwtqwtqwtqw'),
(1860, 51, 'qwtqwtqwt'),
(1861, 51, 'qwtqwtqwtqt'),
(1862, 51, 'wtrqwtqwtqwtqwt'),
(1863, 51, '5r2452525'),
(1864, 51, '6515dgdsag'),
(1865, 50, 'qwtrqwtqwt'),
(1866, 50, 'qwtqwt'),
(1867, 50, 'qwtqwtqw'),
(1868, 50, 'qwtqwtqwt'),
(1869, 49, 'wqtqwtqwtqw'),
(1870, 49, 'qwtqwt'),
(1871, 49, 'qwtqwtqwtqw'),
(1872, 49, 'ghsatgsadga'),
(1873, 49, 'dsagdsagsadg'),
(1874, 49, 'rwwqrqwrqwr'),
(1875, 49, 'qrwrqw'),
(1876, 49, 'qwtqweagg'),
(1877, 49, 'awstwtrqw'),
(1878, 48, 'eywetyewtw'),
(1879, 48, 'qwtqwtqw'),
(1880, 48, 'wtqwtqwtqwt'),
(1881, 48, 'wqtqwt'),
(1882, 48, 'wtqwt'),
(1883, 48, 'tq3wtqwtqwt'),
(1884, 48, 'wrtwr'),
(1885, 48, 'rqwtqwt'),
(1886, 48, 'qwtqwtqwtqqw'),
(1887, 47, 'sagsagsag'),
(1888, 47, 'gastgas'),
(1889, 47, 'hhahah'),
(1890, 47, 'asywtqwtqwt'),
(1891, 47, 'tstgastast'),
(1892, 47, 'qtwtwqatqwt'),
(1893, 47, 'wtwqtqwt'),
(1894, 47, 'qwtqwtqwt'),
(1895, 46, 'sadgdsag'),
(1896, 46, 'dsgsadga'),
(1897, 46, 'ujtjfdhfdhsd'),
(1898, 46, 'hsahah'),
(1899, 46, 'saehgsadgdsag'),
(1900, 46, 'safdhah'),
(1901, 46, 'sadhgsadhgsag'),
(1902, 46, 'dsgsadgagda'),
(1903, 46, 'dsgasdga'),
(1904, 46, 'dsgsdagsag'),
(1905, 45, 'sadgdsag'),
(1906, 45, 'dsgsadga'),
(1907, 45, 'ujtjfdhfdhsd'),
(1908, 45, 'hsahah'),
(1909, 45, 'saehgsadgdsag'),
(1910, 45, 'safdhah'),
(1911, 45, 'sadhgsadhgsag'),
(1912, 45, 'dsgsadgagda'),
(1913, 45, 'dsgasdga'),
(1914, 45, 'dsgsdagsag'),
(1915, 44, 'sagfsafsa'),
(1916, 44, 'sagfastasgasgag'),
(1917, 44, 'sagfasgas'),
(1918, 44, 'sagasgasgasg'),
(1919, 44, 'sagasgasg'),
(1920, 44, 'ahgsahhhhdhds'),
(1921, 44, 'sdhdshsdhdshds'),
(1922, 43, 'ewrytweywe'),
(1923, 43, 'rweuywreywe'),
(1924, 43, 'qwqwtqwtq'),
(1925, 43, 'yqwyqytqy'),
(1926, 43, 'qwtqwtqwtwe'),
(1927, 43, 'weewyewywey'),
(1928, 43, 'ewyewy'),
(1929, 42, 'qwrqwrqwr'),
(1930, 42, 'qwetqwtqwt'),
(1931, 42, 'qwtqwt'),
(1932, 42, 'qwtqwt'),
(1933, 42, 'qwtqwtqw'),
(1934, 42, 'qwtqwtq'),
(1935, 42, 'qwtqwt'),
(1936, 42, 'qwtqwtqwt'),
(1937, 41, 'sdgewtewteqw'),
(1938, 41, 'qwtqwtqwt'),
(1939, 41, 'tqwetqwt'),
(1940, 41, 'wqtqwtqw'),
(1941, 41, 'wqtqw'),
(1942, 41, 'qwtqwtqwtqw'),
(1943, 40, 'eyweyweyw'),
(1944, 40, 'eyewyewywe'),
(1945, 40, 'ewyewywey'),
(1946, 40, 'gufgutrur'),
(1947, 40, 'eyweywey'),
(1948, 40, '3w4763w46r6'),
(1949, 40, 'reyreyeutr'),
(1950, 40, '47476437437'),
(1951, 39, 'reyreyrey'),
(1952, 39, 'reuerueru'),
(1953, 39, 'reuerueru'),
(1954, 39, 'uyeryeryre'),
(1955, 39, 'tutrutu5'),
(1956, 39, 'iutrutrutr'),
(1957, 39, 'trii457564'),
(1958, 39, '5u7euerueu'),
(1959, 39, 'tutututru'),
(1960, 38, 'ewyqweyqeyq'),
(1961, 38, 'qwyqeyq'),
(1962, 38, 'qyqyqyqyy'),
(1963, 38, 'uyryweyweyy'),
(1964, 38, 'eyweyweywe'),
(1965, 38, 'uerurwuyy'),
(1966, 38, 'tqwtqwt'),
(1967, 38, 'tueru'),
(1968, 38, 'utyteteqt'),
(1969, 37, '6q36q3'),
(1970, 37, 'qw65qwe65qw5w'),
(1971, 37, '5qw5qw5q'),
(1972, 37, 'teqtqt'),
(1973, 37, 'ryeryreyrey'),
(1974, 37, 'yii6yiyi'),
(1975, 37, 'ututerueue'),
(1976, 37, 'iutitrutrutr'),
(1977, 36, 'ewyewywe'),
(1978, 36, 'eytweyweywey'),
(1979, 36, 'eyweyewy'),
(1980, 36, 'ewyweywey'),
(1981, 36, 'weyweywe'),
(1982, 36, 'eyewyewy'),
(1983, 36, 'ewywey'),
(1984, 36, 'eywey'),
(1985, 36, 'eyweyeywwey'),
(1986, 36, 'ewygjg'),
(1987, 35, 'weyewyewy'),
(1988, 35, 'qwtqwtqwtwtqwtq'),
(1989, 35, 'wtqwtqwt'),
(1990, 35, 'wtqwt'),
(1991, 35, '525yq3eyqey'),
(1992, 35, '5'),
(1993, 35, 'yey3'),
(1994, 25, 'ewtwet'),
(1995, 25, 'rejhureureu'),
(1996, 25, 'retwet'),
(1997, 25, 'dtuesdg'),
(1998, 25, 'etewtwe'),
(1999, 25, 'ujtee'),
(2000, 25, 'jkktrjj'),
(2001, 25, 'ryewrywrey'),
(2002, 25, 'rwuywry'),
(2003, 25, 'eeqwywey'),
(2004, 25, 'eyweywe'),
(2005, 25, 'w4rywyw'),
(2006, 25, 'ewyujuuwrey'),
(2007, 26, 'wetewtew'),
(2008, 26, 'e6twe63qw65'),
(2009, 26, 'fhdfhdfs'),
(2010, 26, 'twetqwet'),
(2011, 26, 'ew6tewtewt'),
(2012, 26, 'ruyreyrey'),
(2013, 26, 'reuyrewuyrewy'),
(2014, 26, 'wyewyw4eyewy'),
(2015, 27, 'etewytewywey'),
(2016, 27, 'etet'),
(2017, 27, 'etewtetewtwet'),
(2018, 27, 'yewyweyw'),
(2019, 27, 'yewyw'),
(2020, 27, 'weyweyewy'),
(2021, 27, 'ewytew'),
(2022, 27, 'ewytwetwet'),
(2023, 27, 'ewytewt'),
(2024, 27, 'etewt'),
(2025, 27, 'wetewtewtewt'),
(2026, 28, 'yreyryrwy'),
(2027, 28, 'ewytewyewy'),
(2028, 28, 'weyweywey'),
(2029, 28, 'weyweywey'),
(2030, 28, 'weyweyewywe'),
(2031, 28, 'weyweywey'),
(2032, 28, 'werywhryh'),
(2033, 28, 'weyewyewywe'),
(2034, 28, 'ureueru'),
(2035, 28, 'yweyweyweywey'),
(2036, 28, 'ewyewyewywe'),
(2037, 28, 'uwruwru'),
(2038, 24, 'qwtqw'),
(2039, 24, 'qwrqwrqwrqw'),
(2040, 24, 'qwrqwr'),
(2041, 24, 'qwrqwrqwrqwr'),
(2042, 24, 'qwrqwrqw'),
(2043, 24, 'rwrqwr'),
(2044, 24, 'qwrqwrqwr'),
(2045, 24, 'wrqwr'),
(2046, 24, 'qwtrqwytgqw'),
(2047, 24, 'qwtrqwrqw'),
(2048, 24, 'qwetqwtr'),
(2049, 24, 'qwrqw'),
(2050, 24, 'wqtqwtqw'),
(2051, 23, 'eteqwteqw'),
(2052, 23, 'qwtqtqwtq'),
(2053, 23, 'qwtqwtqwt'),
(2054, 23, 'wqtqwt'),
(2055, 23, 'qwtqwtqwt'),
(2056, 23, 'qwtqwtqwt'),
(2057, 23, 'qwtqwt'),
(2058, 23, 'qwtqwtqwt'),
(2059, 23, 'qwtqwt'),
(2060, 23, 'qwtqwtqw'),
(2070, 22, 'gdsgdsg'),
(2071, 22, 'dgsdgdsgsdgds'),
(2072, 22, 'dgdg'),
(2073, 22, 'ewtwetwet'),
(2074, 22, 'etet'),
(2075, 22, 'etewtewtewt'),
(2076, 22, 'etettt'),
(2077, 22, 'etet'),
(2078, 22, 'yweyweywy'),
(2079, 21, 'gdsgsdg'),
(2080, 21, 'dsgsdg'),
(2081, 21, 'dsgsdgs'),
(2082, 21, 'dsgdsg'),
(2083, 20, 'weyeqwyeqwy'),
(2084, 20, 'qwrqwqw'),
(2085, 20, 'rewuyqwuyqy'),
(2086, 20, 'etqwtqwt'),
(2087, 20, 'urey4ry'),
(2088, 20, 'yreyreyrey'),
(2089, 20, 'reyewyewweyewy'),
(2090, 20, 'reuewurwu'),
(2091, 20, 'qy46464'),
(2092, 20, 'yrewyreyreye'),
(2093, 20, 'tutureuy'),
(2094, 20, 'ewu5rewurewu'),
(2095, 20, 'y45u3u52u'),
(2096, 20, 'utrreyw'),
(2097, 20, '57347373773'),
(2098, 19, 'ryrewyrewy'),
(2099, 19, 'rqwrqwr'),
(2100, 19, 'wq6tqwtqwt'),
(2101, 19, 'trqwr'),
(2102, 19, 'qwytqwytqw'),
(2103, 19, 'qwyqyqy'),
(2104, 19, 'qyqyqyqqwyqy'),
(2105, 19, 'qyqyqyuw'),
(2106, 19, 'tritrutru'),
(2107, 19, 'reurwuw'),
(2108, 19, 'tewet'),
(2109, 19, 'uerwuwwu'),
(2110, 19, 'ewtewtewt'),
(2111, 19, 'ur5ueru'),
(2112, 19, 'teqwtqttqqt'),
(2113, 29, 'ewytewyewy'),
(2114, 29, 'qwtqwtqwtqwt'),
(2115, 29, 'qwtqwtqt'),
(2116, 29, 'wqtqwt'),
(2117, 29, 'qwtqt'),
(2118, 29, 'yqeyqyqyqy'),
(2119, 29, 'qwtqwtqwt'),
(2120, 29, 'qwtqyty'),
(2121, 30, 'etqwet'),
(2122, 30, 'yweyewyweyw'),
(2123, 30, 'ewytweywey'),
(2124, 30, 'eyewyew'),
(2125, 30, 'weywywy'),
(2126, 30, 'tqwtqwtq'),
(2127, 30, 'ywry'),
(2128, 30, 'qwtqwtqwt'),
(2129, 30, 'qewytqyqy'),
(2130, 30, 'qwytqyqy'),
(2131, 30, 'qttqtqq'),
(2132, 30, 'eqwyyqqyqy'),
(2133, 30, 'weywywey'),
(2134, 31, 'q6q6q6q'),
(2135, 31, 'qw6q6q6q6q6'),
(2136, 31, 'q6q6q6q6'),
(2137, 31, '363463636'),
(2138, 31, 'yiritriutrre'),
(2139, 31, 'yreuetueue'),
(2140, 31, 'erueruw4e6ewt'),
(2141, 31, 'truerufduy'),
(2142, 31, 'rtitritri'),
(2143, 32, 'qewytqwtqwt'),
(2144, 32, 'qwtqwtqw'),
(2145, 32, 'qwytqwtqwt'),
(2146, 32, 'wtqwtqw'),
(2147, 32, 'yyqeyqweytqy'),
(2148, 32, 'qwtqwtqwt'),
(2149, 32, 'qwtrqw5r'),
(2150, 32, 'wqtqwtqwt'),
(2151, 33, 'weyewyweywey'),
(2152, 33, 'ewyewywey'),
(2153, 33, 'weyweye'),
(2154, 33, 'etweyweywey'),
(2155, 33, 'eytweyweywey'),
(2156, 33, 'eyewyweywey'),
(2157, 33, 'ewyewywy'),
(2158, 33, 'yweywy'),
(2159, 33, 'reuerueruer'),
(2160, 33, 'ruerureue'),
(2161, 9, 'gsadgwag'),
(2162, 9, 'gwdgdwsge'),
(2163, 9, 'fdhsafhash'),
(2164, 9, 'jherjherhwreyh'),
(2165, 9, 'reherhreh'),
(2166, 9, 'rehrhreh'),
(2167, 9, 'erhrehreh'),
(2168, 9, 'reherhreh'),
(2169, 9, 'reherhreh'),
(2170, 9, 'reherhreh'),
(2171, 9, 'reherhreh'),
(2172, 9, 'reherhreh'),
(2173, 9, 'reherhreh'),
(2174, 9, 'reherhreh'),
(2175, 9, 'reherhreh'),
(2176, 11, 'eeqtqewtqw'),
(2177, 11, 'qwrqwrqwr'),
(2178, 11, 'weqwe'),
(2179, 11, 'wqrqwrqrqwrqwrqwr'),
(2180, 11, 'wrqwrqwr'),
(2181, 11, 'rqwrwqrqwrqw'),
(2182, 11, 'wrqwrqw'),
(2183, 11, 'wqweqw'),
(2184, 11, 'weqwewewew'),
(2185, 11, 'ewrwr'),
(2186, 11, 'wrwr'),
(2187, 11, 'tqewtqwt'),
(2188, 11, 'rwrw'),
(2189, 11, 'wtrqwt'),
(2190, 11, 'rwqrqwrqwrqwrqwr'),
(2191, 12, 'hgdwghwetg'),
(2192, 12, 'hgdwghwetg'),
(2193, 12, 'hgdwghwetg'),
(2194, 12, 'hgdwghwetg'),
(2195, 12, 'hgdwghwetg'),
(2196, 12, 'hgdwghwetg'),
(2197, 12, 'hgdwghwetg'),
(2198, 12, 'hgdwghwetg'),
(2199, 12, 'hgdwghwetg'),
(2200, 12, 'hgdwghwetg'),
(2201, 12, 'hgdwghwetg'),
(2202, 12, 'hgdwghwetg'),
(2203, 12, 'hgdwghwetg'),
(2204, 12, 'hgdwghwetg'),
(2205, 12, 'hgdwghwetg'),
(2206, 63, '3etqtqwqt'),
(2207, 63, 'weyewyweywe'),
(2208, 63, 'tewtwetew'),
(2209, 63, 'wet3tqwt'),
(2210, 63, 'yrytwetew'),
(2211, 63, 'etewtewt'),
(2212, 63, 'weyweytweyewy'),
(2213, 64, 'yryryweywe'),
(2214, 64, 'wryrwyweytwew'),
(2215, 64, 'eruyreuyweqt'),
(2216, 64, 'rueryeryre'),
(2217, 16, 'yewytwey'),
(2218, 16, 'rwrwr'),
(2219, 16, 'rewqrq'),
(2220, 16, 'uyrdgwsedgew'),
(2221, 16, 'w5r'),
(2222, 16, 'wtqwttqt'),
(2223, 16, 'twqwt'),
(2224, 16, 'qwttqw'),
(2225, 16, 'qwtqwtqwt'),
(2226, 16, '3eytqewytqy'),
(2227, 16, 'etet'),
(2228, 16, 'wrqwrqwrqw'),
(2229, 16, 'qwrwr'),
(2230, 16, 'qwetrqwr'),
(2231, 16, 'ywytewyt'),
(2232, 18, 'etwetwetew'),
(2233, 18, 'ureureureu'),
(2234, 18, 'etewtew'),
(2235, 18, 'eyewy'),
(2236, 18, 'tiuerureureu'),
(2237, 18, 'reureureureu'),
(2238, 18, '53wqw5tqw5'),
(2239, 18, 'reuyrewyrewy'),
(2240, 18, 'trqwetqwt'),
(2241, 18, 'tiuerureu'),
(2242, 18, 'i65iutrutr'),
(2243, 18, 'ryrewyrey'),
(2244, 18, 'rtrewtwrt'),
(2245, 18, 'irtiuue'),
(2246, 18, 'trutyretreytrety'),
(2247, 83, 'qwtqwtqwtqwtqwt'),
(2278, 13, 'hgdwghwetg'),
(2279, 13, 'hgdwghwetg'),
(2280, 13, 'hgdwghwetg'),
(2281, 13, 'hgdwghwetg'),
(2282, 13, 'hgdwghwetg'),
(2283, 13, 'hgdwghwetg'),
(2284, 13, 'hgdwghwetg'),
(2285, 13, 'hgdwghwetg'),
(2286, 13, 'hgdwghwetg'),
(2287, 13, 'hgdwghwetg'),
(2288, 13, 'hgdwghwetg'),
(2289, 13, 'hgdwghwetg'),
(2290, 13, 'hgdwghwetg'),
(2291, 13, 'hgdwghwetg'),
(2292, 13, 'hgdwghwetg');

-- --------------------------------------------------------

--
-- Table structure for table `statistics`
--

CREATE TABLE `statistics` (
  `id` int(11) NOT NULL,
  `total_affiliates` int(11) DEFAULT 0,
  `total_products` int(11) DEFAULT 0,
  `total_income` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `total_sell_amounts` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `total_sell_count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_product`
--

CREATE TABLE `stock_product` (
  `stock_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock_status` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `stock_qty` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `testmonial`
--

CREATE TABLE `testmonial` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `create_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testmonial`
--

INSERT INTO `testmonial` (`id`, `user_name`, `image`, `description`, `create_date`) VALUES
(13, 'Mr. Safik Ahmed', 'uploads/users/13_banner_.png', '<p>Statements from satisfied customers, whether it&rsquo;s in the format of a review with a star rating or a simple quote or endorsement, can have a huge impact.</p>\r\n\r\n<p>For websites and online businesses, testimonials can be even more useful than traditional businesses because visitors are often skeptical or hesitant to trust someone online. How do you know the person or company behind a website can be trusted? Many visitors feel that genuine endorsements from&nbsp;<em>real people</em>&nbsp;can help to build that trust.</p>', '2021-12-16'),
(14, 'Mahammad Alim Hossen', 'uploads/users/14_banner_.jpg', '<p>Website testimonials can be displayed in many different ways, and throughout this article, we&rsquo;ll take a look at 25 real-world&nbsp;examples that will give you plenty of ideas and inspiration. Here you&rsquo;ll find some that use video, photos of customers, quotes from reviews, and more. Some of them are presented in very basic ways and others are more creative or unique in terms of design or implementation.</p>', '2021-12-16'),
(15, 'ddfdf', 'uploads/users/15_banner_.png', '<p>ddddf</p>', '2021-12-16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_day` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bonus_blance` int(11) DEFAULT 0,
  `wallet_blance` int(11) DEFAULT 0,
  `cashback_blance` int(11) DEFAULT 0,
  `phone` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `affiliate_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `picture`, `email`, `birth_day`, `gender`, `bonus_blance`, `wallet_blance`, `cashback_blance`, `phone`, `address`, `password`, `created_date`, `points`, `affiliate_id`) VALUES
(1, 'ddfd', 'user1639658493.png', 'dfdfds', NULL, NULL, 0, 0, 0, '01571133188', 'dfdfd', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `advertisement`
--
ALTER TABLE `advertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `affiliate_coupon_code`
--
ALTER TABLE `affiliate_coupon_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bands`
--
ALTER TABLE `bands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `courier`
--
ALTER TABLE `courier`
  ADD PRIMARY KEY (`courier_id`);

--
-- Indexes for table `hitcounter`
--
ALTER TABLE `hitcounter`
  ADD PRIMARY KEY (`hitcounter_id`);

--
-- Indexes for table `homeslider`
--
ALTER TABLE `homeslider`
  ADD PRIMARY KEY (`homeslider_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messages_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`newsletter_id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `order_data`
--
ALTER TABLE `order_data`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_edit_track`
--
ALTER TABLE `order_edit_track`
  ADD PRIMARY KEY (`order_edit_track_id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_id` (`product_id`,`product_name`,`sku`),
  ADD KEY `product_title` (`product_title`);

--
-- Indexes for table `product_click`
--
ALTER TABLE `product_click`
  ADD PRIMARY KEY (`click_id`);

--
-- Indexes for table `product_comment`
--
ALTER TABLE `product_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `product_detail_media`
--
ALTER TABLE `product_detail_media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_hit_count`
--
ALTER TABLE `product_hit_count`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_of_order_data`
--
ALTER TABLE `product_of_order_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_order_history`
--
ALTER TABLE `product_order_history`
  ADD PRIMARY KEY (`product_order_history_id`);

--
-- Indexes for table `product_permission_report`
--
ALTER TABLE `product_permission_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smtp`
--
ALTER TABLE `smtp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specifications`
--
ALTER TABLE `specifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `statistics`
--
ALTER TABLE `statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testmonial`
--
ALTER TABLE `testmonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483653;

--
-- AUTO_INCREMENT for table `advertisement`
--
ALTER TABLE `advertisement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `affiliate_coupon_code`
--
ALTER TABLE `affiliate_coupon_code`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bands`
--
ALTER TABLE `bands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `courier`
--
ALTER TABLE `courier`
  MODIFY `courier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `hitcounter`
--
ALTER TABLE `hitcounter`
  MODIFY `hitcounter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=729;

--
-- AUTO_INCREMENT for table `homeslider`
--
ALTER TABLE `homeslider`
  MODIFY `homeslider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `media_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=423;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messages_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `newsletter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `order_data`
--
ALTER TABLE `order_data`
  MODIFY `order_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_edit_track`
--
ALTER TABLE `order_edit_track`
  MODIFY `order_edit_track_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `product_click`
--
ALTER TABLE `product_click`
  MODIFY `click_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_comment`
--
ALTER TABLE `product_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_detail_media`
--
ALTER TABLE `product_detail_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `product_hit_count`
--
ALTER TABLE `product_hit_count`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64698;

--
-- AUTO_INCREMENT for table `product_of_order_data`
--
ALTER TABLE `product_of_order_data`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_order_history`
--
ALTER TABLE `product_order_history`
  MODIFY `product_order_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_permission_report`
--
ALTER TABLE `product_permission_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=539;

--
-- AUTO_INCREMENT for table `smtp`
--
ALTER TABLE `smtp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `specifications`
--
ALTER TABLE `specifications`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2293;

--
-- AUTO_INCREMENT for table `statistics`
--
ALTER TABLE `statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testmonial`
--
ALTER TABLE `testmonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
